// Copyright utrazin. All Rights Reserved.

#include "UI/JRHUD.h"
#include "AI/JREnemyCharacter.h"
#include "AI/JRHordeDirector.h"
#include "Characters/JRCharacter.h"
#include "Combat/JRHealthComponent.h"
#include "Combat/JRWeaponComponent.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/Font.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "CanvasItem.h"
#include "Interactions/JRInteractable.h"
#include "Interactions/JRInteractionComponent.h"
#include "Interactions/JRRescueTarget.h"
#include "Engine/Texture2D.h"
#include "Levels/JRCheckpoint.h"
#include "Levels/JRLevelDefinition.h"
#include "Vehicles/JRVehicleDamageComponent.h"
#include "Vehicles/JRVehiclePawn.h"

void AJRHUD::DrawHUD()
{
	Super::DrawHUD();
	if (!Canvas || !PlayerOwner)
	{
		return;
	}
	S = Canvas->ClipY / 1080.f;
	APawn* Pawn = PlayerOwner->GetPawn();

	const UJRObjectiveSubsystem* Objective = GetWorld()->GetSubsystem<UJRObjectiveSubsystem>();
	const EJRLevelStage Stage = Objective ? Objective->GetStage() : EJRLevelStage::NotStarted;

	if (AJRCharacter* Hero = Cast<AJRCharacter>(Pawn))
	{
		DrawHeroHud(Hero);
	}
	else if (AJRVehiclePawn* Vehicle = Cast<AJRVehiclePawn>(Pawn))
	{
		LastHealth = -1.f;
		DrawVehicleHud(Vehicle);
	}
	DrawToasts();

	DrawObjective(Stage);

	// ---- Guia: marcador no mundo, minimapa e mapa grande
	if (Pawn)
	{
		AActor* Target = FindObjectiveTarget(Stage);
		if (bBigMap)
		{
			DrawBigMapView(Pawn, Target);
		}
		else
		{
			DrawWorldMarker(Target, Pawn);
			DrawMinimap(Pawn, Pawn->IsA<AJRVehiclePawn>(), Target);
		}
	}

	// ---- Flash de dano
	const double Since = GetWorld()->GetTimeSeconds() - DamageFlashStart;
	if (Since < DamageFlashDuration)
	{
		const float A = 0.35f * (1.f - static_cast<float>(Since) / DamageFlashDuration);
		FCanvasTileItem Flash(FVector2D::ZeroVector, FVector2D(Canvas->ClipX, Canvas->ClipY), FLinearColor(0.8f, 0.f, 0.f, A));
		Flash.BlendMode = SE_BLEND_Translucent;
		Canvas->DrawItem(Flash);
	}

	// ---- Telas de fim
	if (Stage == EJRLevelStage::Completed)
	{
		DrawBigBanner(TEXT("RESGATE CONCLUÍDO!"), TEXT("Fase concluída"), AccentColor);
	}
	else if (Stage == EJRLevelStage::Failed)
	{
		DrawBigBanner(TEXT("VOCÊ CAIU"), TEXT("Voltando ao checkpoint..."), HealthColor);
	}
}

UTexture2D* AJRHUD::UITex(FName Name)
{
	if (TObjectPtr<UTexture2D>* Found = UITextures.Find(Name))
	{
		return Found->Get();
	}
	const FString Path = FString::Printf(TEXT("/Game/UI/HUD/T_UI_%s.T_UI_%s"), *Name.ToString(), *Name.ToString());
	UTexture2D* Tex = LoadObject<UTexture2D>(nullptr, *Path, nullptr, LOAD_NoWarn | LOAD_Quiet);
	UITextures.Add(Name, Tex);
	return Tex;
}

void AJRHUD::DrawIcon(FName Name, float X, float Y, float Size, const FLinearColor& Color)
{
	UTexture2D* Tex = UITex(Name);
	if (!Tex || !Tex->GetResource())
	{
		return;
	}
	FCanvasTileItem Shadow(FVector2D(X + 2.f * S, Y + 2.f * S), Tex->GetResource(), FVector2D(Size, Size), FLinearColor(0.f, 0.f, 0.f, 0.6f));
	Shadow.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(Shadow);
	FCanvasTileItem Item(FVector2D(X, Y), Tex->GetResource(), FVector2D(Size, Size), Color);
	Item.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(Item);
}

void AJRHUD::DrawRounded(float X, float Y, float W, float H, float R, const FLinearColor& Color)
{
	R = FMath::Min3(R, W * 0.5f, H * 0.5f);
	UTexture2D* Circle = UITex(TEXT("Circle"));
	auto Rect = [&](float RX, float RY, float RW, float RH)
	{
		if (RW <= 0.f || RH <= 0.f)
		{
			return;
		}
		FCanvasTileItem T(FVector2D(RX, RY), FVector2D(RW, RH), Color);
		T.BlendMode = SE_BLEND_Translucent;
		Canvas->DrawItem(T);
	};
	if (!Circle || !Circle->GetResource() || R < 1.f)
	{
		Rect(X, Y, W, H);
		return;
	}
	Rect(X + R, Y, W - 2.f * R, H);
	Rect(X, Y + R, R, H - 2.f * R);
	Rect(X + W - R, Y + R, R, H - 2.f * R);
	auto Corner = [&](float CX, float CY, float U0, float V0)
	{
		FCanvasTileItem T(FVector2D(CX, CY), Circle->GetResource(), FVector2D(R, R), FVector2D(U0, V0), FVector2D(U0 + 0.5f, V0 + 0.5f), Color);
		T.BlendMode = SE_BLEND_Translucent;
		Canvas->DrawItem(T);
	};
	Corner(X, Y, 0.f, 0.f);
	Corner(X + W - R, Y, 0.5f, 0.f);
	Corner(X, Y + H - R, 0.f, 0.5f);
	Corner(X + W - R, Y + H - R, 0.5f, 0.5f);
}

void AJRHUD::DrawPanel(float X, float Y, float W, float H)
{
	DrawRounded(X, Y, W, H, 14.f * S, PanelColor);
}

void AJRHUD::DrawBar(float X, float Y, float W, float H, float Pct, const FLinearColor& Fill, const FString& Label)
{
	const float B = FMath::Max(2.f, 3.f * S);
	Pct = FMath::Clamp(Pct, 0.f, 1.f);
	DrawRounded(X - B, Y - B, W + 2 * B, H + 2 * B, (H + 2 * B) * 0.5f, FLinearColor(0.f, 0.f, 0.f, 0.75f));
	DrawRounded(X, Y, W, H, H * 0.5f, FLinearColor(0.12f, 0.12f, 0.16f, 0.95f));
	if (Pct > 0.f)
	{
		const float FW = FMath::Max(H, W * Pct);
		DrawRounded(X, Y, FW, H, H * 0.5f, Fill);
		DrawRounded(X + H * 0.3f, Y + H * 0.12f, FMath::Max(0.f, FW - H * 0.6f), H * 0.3f, H * 0.15f, FLinearColor(1.f, 1.f, 1.f, 0.22f));
	}
	if (!Label.IsEmpty())
	{
		DrawLabel(Label, X + W * 0.5f, Y + H * 0.5f - 11.f * S, 1.0f, FLinearColor::White, true);
	}
}

void AJRHUD::DrawLabel(const FString& Text, float X, float Y, float Scale, const FLinearColor& Color, bool bCenterX)
{
	UFont* Font = GEngine ? GEngine->GetMediumFont() : nullptr;
	if (!Font)
	{
		return;
	}
	FCanvasTextItem Item(FVector2D(X, Y), FText::FromString(Text), Font, Color);
	Item.Scale = FVector2D(Scale * S, Scale * S);
	Item.EnableShadow(FLinearColor(0.f, 0.f, 0.f, 0.9f), FVector2D(2.f * S, 2.f * S));
	if (bCenterX)
	{
		float W = 0.f, H = 0.f;
		Canvas->StrLen(Font, Text, W, H);
		Item.Position.X -= W * Scale * S * 0.5f;
	}
	Canvas->DrawItem(Item);
}

void AJRHUD::DrawCrosshair(bool bAiming, bool bReloading)
{
	const float CX = Canvas->ClipX * 0.5f;
	const float CY = Canvas->ClipY * 0.5f;
	const float Gap = (bAiming ? 6.f : 14.f) * S;
	const float Len = 12.f * S;
	const float T = FMath::Max(2.f, 3.f * S);
	const FLinearColor C = bReloading ? FLinearColor(1.f, 1.f, 1.f, 0.35f) : FLinearColor::White;
	auto DrawTick = [&](float X, float Y, float W, float H)
	{
		FCanvasTileItem Shadow(FVector2D(X - 1.f, Y - 1.f), FVector2D(W + 2.f, H + 2.f), FLinearColor(0.f, 0.f, 0.f, 0.6f));
		Shadow.BlendMode = SE_BLEND_Translucent;
		Canvas->DrawItem(Shadow);
		FCanvasTileItem Line(FVector2D(X, Y), FVector2D(W, H), C);
		Line.BlendMode = SE_BLEND_Translucent;
		Canvas->DrawItem(Line);
	};
	DrawTick(CX - Gap - Len, CY - T * 0.5f, Len, T);
	DrawTick(CX + Gap, CY - T * 0.5f, Len, T);
	DrawTick(CX - T * 0.5f, CY - Gap - Len, T, Len);
	DrawTick(CX - T * 0.5f, CY + Gap, T, Len);
	DrawTick(CX - T * 0.5f, CY - T * 0.5f, T, T);
}

AJRHordeDirector* AJRHUD::FindHorde()
{
	if (!CachedHorde.IsValid() && !bSearchedHorde)
	{
		bSearchedHorde = true;
		for (TActorIterator<AJRHordeDirector> It(GetWorld()); It; ++It)
		{
			CachedHorde = *It;
			break;
		}
	}
	return CachedHorde.Get();
}

FString AJRHUD::ObjectiveFor(EJRLevelStage Stage) const
{
	switch (Stage)
	{
	case EJRLevelStage::Driving: return TEXT("Atravesse o vale alienígena até o desembarque");
	case EJRLevelStage::OnFoot: return TEXT("Siga a pé pelas vilas até a nave caída");
	case EJRLevelStage::FinalHorde: return TEXT("Segure a horda na arena!");
	case EJRLevelStage::Rescue: return TEXT("Liberte a sobrevivente da cela");
	case EJRLevelStage::Completed: return TEXT("Fase concluída");
	default: return FString();
	}
}

void AJRHUD::DrawObjective(EJRLevelStage Stage)
{
	if (Stage != LastStage)
	{
		// Novo estágio: a dica antiga não vale mais.
		LastStage = Stage;
		ObjectiveHint.Reset();
	}
	FString Text = ObjectiveFor(Stage);
	if (Text.IsEmpty())
	{
		return;
	}
	if (Stage == EJRLevelStage::FinalHorde)
	{
		if (const AJRHordeDirector* Horde = FindHorde())
		{
			if (Horde->GetCurrentWave() >= 0)
			{
				Text += FString::Printf(TEXT("   Onda %d"), Horde->GetCurrentWave() + 1);
			}
		}
	}
	const float M = 32.f * S;
	const float H = (ObjectiveHint.IsEmpty() ? 80.f : 112.f) * S;
	DrawPanel(M, M, 600.f * S, H);
	DrawRounded(M, M, 8.f * S, H, 4.f * S, AccentColor);
	DrawLabel(TEXT("OBJETIVO"), M + 22.f * S, M + 8.f * S, 0.9f, AccentColor);
	DrawLabel(Text, M + 22.f * S, M + 32.f * S, 1.4f, FLinearColor::White);
	if (!ObjectiveHint.IsEmpty())
	{
		DrawLabel(ObjectiveHint, M + 22.f * S, M + 72.f * S, 1.05f, FLinearColor(1.f, 0.9f, 0.6f));
	}
}

void AJRHUD::DrawBigBanner(const FString& Title, const FString& Sub, const FLinearColor& Color)
{
	const float H = 170.f * S;
	const float Y = Canvas->ClipY * 0.5f - H * 0.5f;
	FCanvasTileItem Band(FVector2D(0.f, Y), FVector2D(Canvas->ClipX, H), FLinearColor(0.f, 0.f, 0.f, 0.6f));
	Band.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(Band);
	DrawLabel(Title, Canvas->ClipX * 0.5f, Y + 30.f * S, 3.2f, Color, true);
	DrawLabel(Sub, Canvas->ClipX * 0.5f, Y + 110.f * S, 1.4f, FLinearColor::White, true);
}

// ====================================================================== guia (minimapa / mapa / marcador)

AActor* AJRHUD::FindObjectiveTarget(EJRLevelStage Stage)
{
	if (!bSearchedTargets)
	{
		bSearchedTargets = true;
		for (TActorIterator<AJRCheckpoint> It(GetWorld()); It; ++It)
		{
			if (It->IsVehicleTransition())
			{
				CachedTransition = *It;
				break;
			}
		}
		for (TActorIterator<AJRRescueTarget> It(GetWorld()); It; ++It)
		{
			CachedRescue = *It;
			break;
		}
	}
	switch (Stage)
	{
	case EJRLevelStage::Driving:
		return CachedTransition.Get();
	case EJRLevelStage::OnFoot:
	case EJRLevelStage::FinalHorde:
		if (AJRHordeDirector* Horde = FindHorde())
		{
			return Horde;
		}
		return CachedRescue.Get();
	case EJRLevelStage::Rescue:
		return CachedRescue.Get();
	default:
		return nullptr;
	}
}

UTexture2D* AJRHUD::GetMinimapTexture()
{
	if (!bSearchedMinimap)
	{
		bSearchedMinimap = true;
		if (const UJRObjectiveSubsystem* Objective = GetWorld()->GetSubsystem<UJRObjectiveSubsystem>())
		{
			if (const UJRLevelDefinition* Def = Objective->GetLevelDefinition())
			{
				CachedMinimap = Def->MinimapTexture.LoadSynchronous();
				MapMin = Def->MinimapWorldMin;
				MapMax = Def->MinimapWorldMax;
			}
		}
	}
	return CachedMinimap.Get();
}

FVector2D AJRHUD::WorldToUV(const FVector& L) const
{
	// Norte para cima: topo da imagem = Y mínimo do mundo.
	return FVector2D((L.X - MapMin.X) / FMath::Max(1.f, MapMax.X - MapMin.X),
		(L.Y - MapMin.Y) / FMath::Max(1.f, MapMax.Y - MapMin.Y));
}

void AJRHUD::DrawDiamond(const FVector2D& C, float R, const FLinearColor& Color)
{
	TArray<FCanvasUVTri> Tris;
	auto Tri = [&](const FVector2D& A, const FVector2D& B, const FVector2D& D, const FLinearColor& Col)
	{
		FCanvasUVTri T;
		T.V0_Pos = A; T.V1_Pos = B; T.V2_Pos = D;
		T.V0_Color = Col; T.V1_Color = Col; T.V2_Color = Col;
		Tris.Add(T);
	};
	const float O = R + 2.f * S;
	const FLinearColor Dark(0.f, 0.f, 0.f, 0.9f);
	Tri(C + FVector2D(0, -O), C + FVector2D(O, 0), C + FVector2D(0, O), Dark);
	Tri(C + FVector2D(0, -O), C + FVector2D(-O, 0), C + FVector2D(0, O), Dark);
	Tri(C + FVector2D(0, -R), C + FVector2D(R, 0), C + FVector2D(0, R), Color);
	Tri(C + FVector2D(0, -R), C + FVector2D(-R, 0), C + FVector2D(0, R), Color);
	Canvas->K2_DrawTriangle(nullptr, Tris);
}

void AJRHUD::DrawArrow(const FVector2D& C, float Yaw, float R, const FLinearColor& Color)
{
	const float A = FMath::DegreesToRadians(Yaw);
	auto Dir = [&](float Off) { return FVector2D(FMath::Cos(A + Off), FMath::Sin(A + Off)); };
	TArray<FCanvasUVTri> Tris;
	auto Tri = [&](float Scale, const FLinearColor& Col)
	{
		FCanvasUVTri T;
		T.V0_Pos = C + Dir(0.f) * R * Scale;
		T.V1_Pos = C + Dir(2.45f) * R * 0.8f * Scale;
		T.V2_Pos = C + Dir(-2.45f) * R * 0.8f * Scale;
		T.V0_Color = Col; T.V1_Color = Col; T.V2_Color = Col;
		Tris.Add(T);
	};
	Tri(1.35f, FLinearColor(0.f, 0.f, 0.f, 0.9f));
	Tri(1.f, Color);
	Canvas->K2_DrawTriangle(nullptr, Tris);
}

void AJRHUD::DrawMinimap(const APawn* Pawn, bool bDriving, const AActor* Target)
{
	UTexture2D* Tex = GetMinimapTexture();
	if (!Tex || !Tex->GetResource())
	{
		return;
	}
	const float M = 32.f * S;
	const float Size = 270.f * S;
	const FVector2D Pos(Canvas->ClipX - M - Size, M);
	const float SpanCm = (bDriving ? MinimapSpanDriving : MinimapSpanOnFoot) * 100.f;
	const FVector2D Span(SpanCm / FMath::Max(1.f, MapMax.X - MapMin.X), SpanCm / FMath::Max(1.f, MapMax.Y - MapMin.Y));
	const FVector2D C = WorldToUV(Pawn->GetActorLocation());
	const FVector2D UV0(FMath::Clamp(C.X - Span.X * 0.5f, 0.f, 1.f - Span.X), FMath::Clamp(C.Y - Span.Y * 0.5f, 0.f, 1.f - Span.Y));
	auto ToScreen = [&](const FVector& L)
	{
		const FVector2D UV = WorldToUV(L);
		return Pos + (UV - UV0) / Span * Size;
	};

	DrawPanel(Pos.X - 6.f * S, Pos.Y - 6.f * S, Size + 12.f * S, Size + 12.f * S);
	FCanvasTileItem Map(Pos, Tex->GetResource(), FVector2D(Size, Size), UV0, UV0 + Span, FLinearColor::White);
	Canvas->DrawItem(Map);

	for (TActorIterator<AJREnemyCharacter> It(GetWorld()); It; ++It)
	{
		if (It->IsDead())
		{
			continue;
		}
		const FVector2D P = ToScreen(It->GetActorLocation());
		if (P.X > Pos.X && P.Y > Pos.Y && P.X < Pos.X + Size && P.Y < Pos.Y + Size)
		{
			FCanvasTileItem Dot(P - FVector2D(3.f, 3.f) * S, FVector2D(6.f, 6.f) * S, HealthColor);
			Canvas->DrawItem(Dot);
		}
	}
	if (Target)
	{
		FVector2D P = ToScreen(Target->GetActorLocation());
		const FVector2D Mid = Pos + FVector2D(Size, Size) * 0.5f;
		const float Inset = 12.f * S;
		FVector2D D = P - Mid;
		const float Lim = Size * 0.5f - Inset;
		const float K = FMath::Max(FMath::Abs(D.X), FMath::Abs(D.Y)) / Lim;
		if (K > 1.f)
		{
			P = Mid + D / K; // fora da área: preso na borda, apontando para o objetivo
		}
		DrawDiamond(P, (K > 1.f ? 7.f : 9.f) * S, ObjectiveColor);
		const float Dist = FVector::Dist2D(Pawn->GetActorLocation(), Target->GetActorLocation()) / 100.f;
		DrawLabel(FString::Printf(TEXT("OBJETIVO  %d m"), FMath::RoundToInt(Dist)), Pos.X, Pos.Y + Size + 10.f * S, 1.1f, ObjectiveColor);
	}
	DrawArrow(ToScreen(Pawn->GetActorLocation()), Pawn->GetActorRotation().Yaw, 10.f * S, FLinearColor::White);
	DrawLabel(TEXT("N"), Pos.X + Size * 0.5f, Pos.Y + 2.f * S, 1.0f, FLinearColor::White, true);
	DrawLabel(TEXT("[M] MAPA"), Pos.X + Size - 80.f * S, Pos.Y + Size + 10.f * S, 0.9f, FLinearColor(0.8f, 0.8f, 0.8f));
}

void AJRHUD::DrawBigMapView(const APawn* Pawn, const AActor* Target)
{
	UTexture2D* Tex = GetMinimapTexture();
	FCanvasTileItem Dim(FVector2D::ZeroVector, FVector2D(Canvas->ClipX, Canvas->ClipY), FLinearColor(0.f, 0.f, 0.f, 0.65f));
	Dim.BlendMode = SE_BLEND_Translucent;
	Canvas->DrawItem(Dim);
	if (!Tex || !Tex->GetResource())
	{
		DrawLabel(TEXT("Mapa indisponível nesta fase"), Canvas->ClipX * 0.5f, Canvas->ClipY * 0.5f, 1.6f, FLinearColor::White, true);
		return;
	}
	const float Size = Canvas->ClipY * 0.82f;
	const FVector2D Pos((Canvas->ClipX - Size) * 0.5f, (Canvas->ClipY - Size) * 0.5f + 20.f * S);
	auto ToScreen = [&](const FVector& L) { return Pos + WorldToUV(L) * Size; };
	DrawPanel(Pos.X - 8.f * S, Pos.Y - 8.f * S, Size + 16.f * S, Size + 16.f * S);
	FCanvasTileItem Map(Pos, Tex->GetResource(), FVector2D(Size, Size), FLinearColor::White);
	Canvas->DrawItem(Map);
	for (TActorIterator<AJREnemyCharacter> It(GetWorld()); It; ++It)
	{
		if (!It->IsDead())
		{
			const FVector2D P = ToScreen(It->GetActorLocation());
			FCanvasTileItem Dot(P - FVector2D(3.f, 3.f) * S, FVector2D(6.f, 6.f) * S, HealthColor);
			Canvas->DrawItem(Dot);
		}
	}
	if (Target)
	{
		DrawDiamond(ToScreen(Target->GetActorLocation()), 11.f * S, ObjectiveColor);
	}
	DrawArrow(ToScreen(Pawn->GetActorLocation()), Pawn->GetActorRotation().Yaw, 12.f * S, FLinearColor::White);
	DrawLabel(TEXT("MAPA"), Canvas->ClipX * 0.5f, Pos.Y - 46.f * S, 1.8f, FLinearColor::White, true);
	DrawLabel(TEXT("[M] fechar     seta = você     losango = objetivo     pontos vermelhos = zumbis"),
		Canvas->ClipX * 0.5f, Pos.Y + Size + 14.f * S, 1.0f, FLinearColor(0.85f, 0.85f, 0.85f), true);
}

void AJRHUD::DrawWorldMarker(const AActor* Target, const APawn* Pawn)
{
	if (!Target)
	{
		return;
	}
	const FVector MarkerPos = Target->GetActorLocation() + FVector(0.f, 0.f, 350.f);
	FVector Screen = Project(MarkerPos, false);
	const float Edge = 60.f * S;
	bool bOff = false;
	if (Screen.Z <= 0.f)
	{
		// atrás da câmera: espelha para a borda de baixo
		Screen.X = Canvas->ClipX - Screen.X;
		Screen.Y = Canvas->ClipY - Edge;
		bOff = true;
	}
	if (Screen.X < Edge || Screen.X > Canvas->ClipX - Edge || Screen.Y < Edge || Screen.Y > Canvas->ClipY - Edge)
	{
		bOff = true;
	}
	Screen.X = FMath::Clamp(Screen.X, Edge, Canvas->ClipX - Edge);
	Screen.Y = FMath::Clamp(Screen.Y, Edge + 110.f * S, Canvas->ClipY - Edge);
	const float Dist = FVector::Dist(Pawn->GetActorLocation(), Target->GetActorLocation()) / 100.f;
	if (!bOff && Dist < 12.f)
	{
		return; // já chegou
	}
	DrawDiamond(FVector2D(Screen.X, Screen.Y), (bOff ? 9.f : 12.f) * S, ObjectiveColor);
	DrawLabel(FString::Printf(TEXT("%d m"), FMath::RoundToInt(Dist)), Screen.X, Screen.Y + 16.f * S, 1.1f, ObjectiveColor, true);
}

// ====================================================================== HUD do herói / carro / avisos

void AJRHUD::DrawHeroHud(AJRCharacter* Hero)
{
	const float M = 32.f * S;
	const float Now = static_cast<float>(GetWorld()->GetTimeSeconds());
	// ---- Vida (canto inferior esquerdo)
	const UJRHealthComponent* Health = Hero->GetHealthComponent();
	const float Hp = Health->GetHealth();
	if (LastHealth >= 0.f && Hp < LastHealth)
	{
		DamageFlashStart = Now;
	}
	LastHealth = Hp;
	const float PanelW = 430.f * S, PanelH = 96.f * S;
	const float PX = M, PY = Canvas->ClipY - M - PanelH;
	DrawPanel(PX, PY, PanelW, PanelH);
	const float Pulse = Health->GetHealthNormalized() < 0.3f ? 0.75f + 0.25f * FMath::Sin(Now * 8.f) : 1.f;
	DrawIcon(TEXT("Heart"), PX + 14.f * S, PY + 18.f * S, 60.f * S, HealthColor * Pulse);
	DrawLabel(TEXT("VIDA"), PX + 90.f * S, PY + 12.f * S, 0.95f, FLinearColor(0.85f, 0.85f, 0.9f));
	DrawBar(PX + 90.f * S, PY + 42.f * S, PanelW - 110.f * S, 34.f * S, Health->GetHealthNormalized(), HealthColor,
		FString::Printf(TEXT("%d / %d"), FMath::CeilToInt(Hp), FMath::CeilToInt(Health->GetMaxHealth())));

	// ---- Fúria (barra roxa logo acima)
	const float Fury = Hero->GetFuryRemaining();
	if (Fury > 0.f)
	{
		const FLinearColor Purple(0.75f, 0.25f, 1.f, 1.f);
		DrawPanel(PX, PY - 56.f * S, PanelW, 48.f * S);
		DrawIcon(TEXT("Fury"), PX + 14.f * S, PY - 50.f * S, 36.f * S, Purple);
		DrawLabel(FString::Printf(TEXT("FÚRIA  %.0fs"), FMath::CeilToFloat(Fury)), PX + 60.f * S, PY - 46.f * S, 1.15f, Purple);
		// borda roxa pulsando na tela
		const float A = 0.10f + 0.06f * FMath::Sin(Now * 6.f);
		for (int32 Side = 0; Side < 2; ++Side)
		{
			FCanvasTileItem Edge(FVector2D(Side == 0 ? 0.f : Canvas->ClipX - 40.f * S, 0.f), FVector2D(40.f * S, Canvas->ClipY), FLinearColor(0.6f, 0.1f, 1.f, A));
			Edge.BlendMode = SE_BLEND_Translucent;
			Canvas->DrawItem(Edge);
		}
	}

	// ---- Armas (canto inferior direito): 3 espaços + munição
	const UJRWeaponComponent* Weapon = Hero->GetWeaponComponent();
	const float WW = 420.f * S, WH = 140.f * S;
	const float WX = Canvas->ClipX - M - WW, WY = Canvas->ClipY - M - WH;
	DrawPanel(WX, WY, WW, WH);
	struct FSlotInfo { EJRWeaponSlot Slot; const TCHAR* Icon; const TCHAR* Key; };
	const FSlotInfo Slots[] = { { EJRWeaponSlot::Melee, TEXT("Stick"), TEXT("Graveto") },
		{ EJRWeaponSlot::Pistol, TEXT("Pistol"), TEXT("Pistola") }, { EJRWeaponSlot::Shotgun, TEXT("Shotgun"), TEXT("Escopeta") } };
	const EJRWeaponSlot Current = Hero->GetCurrentWeaponSlot();
	for (int32 i = 0; i < 3; ++i)
	{
		const float SX = WX + 14.f * S + i * 66.f * S, SY = WY + 14.f * S;
		const bool bOwned = Hero->OwnsWeapon(Slots[i].Slot);
		const bool bActive = Current == Slots[i].Slot;
		DrawRounded(SX, SY, 58.f * S, 58.f * S, 10.f * S, bActive ? FLinearColor(AccentColor.R, AccentColor.G, AccentColor.B, 0.35f) : FLinearColor(1.f, 1.f, 1.f, 0.06f));
		DrawIcon(Slots[i].Icon, SX + 6.f * S, SY + 6.f * S, 46.f * S,
			bOwned ? (bActive ? AccentColor : FLinearColor(0.85f, 0.85f, 0.85f, 0.9f)) : FLinearColor(1.f, 1.f, 1.f, 0.12f));
	}
	const TCHAR* Name = Current == EJRWeaponSlot::Melee ? TEXT("GRAVETO ALIEN") : Current == EJRWeaponSlot::Pistol ? TEXT("PISTOLA ALIEN")
		: Current == EJRWeaponSlot::Shotgun ? TEXT("ESCOPETA ALIEN") : TEXT("DESARMADO");
	DrawLabel(Name, WX + 14.f * S, WY + 86.f * S, 1.05f, Current == EJRWeaponSlot::None ? FLinearColor(0.7f, 0.7f, 0.7f) : AccentColor);
	DrawLabel(TEXT("[Q] trocar"), WX + 14.f * S, WY + 112.f * S, 0.8f, FLinearColor(0.7f, 0.7f, 0.75f));
	if (Hero->IsWeaponEquipped())
	{
		const FJRAmmoState Ammo = Weapon->GetAmmo();
		const FLinearColor MagColor = Ammo.Magazine == 0 ? HealthColor : FLinearColor::White;
		DrawIcon(TEXT("Cell"), WX + 222.f * S, WY + 22.f * S, 44.f * S, AccentColor);
		DrawLabel(FString::Printf(TEXT("%d"), Ammo.Magazine), WX + 268.f * S, WY + 10.f * S, 3.0f, MagColor);
		DrawLabel(FString::Printf(TEXT("/ %d"), Ammo.Reserve), WX + 340.f * S, WY + 40.f * S, 1.5f, FLinearColor(0.8f, 0.8f, 0.8f));
		if (Weapon->IsReloading())
		{
			DrawLabel(TEXT("RECARREGANDO..."), WX + 222.f * S, WY + 92.f * S, 1.1f, AccentColor);
		}
		else if (Ammo.Magazine == 0)
		{
			DrawLabel(Ammo.Reserve > 0 ? TEXT("[R] RECARREGAR") : TEXT("SEM CÉLULAS"), WX + 222.f * S, WY + 92.f * S, 1.1f, HealthColor);
		}
		if (Current == EJRWeaponSlot::Shotgun)
		{
			DrawShotgunCrosshair(Hero->IsAimHeld());
		}
		else
		{
			DrawCrosshair(Hero->IsAimHeld(), Weapon->IsReloading());
		}
	}
	else if (Current == EJRWeaponSlot::Melee)
	{
		// ponto discreto no centro para orientar o golpe
		DrawRounded(Canvas->ClipX * 0.5f - 3.f * S, Canvas->ClipY * 0.5f - 3.f * S, 6.f * S, 6.f * S, 3.f * S, FLinearColor(1.f, 1.f, 1.f, 0.7f));
	}

	// ---- Interação
	if (const UJRInteractionComponent* Interaction = Hero->FindComponentByClass<UJRInteractionComponent>())
	{
		if (AActor* Target = Interaction->FindInteractable())
		{
			const FString Text = IJRInteractable::Execute_GetInteractionText(Target).ToString();
			const FString Line = Text.IsEmpty() ? FString(TEXT("Interagir")) : Text;
			const float BW = (110.f + Line.Len() * 13.f) * S;
			const float BX = Canvas->ClipX * 0.5f - BW * 0.5f, BY = Canvas->ClipY * 0.66f;
			DrawRounded(BX, BY, BW, 50.f * S, 25.f * S, FLinearColor(0.f, 0.f, 0.f, 0.6f));
			DrawRounded(BX + 8.f * S, BY + 8.f * S, 34.f * S, 34.f * S, 8.f * S, AccentColor);
			DrawLabel(TEXT("E"), BX + 25.f * S, BY + 13.f * S, 1.2f, FLinearColor(0.05f, 0.05f, 0.08f), true);
			DrawLabel(Line, BX + 54.f * S, BY + 12.f * S, 1.25f, FLinearColor::White);
		}
	}
}

void AJRHUD::DrawVehicleHud(AJRVehiclePawn* Vehicle)
{
	const float M = 32.f * S;
	const UJRVehicleDamageComponent* Damage = Vehicle->GetDamageComponent();
	const float Integrity = Damage ? Damage->GetIntegrity() : 1.f;
	const float PanelW = 430.f * S, PanelH = 150.f * S;
	const float PX = M, PY = Canvas->ClipY - M - PanelH;
	DrawPanel(PX, PY, PanelW, PanelH);
	const FLinearColor CarColor = Integrity > 0.5f ? AccentColor : (Integrity > 0.25f ? FLinearColor(1.f, 0.7f, 0.1f) : HealthColor);
	DrawIcon(TEXT("Car"), PX + 14.f * S, PY + 14.f * S, 60.f * S, CarColor);
	DrawLabel(TEXT("CARRO"), PX + 90.f * S, PY + 10.f * S, 0.95f, FLinearColor(0.85f, 0.85f, 0.9f));
	DrawBar(PX + 90.f * S, PY + 38.f * S, PanelW - 110.f * S, 30.f * S, Integrity, CarColor, FString::Printf(TEXT("%d%%"), FMath::RoundToInt(Integrity * 100.f)));
	const FLinearColor NitroColor(0.2f, 0.6f, 1.f, 1.f);
	const float Glow = Vehicle->IsNitroActive() ? 1.f + 0.4f * FMath::Sin(static_cast<float>(GetWorld()->GetTimeSeconds()) * 20.f) : 1.f;
	DrawIcon(TEXT("Nitro"), PX + 18.f * S, PY + 84.f * S, 52.f * S, NitroColor * Glow);
	DrawLabel(TEXT("NITRO  [SHIFT]"), PX + 90.f * S, PY + 82.f * S, 0.95f, FLinearColor(0.85f, 0.85f, 0.9f));
	DrawBar(PX + 90.f * S, PY + 108.f * S, PanelW - 110.f * S, 24.f * S, Vehicle->GetNitro(), NitroColor, FString());

	const float SW = 250.f * S, SH = 110.f * S;
	const float SX = Canvas->ClipX - M - SW, SY = Canvas->ClipY - M - SH;
	DrawPanel(SX, SY, SW, SH);
	DrawLabel(FString::Printf(TEXT("%d"), FMath::Abs(FMath::RoundToInt(Vehicle->GetSpeedKmh()))), SX + 20.f * S, SY + 10.f * S, 3.4f, FLinearColor::White);
	DrawLabel(TEXT("km/h"), SX + 160.f * S, SY + 56.f * S, 1.3f, FLinearColor(0.8f, 0.8f, 0.8f));
}

void AJRHUD::DrawShotgunCrosshair(bool bAiming)
{
	const float Size = (bAiming ? 70.f : 100.f) * S;
	DrawIcon(TEXT("Ring"), Canvas->ClipX * 0.5f - Size * 0.5f, Canvas->ClipY * 0.5f - Size * 0.5f, Size, FLinearColor(1.f, 1.f, 1.f, 0.85f));
	DrawRounded(Canvas->ClipX * 0.5f - 3.f * S, Canvas->ClipY * 0.5f - 3.f * S, 6.f * S, 6.f * S, 3.f * S, FLinearColor::White);
}

void AJRHUD::ShowToast(const FString& Text, FLinearColor Color)
{
	FToast T;
	T.Text = Text;
	T.Color = Color;
	T.Start = GetWorld() ? GetWorld()->GetTimeSeconds() : 0.0;
	Toasts.Add(T);
	if (Toasts.Num() > 4)
	{
		Toasts.RemoveAt(0);
	}
}

void AJRHUD::Toast(const UObject* WorldContext, const FString& Text, FLinearColor Color)
{
	const UWorld* World = WorldContext ? WorldContext->GetWorld() : nullptr;
	const APlayerController* PC = World ? World->GetFirstPlayerController() : nullptr;
	if (AJRHUD* Hud = PC ? Cast<AJRHUD>(PC->GetHUD()) : nullptr)
	{
		Hud->ShowToast(Text, Color);
	}
}

void AJRHUD::DrawToasts()
{
	const double Now = GetWorld()->GetTimeSeconds();
	Toasts.RemoveAll([Now](const FToast& T) { return Now - T.Start > 3.0; });
	float Y = Canvas->ClipY * 0.74f;
	for (const FToast& T : Toasts)
	{
		const float Age = static_cast<float>(Now - T.Start);
		const float A = Age < 0.2f ? Age / 0.2f : (Age > 2.4f ? FMath::Max(0.f, (3.f - Age) / 0.6f) : 1.f);
		const float BW = (60.f + T.Text.Len() * 13.f) * S;
		DrawRounded(Canvas->ClipX * 0.5f - BW * 0.5f, Y, BW, 42.f * S, 21.f * S, FLinearColor(0.f, 0.f, 0.f, 0.55f * A));
		FLinearColor C = T.Color;
		C.A = A;
		DrawLabel(T.Text, Canvas->ClipX * 0.5f, Y + 9.f * S, 1.2f, C, true);
		Y += 48.f * S;
	}
}
