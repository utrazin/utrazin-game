// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "Levels/JRObjectiveSubsystem.h"
#include "JRHUD.generated.h"

class AJRHordeDirector;
class UTexture2D;

/**
 * HUD do jogo (GDD 10): vida, munição, mira, objetivo, carro, interação e avisos.
 * Desenhado em C++ (Canvas) para funcionar sem montar widgets no editor; estilo cartoon simples.
 */
UCLASS()
class JOGORESGATE_API AJRHUD : public AHUD
{
	GENERATED_BODY()

public:
	virtual void DrawHUD() override;

	/** Mapa grande na tela (tecla M). */
	UFUNCTION(BlueprintCallable, Category = "HUD")
	void ToggleBigMap() { bBigMap = !bBigMap; }

	/** Aviso curto no centro-baixo da tela ("Pegou: pistola", "+12 células"...). */
	UFUNCTION(BlueprintCallable, Category = "HUD")
	void ShowToast(const FString& Text, FLinearColor Color = FLinearColor::White);

	/** Dica do que fazer agora (aparece embaixo do objetivo). */
	UFUNCTION(BlueprintCallable, Category = "HUD")
	void SetObjectiveHint(const FString& Hint) { ObjectiveHint = Hint; }

	/** Atalho para qualquer código mostrar aviso no HUD do jogador 1. */
	static void Toast(const UObject* WorldContext, const FString& Text, FLinearColor Color = FLinearColor::White);

protected:
	/** Cor de destaque (mesma faixa verde da pistola). */
	UPROPERTY(EditDefaultsOnly, Category = "HUD")
	FLinearColor AccentColor = FLinearColor(0.1f, 0.95f, 0.55f, 1.f);

	UPROPERTY(EditDefaultsOnly, Category = "HUD")
	FLinearColor HealthColor = FLinearColor(0.95f, 0.25f, 0.25f, 1.f);

	UPROPERTY(EditDefaultsOnly, Category = "HUD")
	FLinearColor PanelColor = FLinearColor(0.f, 0.f, 0.f, 0.45f);

	/** Área mostrada no minimapa (largura em metros) a pé e no carro. */
	UPROPERTY(EditDefaultsOnly, Category = "HUD|Minimap", meta = (Units = "m"))
	float MinimapSpanOnFoot = 260.f;

	UPROPERTY(EditDefaultsOnly, Category = "HUD|Minimap", meta = (Units = "m"))
	float MinimapSpanDriving = 520.f;

	UPROPERTY(EditDefaultsOnly, Category = "HUD|Minimap")
	FLinearColor ObjectiveColor = FLinearColor(1.f, 0.82f, 0.1f, 1.f);

	/** Duração do flash vermelho ao levar dano. */
	UPROPERTY(EditDefaultsOnly, Category = "HUD", meta = (Units = "s"))
	float DamageFlashDuration = 0.45f;

private:
	void DrawPanel(float X, float Y, float W, float H);
	void DrawRounded(float X, float Y, float W, float H, float R, const FLinearColor& Color);
	void DrawIcon(FName Name, float X, float Y, float Size, const FLinearColor& Color);
	UTexture2D* UITex(FName Name);
	void DrawHeroHud(class AJRCharacter* Hero);
	void DrawVehicleHud(class AJRVehiclePawn* Vehicle);
	void DrawToasts();
	void DrawShotgunCrosshair(bool bAiming);
	void DrawBar(float X, float Y, float W, float H, float Pct, const FLinearColor& Fill, const FString& Label);
	void DrawLabel(const FString& Text, float X, float Y, float Scale, const FLinearColor& Color, bool bCenterX = false);
	void DrawCrosshair(bool bAiming, bool bReloading);
	void DrawObjective(EJRLevelStage Stage);
	void DrawBigBanner(const FString& Title, const FString& Sub, const FLinearColor& Color);
	FString ObjectiveFor(EJRLevelStage Stage) const;
	AJRHordeDirector* FindHorde();
	void DrawMinimap(const APawn* Pawn, bool bDriving, const AActor* Target);
	void DrawBigMapView(const APawn* Pawn, const AActor* Target);
	void DrawWorldMarker(const AActor* Target, const APawn* Pawn);
	AActor* FindObjectiveTarget(EJRLevelStage Stage);
	UTexture2D* GetMinimapTexture();
	FVector2D WorldToUV(const FVector& L) const;
	void DrawDiamond(const FVector2D& C, float R, const FLinearColor& Color);
	void DrawArrow(const FVector2D& C, float Yaw, float R, const FLinearColor& Color);

	TWeakObjectPtr<AActor> CachedTransition;
	TWeakObjectPtr<AActor> CachedRescue;
	TWeakObjectPtr<UTexture2D> CachedMinimap;
	bool bSearchedTargets = false;
	bool bSearchedMinimap = false;
	bool bBigMap = false;
	FVector2D MapMin = FVector2D(-100000.f, -100000.f);
	FVector2D MapMax = FVector2D(100000.f, 100000.f);

	TWeakObjectPtr<AJRHordeDirector> CachedHorde;
	bool bSearchedHorde = false;
	float LastHealth = -1.f;
	double DamageFlashStart = -100.0;
	float S = 1.f; // escala da UI (base 1080p)

	UPROPERTY(Transient)
	TMap<FName, TObjectPtr<UTexture2D>> UITextures;

	struct FToast
	{
		FString Text;
		FLinearColor Color;
		double Start = 0.0;
	};
	TArray<FToast> Toasts;
	FString ObjectiveHint;
	EJRLevelStage LastStage = EJRLevelStage::NotStarted;
};
