// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "Vehicles/JRVehicleDamageModel.h"
#include "Vehicles/JRZombieCarTypes.h"
#include "JRVehiclePawn.generated.h"

class AJREnemyCharacter;
class UCameraComponent;
class UNiagaraComponent;
class UNiagaraSystem;
class UPointLightComponent;
class USoundBase;
class UInputAction;
class UJRVehicleDamageComponent;
class UAnimSequenceBase;
class UPhysicalMaterial;
class UPrimitiveComponent;
class USkeletalMeshComponent;
class USpringArmComponent;
class UStaticMeshComponent;
struct FInputActionValue;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FJROnZombieCarEvent, EJRZombieCarEvent, Event, AActor*, Zombie, FVector, Location, float, Value);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FJROnVehicleDamageFXStateChanged, EJRVehicleDamageFXState, NewState);

/**
 * SUV jogável (A-008) sobre Chaos Vehicles. Tuning de rodas/motor fica no Blueprint
 * derivado (BP_Vehicle_SUV) e em docs/gameplay/VEHICLE.md.
 */
UCLASS()
class JOGORESGATE_API AJRVehiclePawn : public AWheeledVehiclePawn
{
	GENERATED_BODY()

public:
	AJRVehiclePawn();

	/** Zera inputs, freia e desativa o veículo após a saída do jogador (A-015). */
	UFUNCTION(BlueprintCallable, Category = "Vehicle")
	void ParkAndDisable();

	UFUNCTION(BlueprintPure, Category = "Vehicle")
	UJRVehicleDamageComponent* GetDamageComponent() const { return DamageComponent; }

	UFUNCTION(BlueprintPure, Category = "Vehicle")
	FTransform GetExitTransform() const;

	/** Banco do motorista (onde a animação de sair do carro começa). */
	UFUNCTION(BlueprintPure, Category = "Vehicle")
	FTransform GetSeatTransform() const;

	/** Freia até quase parar (ou até ExitStopTimeout) e só então tira o jogador do carro. */
	void StopThenExit(const FTransform& FallbackTransform);

	UFUNCTION(BlueprintPure, Category = "Vehicle")
	float GetSpeedKmh() const;

	/** Carga de nitro 0..1. */
	UFUNCTION(BlueprintPure, Category = "Vehicle|Nitro")
	float GetNitro() const { return NitroCharge; }

	UFUNCTION(BlueprintPure, Category = "Vehicle|Nitro")
	bool IsNitroActive() const { return bNitroActive; }

	UFUNCTION(BlueprintCallable, Category = "Vehicle|Nitro")
	void AddNitro(float Amount) { NitroCharge = FMath::Clamp(NitroCharge + Amount, 0.f, 1.f); }

	/** Mostra/esconde o motorista sentado (cópia visual do herói selecionado). */
	UFUNCTION(BlueprintCallable, Category = "Vehicle|Driver")
	void SetDriverVisible(bool bVisible);

	/** Copia malha, materiais e animação de dirigir do herói selecionado para o DriverMesh. */
	UFUNCTION(BlueprintCallable, Category = "Vehicle|Driver")
	void RefreshDriver();

	/**
	 * Distância (cm) de um ponto do mundo até a caixa da carroceria (0 = encostado ou dentro).
	 * OutClosestPoint (opcional) recebe o ponto da lataria mais próximo.
	 */
	float GetDistanceToBody(const FVector& WorldPoint, FVector* OutClosestPoint = nullptr) const;

	/** Reserva o ponto de agarre livre mais próximo (capô, esquerda, direita). INDEX_NONE se não der. */
	int32 TryReserveGrabSlot(AJREnemyCharacter* Zombie);

	/** Libera o ponto ocupado por este zumbi (chamado pelo próprio zumbi ao soltar ou morrer). */
	void ReleaseGrabSlot(AJREnemyCharacter* Zombie);

	USceneComponent* GetGrabPoint(int32 Slot) const;

	/** Zona do carro que o zumbi agarrado neste ponto danifica. */
	EJRVehicleZone GetGrabZone(int32 Slot) const;

	UFUNCTION(BlueprintPure, Category = "Vehicle|Zombies")
	int32 GetGrabberCount() const;

	/** Solta todos os zumbis agarrados. bKill = arremessa (ragdoll) e mata. */
	UFUNCTION(BlueprintCallable, Category = "Vehicle|Zombies")
	void ReleaseAllGrabbers(bool bKill);

	/** Cada zumbi atropelado tira esta fração da velocidade, com teto: a horda freia mas não para o carro. */
	void ApplyZombieDrag(float Fraction);

	/** Explode o carro (integridade zerou): dano em área, arremessa zumbis, jogador sai a pé ou falha. */
	UFUNCTION(BlueprintCallable, Category = "Vehicle|Damage FX")
	void Explode();

	UFUNCTION(BlueprintPure, Category = "Vehicle|Damage FX")
	bool IsWrecked() const { return bExploded; }

	UFUNCTION(BlueprintPure, Category = "Vehicle|Damage FX")
	EJRVehicleDamageFXState GetDamageFXState() const { return DamageFXState; }

	/** Bomba armada (jogador saiu do carro pegando fogo)? */
	UFUNCTION(BlueprintPure, Category = "Vehicle|Damage FX")
	bool IsCarBombArmed() const;

	/**
	 * Avisa um evento zumbi x carro: dispara OnZombieCarEvent (delegate) e BP_OnZombieCarEvent (Blueprint).
	 * Chamado pelos zumbis, pela barricada e pelo próprio carro. Gancho de som/VFX (Etapa 10).
	 */
	UFUNCTION(BlueprintCallable, Category = "Vehicle|Events")
	void NotifyZombieCarEvent(EJRZombieCarEvent Event, AActor* Zombie, FVector Location, float Value);

	UPROPERTY(BlueprintAssignable, Category = "Vehicle|Events")
	FJROnZombieCarEvent OnZombieCarEvent;

	/** Mudou o estado visual de dano (Intact, Smoking, Burning, Wrecked). */
	UPROPERTY(BlueprintAssignable, Category = "Vehicle|Events")
	FJROnVehicleDamageFXStateChanged OnDamageFXStateChanged;

	/** Acima disto os zumbis não conseguem agarrar o carro. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Vehicle|Zombies", meta = (Units = "km/h"))
	float GrabMaxSpeedKmh = 40.f;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	/** Ajudas arcade: segura a derrapagem lateral (anti "gelo") quando as rodas estão no chão. */
	void ApplyGripAssist(float DeltaSeconds);
	bool IsNearGround() const;

	/** Volante gira e motorista inclina com o volante (só visual). */
	void UpdateSteeringVisuals(float DeltaSeconds);

	/** Batida de raspão na parede: desliza junto à parede em vez de parar (estilo corrida). */
	UFUNCTION()
	void HandleVehicleHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	/** Gancho para faísca/som de raspão (implementar no BP depois). AngleDeg = ângulo entre carro e parede. */
	UFUNCTION(BlueprintImplementableEvent, Category = "Vehicle|Walls")
	void OnWallScrape(FVector ImpactPoint, float SpeedKmh, float AngleDeg);

	/** Gancho Blueprint para som/VFX de cada evento zumbi x carro (mesmo conteúdo do delegate OnZombieCarEvent). */
	UFUNCTION(BlueprintImplementableEvent, Category = "Vehicle|Events")
	void BP_OnZombieCarEvent(EJRZombieCarEvent Event, AActor* Zombie, FVector Location, float Value);

	/** Gancho Blueprint: fumaça/fogo/destruído (para VFX e som de verdade depois). */
	UFUNCTION(BlueprintImplementableEvent, Category = "Vehicle|Events")
	void OnDamageStateChanged(EJRVehicleDamageFXState NewState);

	/** Volante com o input do jogador: menos curva em alta velocidade + puxão do pneu furado e dos zumbis agarrados. */
	float ComputeSteering(float RawInput) const;

	/** Puxão no volante dos zumbis agarrados (lateral puxa para o seu lado; no capô balança). */
	float GetGrabSteerBias() const;

	void HandleThrottle(const FInputActionValue& Value);
	void HandleBrake(const FInputActionValue& Value);
	void HandleSteer(const FInputActionValue& Value);
	void HandleSteerReleased(const FInputActionValue& Value);
	void HandleHandbrake(const FInputActionValue& Value);
	void HandleLook(const FInputActionValue& Value);
	void HandleNitro(const FInputActionValue& Value);
	void TickNitro();
	void ZeroInputs(bool bApplyHandbrake);

	UFUNCTION()
	void HandleVehicleDisabled();

	/** Fumaça (<50%), fogo (<25%) conforme a integridade. */
	UFUNCTION()
	void HandleIntegrityChanged(float Integrity);

	/** Posiciona pontos de agarre, fumaça e fogo pelos limites da malha do chassi. */
	void PlaceBodyPointsFromChassis();

	/** Sacudir os zumbis agarrados (curva forte, velocidade alta) e frear o carro com o peso deles. */
	void TickGrabbers(float DeltaSeconds);

	void EndExplosionFlash();

	/** Fogo queimando o motor (1 vez por segundo). */
	void TickBurn();

	void SleepPhysics();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle")
	TObjectPtr<USpringArmComponent> SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle")
	TObjectPtr<UCameraComponent> Camera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle")
	TObjectPtr<UJRVehicleDamageComponent> DamageComponent;

	/** Carroceria visual (estática), presa ao esqueleto da suspensão. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> ChassisMesh;

	/** Pneus visuais nos sockets VisWheel_* (FL, FR, BL, BR). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> TireFL;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> TireFR;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> TireBL;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> TireBR;

	/** Onde o personagem aparece ao sair do carro (lado do motorista). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle")
	TObjectPtr<USceneComponent> ExitPoint;

	/** Banco do motorista. Ajuste no BP se a animação de sair não começar sentada no banco. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle")
	TObjectPtr<USceneComponent> SeatPoint;

	/** Quadril do motorista (preso à carroceria, coordenadas da malha SM_Car_AlienBuggy). Inclina nas curvas. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Driver")
	TObjectPtr<USceneComponent> DriverPivot;

	/** Motorista visual (sem colisão), escala de mundo 1. Ajuste o DriverPivot no BP se ficar fora do banco. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Driver")
	TObjectPtr<USkeletalMeshComponent> DriverMesh;

	/** Volante separado (SM_Car_AlienBuggy_SteeringWheel); o eixo local X é o eixo do volante. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Visual")
	TObjectPtr<UStaticMeshComponent> SteeringWheelMesh;

	/** Ossos escondidos no motorista (canelas/pés atravessariam o assoalho do buggy). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Driver")
	TArray<FName> DriverHiddenBones = { TEXT("calf_l"), TEXT("calf_r") };

	/** Inclinação lateral do motorista com volante todo virado. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Driver", meta = (Units = "Degrees"))
	float DriverLeanDegrees = 8.f;

	/** Giro do tronco/cabeça do motorista para dentro da curva. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Driver", meta = (Units = "Degrees"))
	float DriverYawDegrees = 6.f;

	/** Rotação de repouso do volante (inclinação da coluna). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Visual")
	FRotator SteeringWheelBaseRotation = FRotator(-20.25f, 0.f, 0.f);

	/** Quanto o volante gira com o input todo para um lado. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Visual", meta = (Units = "Degrees"))
	float SteeringWheelMaxDegrees = 120.f;

	/** Velocidade com que volante e motorista acompanham o input. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Visual")
	float SteerVisualSpeed = 8.f;

	/** Material físico da carroceria (atrito baixo, combina por mínimo): raspa nas paredes sem "grudar". */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls")
	TObjectPtr<UPhysicalMaterial> ChassisPhysMaterial;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls")
	bool bWallScrapeEnabled = true;

	/** Acima deste ângulo (carro x parede) a batida é "de frente": física normal, o carro para. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (Units = "Degrees"))
	float WallScrapeMaxAngle = 35.f;

	/** Fração da velocidade mantida numa batida de raspão a 10 graus. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (ClampMin = "0", ClampMax = "1"))
	float WallScrapeKeepShallow = 0.97f;

	/** Fração da velocidade mantida numa batida a WallScrapeMaxAngle. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (ClampMin = "0", ClampMax = "1"))
	float WallScrapeKeepSteep = 0.85f;

	/** Perda de velocidade por segundo enquanto continua raspando. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (ClampMin = "0"))
	float WallScrapeDragPerSecond = 0.15f;

	/** Força de alinhamento do carro com a parede (graus/s por grau de erro). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (ClampMin = "0"))
	float WallAlignStrength = 3.f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Walls", meta = (Units = "km/h"))
	float WallScrapeMinSpeedKmh = 15.f;

	/** Pontos onde zumbis se agarram (presos ao chassi). Com bAutoPlaceGrabPoints, posicionados no BeginPlay. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Zombies")
	TObjectPtr<USceneComponent> GrabPointHood;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Zombies")
	TObjectPtr<USceneComponent> GrabPointLeft;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Zombies")
	TObjectPtr<USceneComponent> GrabPointRight;

	/** Desligue para posicionar GrabPoint*, SmokeFX e FireFX à mão no BP. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies")
	bool bAutoPlaceGrabPoints = true;

	/** Meia caixa da carroceria (cm, espaço do carro). Recalculada pela malha do chassi no BeginPlay se houver malha. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies")
	FVector BodyHalfExtent = FVector(230.f, 95.f, 80.f);

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies")
	FVector BodyCenter = FVector(0.f, 0.f, 60.f);

	/** Acima desta velocidade os zumbis agarrados caem. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (Units = "km/h"))
	float ShakeOffSpeedKmh = 60.f;

	/** Aceleração lateral (cm/s², velocidade x giro) que derruba os agarrados: curva forte. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0"))
	float ShakeOffLateralAccel = 1000.f;

	/** Batida em algo com impulso acima disto derruba os agarrados (kg·cm/s; ~250000 = batida leve). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0"))
	float ShakeOffImpactImpulse = 250000.f;

	/** Tempo agarrado antes de poder ser sacudido (evita cair no mesmo instante). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (Units = "s"))
	float ShakeOffGraceTime = 0.5f;

	/** Freada forte (desaceleração em cm/s²) derruba os agarrados. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0"))
	float ShakeOffBrakeDecel = 1100.f;

	/** Puxão no volante (fração do volante) por zumbi agarrado na lateral. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0", ClampMax = "0.5"))
	float GrabberSteerPull = 0.08f;

	/** Desaceleração (cm/s²) por zumbi agarrado. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0"))
	float GrabberDeceleration = 120.f;

	/** Máximo de velocidade (fração) que atropelamentos seguidos podem tirar de uma vez. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0", ClampMax = "1"))
	float ZombieDragMaxBurst = 0.3f;

	/** Quanto do teto de freio por atropelamento volta por segundo. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (ClampMin = "0"))
	float ZombieDragRecoveryPerSecond = 0.25f;

	/** Abaixo desta velocidade atropelar não freia mais (a horda nunca para o carro). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Zombies", meta = (Units = "km/h"))
	float ZombieDragMinSpeedKmh = 30.f;

	/** Fumaça e fogo do motor (presos ao chassi, na frente). Ligados por HandleIntegrityChanged. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UNiagaraComponent> SmokeFX;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UNiagaraComponent> FireFX;

	/** Luz laranja do fogo (funciona mesmo sem asset de partícula) e clarão da explosão. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UPointLightComponent> FireLight;

	/** Partículas (Niagara). Vazias = só a luz; tools/unreal/setup_car_zombies.py procura assets. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UNiagaraSystem> SmokeSystem;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UNiagaraSystem> FireSystem;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<UNiagaraSystem> ExplosionSystem;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	TObjectPtr<USoundBase> ExplosionSound;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (ClampMin = "0", ClampMax = "1"))
	float SmokeBelowIntegrity = 0.5f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (ClampMin = "0", ClampMax = "1"))
	float FireBelowIntegrity = 0.25f;

	/** Explosão: raio, dano (barris, objetos) e velocidade de arremesso dos zumbis no centro. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (Units = "cm"))
	float ExplosionRadius = 900.f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	float ExplosionDamage = 400.f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (Units = "cm/s"))
	float ExplosionLaunchSpeed = 2200.f;

	/** "Bomba": sair do carro pegando fogo arma a explosão em CarBombFuseTime segundos (mata zumbis em volta). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	bool bCarBombOnExitWhileBurning = true;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (Units = "s"))
	float CarBombFuseTime = 5.f;

	/** Pegando fogo, o motor queima sozinho (dano por segundo) até explodir. 0 = fogo não piora. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX", meta = (ClampMin = "0"))
	float BurnEngineDamagePerSecond = 1.5f;

	/** No estágio Driving a explosão é falha (volta ao checkpoint). Ligue para sair a pé também nele. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Damage FX")
	bool bEjectOnExplodeWhileDriving = false;

	/** Usada se o herói não tiver DrivingAnim própria (precisa ser do mesmo esqueleto do herói). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Driver")
	TObjectPtr<UAnimSequenceBase> FallbackDrivingAnim;

	/** Quanto da velocidade lateral é removida por segundo com as rodas no chão (0 = desligado). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (ClampMin = "0"))
	float LateralGripAssist = 2.5f;

	/** Fração do LateralGripAssist com o freio de mão puxado (deixa derrapar de propósito). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (ClampMin = "0", ClampMax = "1"))
	float HandbrakeGripScale = 0.2f;

	/** Até esta velocidade o volante gira tudo; acima dela vai reduzindo. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (Units = "km/h"))
	float SteerFullUntilKmh = 50.f;

	/** Velocidade em que o volante chega ao mínimo (SteerAtHighSpeed). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (Units = "km/h"))
	float SteerMinAtKmh = 130.f;

	/** Fração do volante em alta velocidade (evita rodar com toque no teclado). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (ClampMin = "0.1", ClampMax = "1"))
	float SteerAtHighSpeed = 0.65f;

	/** Amortecimento angular do chassi (menos capotagem e pião). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (ClampMin = "0"))
	float ChassisAngularDamping = 1.f;

	/** Distância do traço para considerar o carro "no chão" (a partir da origem do carro). */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Handling", meta = (Units = "cm"))
	float GroundCheckDistance = 140.f;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> ThrottleAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> BrakeAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> SteerAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> HandbrakeAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> LookAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> NitroAction;

	/** Aceleração extra do nitro (cm/s²) e consumo por segundo. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Nitro")
	float NitroAcceleration = 500.f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Nitro")
	float NitroDrainPerSecond = 0.22f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Nitro", meta = (Units = "km/h"))
	float NitroMaxSpeedKmh = 160.f;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle|Nitro")
	float StartingNitro = 0.5f;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> MouseLookAction;

	UPROPERTY(EditDefaultsOnly, Category = "Vehicle", meta = (Units = "s"))
	float SleepDelayAfterPark = 2.f;

	/** Velocidade abaixo da qual o jogador pode descer na zona de transição. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle")
	float ExitMaxSpeedKmh = 4.f;

	/** Tempo máximo freando antes de forçar a parada e descer. */
	UPROPERTY(EditDefaultsOnly, Category = "Vehicle", meta = (Units = "s"))
	float ExitStopTimeout = 3.f;

private:
	void TickStopForExit();

	bool bDriveEnabled = true;
	FTimerHandle SleepTimer;
	FTimerHandle StopExitTimer;
	FTimerHandle NitroTimer;
	float NitroCharge = 0.f;
	bool bNitroActive = false;
	bool bNitroHeld = false;
	bool bHandbrakeHeld = false;
	float LastSteerInput = 0.f;
	float VisualSteer = 0.f;
	double LastScrapeTime = -1.0;
	FTransform PendingExitFallback;
	float StopExitElapsed = 0.f;

	static constexpr int32 NumGrabSlots = 3;
	TWeakObjectPtr<AJREnemyCharacter> Grabbers[NumGrabSlots];
	double GrabStartTime[NumGrabSlots] = { 0.0, 0.0, 0.0 };
	float ZombieDragUsed = 0.f;
	double LastZombieDragTime = 0.0;
	bool bExploded = false;
	bool bSmokeOn = false;
	bool bFireOn = false;
	bool bLoggedMissingFX = false;
	FTimerHandle ExplosionFlashTimer;
	FTimerHandle CarBombTimer;
	FTimerHandle BurnTimer;
	EJRVehicleDamageFXState DamageFXState = EJRVehicleDamageFXState::Intact;
	float PrevForwardSpeed = 0.f;
	float FilteredBrakeDecel = 0.f;
	bool bGrabSteerApplied = false;
};
