// Copyright utrazin. All Rights Reserved.

#include "Vehicles/JRVehiclePawn.h"
#include "AI/JREnemyCharacter.h"
#include "Animation/AnimSequenceBase.h"
#include "Camera/CameraComponent.h"
#include "ChaosVehicleMovementComponent.h"
#include "Characters/JRCharacter.h"
#include "Characters/JRCharacterDefinition.h"
#include "CollisionQueryParams.h"
#include "Components/PointLightComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Core/JRGameMode.h"
#include "Core/JRPlayerController.h"
#include "EnhancedInputComponent.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "JogoResgate.h"
#include "Materials/MaterialInterface.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "GameFramework/SpringArmComponent.h"
#include "InputActionValue.h"
#include "Kismet/GameplayStatics.h"
#include "Levels/JRObjectiveSubsystem.h"
#include "NiagaraComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "TimerManager.h"
#include "UI/JRHUD.h"
#include "Vehicles/JRVehicleDamageComponent.h"

AJRVehiclePawn::AJRVehiclePawn()
{
	// Tick só para a ajuda de aderência (física precisa de força a cada frame).
	PrimaryActorTick.bCanEverTick = true;

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(GetMesh());
	// Origem do braço acima do chão: evita a câmera "afundar" quando o traço de colisão nasce no terreno.
	SpringArm->SetRelativeLocation(FVector(0.f, 0.f, 200.f));
	SpringArm->TargetArmLength = 900.f;
	SpringArm->SocketOffset = FVector(0.f, 0.f, 120.f);
	SpringArm->bUsePawnControlRotation = true;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 8.f;

	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);

	auto MakeVisual = [this](const TCHAR* Name, FName Socket) -> UStaticMeshComponent*
	{
		UStaticMeshComponent* Comp = CreateDefaultSubobject<UStaticMeshComponent>(Name);
		Comp->SetupAttachment(GetMesh(), Socket);
		Comp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		Comp->SetCanEverAffectNavigation(false);
		return Comp;
	};
	ChassisMesh = MakeVisual(TEXT("ChassisMesh"), NAME_None);
	TireFL = MakeVisual(TEXT("TireFL"), TEXT("VisWheel_FL"));
	TireFR = MakeVisual(TEXT("TireFR"), TEXT("VisWheel_FR"));
	TireBL = MakeVisual(TEXT("TireBL"), TEXT("VisWheel_BL"));
	TireBR = MakeVisual(TEXT("TireBR"), TEXT("VisWheel_BR"));

	// Volante separado, preso à carroceria. Posição em cm no espaço da malha SM_Car_AlienBuggy
	// (tools/blender/make_car_buggy.py: WHEEL_C = 0,08 / 0 / 1,165 m); a escala do chassi vale para ele.
	SteeringWheelMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("SteeringWheelMesh"));
	SteeringWheelMesh->SetupAttachment(ChassisMesh);
	SteeringWheelMesh->SetRelativeLocation(FVector(8.f, 0.f, 116.5f));
	SteeringWheelMesh->SetRelativeRotation(SteeringWheelBaseRotation);
	SteeringWheelMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	SteeringWheelMesh->SetCanEverAffectNavigation(false);

	ExitPoint = CreateDefaultSubobject<USceneComponent>(TEXT("ExitPoint"));
	ExitPoint->SetupAttachment(GetMesh());
	ExitPoint->SetRelativeLocation(FVector(0.f, -320.f, 120.f)); // longe o bastante do Offroad (largo)

	SeatPoint = CreateDefaultSubobject<USceneComponent>(TEXT("SeatPoint"));
	SeatPoint->SetupAttachment(GetMesh());
	SeatPoint->SetRelativeLocation(FVector(-25.5f, 0.f, 64.5f)); // banco central do buggy (assento x 0,849)

	// Motorista só visual, no banco central do buggy. DriverPivot = quadril (cm no espaço da malha do buggy):
	// assento em z 76, quadril 12 acima; 7,6 para a esquerda centraliza as mãos no volante.
	DriverPivot = CreateDefaultSubobject<USceneComponent>(TEXT("DriverPivot"));
	DriverPivot->SetupAttachment(ChassisMesh);
	DriverPivot->SetRelativeLocation(FVector(-30.f, -7.6f, 88.f));

	// Na pose "Driving" o quadril fica ~62,6 cm acima dos pés (herói de ~1,7 m) = 73,8 na escala do chassi (0,849).
	// Escala de mundo 1 (igual ao herói a pé). Herói UE5 olha para +Y, por isso yaw -90.
	DriverMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("DriverMesh"));
	DriverMesh->SetupAttachment(DriverPivot);
	DriverMesh->SetRelativeLocation(FVector(0.f, 0.f, -73.8f));
	DriverMesh->SetRelativeRotation(FRotator(0.f, -90.f, 0.f));
	DriverMesh->SetUsingAbsoluteScale(true);
	DriverMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	DriverMesh->SetGenerateOverlapEvents(false);
	DriverMesh->SetCanEverAffectNavigation(false);
	DriverMesh->SetHiddenInGame(true);

	DamageComponent = CreateDefaultSubobject<UJRVehicleDamageComponent>(TEXT("DamageComponent"));

	// Pontos de agarre dos zumbis (presos ao chassi). Valores iniciais; o BeginPlay recalcula pela malha.
	// O eixo X de cada ponto aponta para dentro do carro (o zumbi olha para a cabine).
	auto MakeGrabPoint = [this](const TCHAR* Name, const FVector& Location, float Yaw) -> USceneComponent*
	{
		USceneComponent* Point = CreateDefaultSubobject<USceneComponent>(Name);
		Point->SetupAttachment(ChassisMesh);
		Point->SetRelativeLocationAndRotation(Location, FRotator(0.f, Yaw, 0.f));
		return Point;
	};
	GrabPointHood = MakeGrabPoint(TEXT("GrabPointHood"), FVector(170.f, 0.f, 150.f), 180.f);
	GrabPointLeft = MakeGrabPoint(TEXT("GrabPointLeft"), FVector(-20.f, -150.f, 110.f), 90.f);
	GrabPointRight = MakeGrabPoint(TEXT("GrabPointRight"), FVector(-20.f, 150.f, 110.f), -90.f);

	// Fumaça e fogo do motor (desligados até a integridade cair).
	SmokeFX = CreateDefaultSubobject<UNiagaraComponent>(TEXT("SmokeFX"));
	SmokeFX->SetupAttachment(ChassisMesh);
	SmokeFX->SetRelativeLocation(FVector(160.f, 0.f, 110.f));
	SmokeFX->SetAutoActivate(false);
	FireFX = CreateDefaultSubobject<UNiagaraComponent>(TEXT("FireFX"));
	FireFX->SetupAttachment(ChassisMesh);
	FireFX->SetRelativeLocation(FVector(160.f, 0.f, 100.f));
	FireFX->SetAutoActivate(false);
	FireLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("FireLight"));
	FireLight->SetupAttachment(ChassisMesh);
	FireLight->SetRelativeLocation(FVector(160.f, 0.f, 140.f));
	FireLight->SetLightColor(FLinearColor(1.f, 0.45f, 0.1f));
	FireLight->SetIntensity(8000.f);
	FireLight->SetAttenuationRadius(600.f);
	FireLight->SetCastShadows(false);
	FireLight->SetVisibility(false);

	// Necessário para disparar AJRCheckpoint e outros gatilhos (malha esquelética vem desligada).
	GetMesh()->SetGenerateOverlapEvents(true);
}

void AJRVehiclePawn::BeginPlay()
{
	Super::BeginPlay();
	DamageComponent->OnVehicleDisabled.AddDynamic(this, &AJRVehiclePawn::HandleVehicleDisabled);
	DamageComponent->OnIntegrityChanged.AddDynamic(this, &AJRVehiclePawn::HandleIntegrityChanged);
	PlaceBodyPointsFromChassis();
	if (SmokeSystem)
	{
		SmokeFX->SetAsset(SmokeSystem);
	}
	if (FireSystem)
	{
		FireFX->SetAsset(FireSystem);
	}
	NitroCharge = StartingNitro;
	GetWorldTimerManager().SetTimer(NitroTimer, this, &AJRVehiclePawn::TickNitro, 0.05f, true);

	// Só o corpo físico do esqueleto colide. Carroceria e pneus são enfeite (evita "agarrar" em rampas e paredes).
	UStaticMeshComponent* Visuals[] = { ChassisMesh, TireFL, TireFR, TireBL, TireBR, SteeringWheelMesh };
	for (UStaticMeshComponent* Visual : Visuals)
	{
		if (Visual)
		{
			Visual->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}
	}
	// CCD: em alta velocidade (nitro) o chassi não atravessa rampas e paredes finas.
	GetMesh()->SetUseCCD(true);
	GetMesh()->SetAngularDamping(ChassisAngularDamping);
	// Atrito baixo na carroceria: raspa nas paredes em vez de grudar.
	if (ChassisPhysMaterial)
	{
		GetMesh()->SetPhysMaterialOverride(ChassisPhysMaterial);
	}
	GetMesh()->SetNotifyRigidBodyCollision(true);
	OnActorHit.AddDynamic(this, &AJRVehiclePawn::HandleVehicleHit);
	if (IsPlayerControlled())
	{
		RefreshDriver();
	}
}

void AJRVehiclePawn::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	ApplyGripAssist(DeltaSeconds);
	if (bNitroActive)
	{
		// Empurrão para frente a cada frame (independente da massa).
		GetMesh()->AddForce(GetActorForwardVector() * NitroAcceleration, NAME_None, true);
	}
	UpdateSteeringVisuals(DeltaSeconds);
	TickGrabbers(DeltaSeconds);
}

void AJRVehiclePawn::PlaceBodyPointsFromChassis()
{
	const UStaticMesh* ChassisAsset = ChassisMesh ? ChassisMesh->GetStaticMesh() : nullptr;
	if (!ChassisAsset)
	{
		return; // sem malha: ficam os valores do BP
	}
	// Caixa da carroceria no espaço do carro (usada para distância/contato dos zumbis).
	const FTransform ChassisToActor = ChassisMesh->GetComponentTransform().GetRelativeTransform(GetActorTransform());
	const FBoxSphereBounds ActorSpace = ChassisMesh->CalcBounds(ChassisToActor);
	BodyCenter = ActorSpace.Origin;
	BodyHalfExtent = ActorSpace.BoxExtent;
	if (!bAutoPlaceGrabPoints)
	{
		return;
	}
	// Pontos no espaço da malha do chassi (a escala do chassi vale para eles).
	const FBox Box = ChassisAsset->GetBoundingBox();
	const FVector Center = Box.GetCenter();
	const float Scale = FMath::Max(static_cast<float>(ChassisMesh->GetComponentScale().Z), 0.01f);
	const float HalfCapsule = 88.f / Scale; // a origem do zumbi é o meio da cápsula
	const double HoodX = FMath::Lerp(Center.X, Box.Max.X, 0.55);
	const double HoodTopZ = FMath::Lerp(Box.Min.Z, Box.Max.Z, 0.45);
	GrabPointHood->SetRelativeLocation(FVector(HoodX, Center.Y, HoodTopZ + HalfCapsule * 0.55f));
	const double SideX = Center.X - (Box.Max.X - Box.Min.X) * 0.1;
	const double SideZ = Box.Min.Z + HalfCapsule + 20.f / Scale;
	GrabPointLeft->SetRelativeLocation(FVector(SideX, Box.Min.Y - 20.f / Scale, SideZ));
	GrabPointRight->SetRelativeLocation(FVector(SideX, Box.Max.Y + 20.f / Scale, SideZ));
	const FVector EnginePoint(HoodX, Center.Y, HoodTopZ);
	SmokeFX->SetRelativeLocation(EnginePoint);
	FireFX->SetRelativeLocation(EnginePoint);
	FireLight->SetRelativeLocation(EnginePoint + FVector(0.f, 0.f, 40.f / Scale));
}

float AJRVehiclePawn::GetDistanceToBody(const FVector& WorldPoint, FVector* OutClosestPoint) const
{
	const FTransform& ActorTransform = GetActorTransform();
	const FVector Local = ActorTransform.InverseTransformPosition(WorldPoint) - BodyCenter;
	const FVector Clamped(
		FMath::Clamp(Local.X, -BodyHalfExtent.X, BodyHalfExtent.X),
		FMath::Clamp(Local.Y, -BodyHalfExtent.Y, BodyHalfExtent.Y),
		FMath::Clamp(Local.Z, -BodyHalfExtent.Z, BodyHalfExtent.Z));
	if (OutClosestPoint)
	{
		*OutClosestPoint = ActorTransform.TransformPosition(Clamped + BodyCenter);
	}
	return static_cast<float>(FVector::Dist(Local, Clamped));
}

USceneComponent* AJRVehiclePawn::GetGrabPoint(int32 Slot) const
{
	switch (Slot)
	{
	case 0: return GrabPointHood;
	case 1: return GrabPointLeft;
	case 2: return GrabPointRight;
	default: return nullptr;
	}
}

EJRVehicleZone AJRVehiclePawn::GetGrabZone(int32 Slot) const
{
	switch (Slot)
	{
	case 1: return EJRVehicleZone::Left;
	case 2: return EJRVehicleZone::Right;
	default: return EJRVehicleZone::Front;
	}
}

int32 AJRVehiclePawn::GetGrabberCount() const
{
	int32 Count = 0;
	for (const TWeakObjectPtr<AJREnemyCharacter>& Grabber : Grabbers)
	{
		Count += Grabber.IsValid() ? 1 : 0;
	}
	return Count;
}

int32 AJRVehiclePawn::TryReserveGrabSlot(AJREnemyCharacter* Zombie)
{
	if (!Zombie || bExploded || FMath::Abs(GetSpeedKmh()) > GrabMaxSpeedKmh)
	{
		return INDEX_NONE;
	}
	// Só pela frente e pelos lados: atrás do carro não há onde se segurar.
	const FVector ZombieLocal = GetActorTransform().InverseTransformPosition(Zombie->GetActorLocation()) - BodyCenter;
	if (ZombieLocal.X < -BodyHalfExtent.X * 0.6)
	{
		return INDEX_NONE;
	}
	int32 Best = INDEX_NONE;
	double BestDistSq = FMath::Square(450.0); // não "teletransporta" o zumbi para o outro lado do carro
	for (int32 Slot = 0; Slot < NumGrabSlots; ++Slot)
	{
		if (Grabbers[Slot].IsValid() && !Grabbers[Slot]->IsDead())
		{
			continue;
		}
		const USceneComponent* Point = GetGrabPoint(Slot);
		const double DistSq = Point ? FVector::DistSquared(Point->GetComponentLocation(), Zombie->GetActorLocation()) : TNumericLimits<double>::Max();
		if (DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = Slot;
		}
	}
	if (Best != INDEX_NONE)
	{
		Grabbers[Best] = Zombie;
		GrabStartTime[Best] = GetWorld()->GetTimeSeconds();
		if (IsPlayerControlled() && GetGrabberCount() == 1)
		{
			AJRHUD::Toast(this, TEXT("Zumbi no carro! Vire forte ou freie para derrubar."), FLinearColor(1.f, 0.7f, 0.2f));
		}
	}
	return Best;
}

void AJRVehiclePawn::ReleaseGrabSlot(AJREnemyCharacter* Zombie)
{
	for (TWeakObjectPtr<AJREnemyCharacter>& Grabber : Grabbers)
	{
		if (Grabber.Get() == Zombie)
		{
			Grabber.Reset();
		}
	}
}

void AJRVehiclePawn::ReleaseAllGrabbers(bool bKill)
{
	// Cópia: cada zumbi libera o próprio ponto durante o laço.
	TArray<AJREnemyCharacter*> Current;
	for (const TWeakObjectPtr<AJREnemyCharacter>& Grabber : Grabbers)
	{
		if (AJREnemyCharacter* Zombie = Grabber.Get())
		{
			Current.Add(Zombie);
		}
	}
	const FVector CarVelocity = GetVelocity();
	for (AJREnemyCharacter* Zombie : Current)
	{
		const FVector Out = (Zombie->GetActorLocation() - GetActorLocation()).GetSafeNormal2D();
		const FVector Launch = CarVelocity * 0.8f + Out * 700.f + FVector(0.f, 0.f, 400.f);
		Zombie->ReleaseFromVehicle(bKill, Launch);
	}
	for (TWeakObjectPtr<AJREnemyCharacter>& Grabber : Grabbers)
	{
		Grabber.Reset();
	}
}

void AJRVehiclePawn::TickGrabbers(float DeltaSeconds)
{
	if (!GetMesh()->IsSimulatingPhysics())
	{
		return;
	}
	const FVector Velocity = GetMesh()->GetPhysicsLinearVelocity();
	// Desaceleração para frente (suavizada: a física oscila de um frame para o outro).
	const float ForwardSpeed = static_cast<float>(FVector::DotProduct(Velocity, GetActorForwardVector()));
	const float RawDecel = DeltaSeconds > KINDA_SMALL_NUMBER ? (FMath::Abs(PrevForwardSpeed) - FMath::Abs(ForwardSpeed)) / DeltaSeconds : 0.f;
	FilteredBrakeDecel = FMath::Lerp(FilteredBrakeDecel, RawDecel, 0.5f);
	PrevForwardSpeed = ForwardSpeed;

	const int32 Count = GetGrabberCount();
	if (Count == 0)
	{
		if (bGrabSteerApplied)
		{
			// O último caiu: volante volta ao normal sem esperar o próximo input.
			bGrabSteerApplied = false;
			if (bDriveEnabled)
			{
				GetVehicleMovementComponent()->SetSteeringInput(ComputeSteering(LastSteerInput));
			}
		}
		return;
	}
	const float Kmh = static_cast<float>(Velocity.Size()) * 0.036f;
	const float YawRate = FMath::DegreesToRadians(FMath::Abs(static_cast<float>(GetMesh()->GetPhysicsAngularVelocityInDegrees().Z)));
	const float LateralAccel = YawRate * static_cast<float>(Velocity.Size2D());
	const bool bHardBrake = FilteredBrakeDecel > ShakeOffBrakeDecel && Kmh > 8.f;
	const double Now = GetWorld()->GetTimeSeconds();
	if (Kmh > ShakeOffSpeedKmh || LateralAccel > ShakeOffLateralAccel || bHardBrake)
	{
		// Só cai quem já está agarrado há um tempinho.
		TArray<AJREnemyCharacter*> Shaken;
		for (int32 Slot = 0; Slot < NumGrabSlots; ++Slot)
		{
			if (Grabbers[Slot].IsValid() && Now - GrabStartTime[Slot] >= ShakeOffGraceTime)
			{
				Shaken.Add(Grabbers[Slot].Get());
			}
		}
		for (AJREnemyCharacter* Zombie : Shaken)
		{
			const FVector Out = (Zombie->GetActorLocation() - GetActorLocation()).GetSafeNormal2D();
			// Freada: o zumbi do capô voa para frente (inércia); curva: voa para fora.
			const FVector Inertia = bHardBrake ? GetActorForwardVector() * 500.f : FVector::ZeroVector;
			Zombie->ReleaseFromVehicle(true, Velocity * 0.8f + Out * 700.f + Inertia + FVector(0.f, 0.f, 400.f));
		}
		if (Shaken.Num() > 0)
		{
			UE_LOG(LogJR, Log, TEXT("%s: %d zumbi(s) sacudido(s) (%.0f km/h, lateral %.0f, freada %.0f)"), *GetName(), Shaken.Num(),
				Kmh, LateralAccel, FilteredBrakeDecel);
		}
		return;
	}
	// O peso dos zumbis segura o carro (só andando).
	if (Kmh > 5.f)
	{
		const FVector Back = -Velocity.GetSafeNormal2D();
		GetMesh()->AddForce(Back * (GrabberDeceleration * Count), NAME_None, true);
	}
	// E puxam o volante (o jogador sente o carro "torto").
	if (bDriveEnabled && IsPlayerControlled())
	{
		GetVehicleMovementComponent()->SetSteeringInput(ComputeSteering(LastSteerInput));
		bGrabSteerApplied = true;
	}
}

float AJRVehiclePawn::GetGrabSteerBias() const
{
	float Bias = 0.f;
	if (Grabbers[1].IsValid())
	{
		Bias -= GrabberSteerPull; // esquerda puxa para a esquerda
	}
	if (Grabbers[2].IsValid())
	{
		Bias += GrabberSteerPull;
	}
	if (Grabbers[0].IsValid())
	{
		// No capô: balança de um lado para o outro.
		const UWorld* World = GetWorld();
		const float Time = World ? static_cast<float>(World->GetTimeSeconds()) : 0.f;
		Bias += FMath::Sin(Time * 2.3f) * GrabberSteerPull * 0.6f;
	}
	return Bias;
}

float AJRVehiclePawn::ComputeSteering(float RawInput) const
{
	// Menos volante em alta velocidade: toque no teclado não vira pião.
	const float Speed = FMath::Abs(GetSpeedKmh());
	const float Alpha = FMath::Clamp((Speed - SteerFullUntilKmh) / FMath::Max(SteerMinAtKmh - SteerFullUntilKmh, 1.f), 0.f, 1.f);
	const float SteerScale = FMath::Lerp(1.f, SteerAtHighSpeed, Alpha);
	return FMath::Clamp(RawInput * SteerScale + DamageComponent->GetSteeringBias() + GetGrabSteerBias(), -1.f, 1.f);
}

void AJRVehiclePawn::NotifyZombieCarEvent(EJRZombieCarEvent Event, AActor* Zombie, FVector Location, float Value)
{
	OnZombieCarEvent.Broadcast(Event, Zombie, Location, Value);
	BP_OnZombieCarEvent(Event, Zombie, Location, Value);
}

bool AJRVehiclePawn::IsCarBombArmed() const
{
	return GetWorldTimerManager().IsTimerActive(CarBombTimer);
}

void AJRVehiclePawn::ApplyZombieDrag(float Fraction)
{
	const double Now = GetWorld()->GetTimeSeconds();
	ZombieDragUsed = FMath::Max(0.f, ZombieDragUsed - static_cast<float>(Now - LastZombieDragTime) * ZombieDragRecoveryPerSecond);
	LastZombieDragTime = Now;
	const float Allowed = FMath::Clamp(FMath::Min(Fraction, ZombieDragMaxBurst - ZombieDragUsed), 0.f, 1.f);
	if (Allowed <= 0.f || FMath::Abs(GetSpeedKmh()) < ZombieDragMinSpeedKmh || !GetMesh()->IsSimulatingPhysics())
	{
		return;
	}
	ZombieDragUsed += Allowed;
	GetMesh()->SetPhysicsLinearVelocity(GetMesh()->GetPhysicsLinearVelocity() * (1.f - Allowed));
}

void AJRVehiclePawn::HandleIntegrityChanged(float Integrity)
{
	const bool bWantSmoke = Integrity < SmokeBelowIntegrity;
	const bool bWantFire = Integrity < FireBelowIntegrity || bExploded;
	if (!bLoggedMissingFX && (bWantSmoke || bWantFire) && (!SmokeSystem || !FireSystem))
	{
		bLoggedMissingFX = true;
		UE_LOG(LogJR, Warning, TEXT("%s: sem SmokeSystem/FireSystem (Niagara) no BP; só a luz do fogo aparece. Rode tools/unreal/setup_car_zombies.py."), *GetName());
	}
	if (bWantSmoke != bSmokeOn)
	{
		bSmokeOn = bWantSmoke;
		if (bSmokeOn)
		{
			SmokeFX->Activate(true);
			if (IsPlayerControlled())
			{
				AJRHUD::Toast(this, TEXT("O carro está soltando fumaça!"), FLinearColor(1.f, 0.8f, 0.2f));
			}
		}
		else
		{
			SmokeFX->Deactivate();
		}
	}
	const EJRVehicleDamageFXState NewState = bExploded ? EJRVehicleDamageFXState::Wrecked
		: bWantFire ? EJRVehicleDamageFXState::Burning
		: bWantSmoke ? EJRVehicleDamageFXState::Smoking
		: EJRVehicleDamageFXState::Intact;
	if (NewState != DamageFXState)
	{
		DamageFXState = NewState;
		UE_LOG(LogJR, Log, TEXT("%s: estado de dano %s (integridade %.0f%%)"), *GetName(), *UEnum::GetValueAsString(NewState), Integrity * 100.f);
		OnDamageStateChanged(NewState);
		OnDamageFXStateChanged.Broadcast(NewState);
	}
	if (bWantFire != bFireOn)
	{
		bFireOn = bWantFire;
		FireLight->SetVisibility(bFireOn);
		if (bFireOn && !bExploded && BurnEngineDamagePerSecond > 0.f)
		{
			GetWorldTimerManager().SetTimer(BurnTimer, this, &AJRVehiclePawn::TickBurn, 1.f, true);
		}
		else
		{
			GetWorldTimerManager().ClearTimer(BurnTimer);
		}
		if (bFireOn)
		{
			FireFX->Activate(true);
			if (IsPlayerControlled() && !bExploded)
			{
				AJRHUD::Toast(this, TEXT("O carro pegou fogo! Vai explodir!"), FLinearColor(1.f, 0.3f, 0.1f));
			}
		}
		else
		{
			FireFX->Deactivate();
		}
	}
}

void AJRVehiclePawn::Explode()
{
	if (bExploded)
	{
		return;
	}
	bExploded = true;
	bDriveEnabled = false;
	GetWorldTimerManager().ClearTimer(CarBombTimer);
	GetWorldTimerManager().ClearTimer(BurnTimer);
	ZeroInputs(true);
	const FVector Origin = GetActorLocation();
	UE_LOG(LogJR, Log, TEXT("%s explodiu"), *GetName());
	NotifyZombieCarEvent(EJRZombieCarEvent::Explosion, nullptr, Origin, ExplosionRadius);

	// Quem estava agarrado voa junto.
	ReleaseAllGrabbers(true);

	if (ExplosionSystem)
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(this, ExplosionSystem, Origin);
	}
	if (ExplosionSound)
	{
		UGameplayStatics::PlaySoundAtLocation(this, ExplosionSound, Origin);
	}
	// Clarão (funciona mesmo sem partícula) e o carro fica queimando.
	FireLight->SetVisibility(true);
	FireLight->SetIntensity(400000.f);
	FireLight->SetAttenuationRadius(ExplosionRadius * 2.f);
	GetWorldTimerManager().SetTimer(ExplosionFlashTimer, this, &AJRVehiclePawn::EndExplosionFlash, 0.25f, false);
	HandleIntegrityChanged(0.f);
	// Empurrão do próprio carro (pula um pouco com a explosão).
	if (GetMesh()->IsSimulatingPhysics())
	{
		GetMesh()->WakeAllRigidBodies();
		GetMesh()->AddImpulse(FVector(0.f, 0.f, 450.f), NAME_None, true);
	}

	// "Bomba": zumbis no raio morrem arremessados (mais forte perto do centro).
	AController* InstigatorController = GetController();
	for (TActorIterator<AJREnemyCharacter> It(GetWorld()); It; ++It)
	{
		AJREnemyCharacter* Enemy = *It;
		if (!Enemy || Enemy->IsDead())
		{
			continue;
		}
		const FVector Offset = Enemy->GetActorLocation() - Origin;
		const float Dist = static_cast<float>(Offset.Size());
		if (Dist > ExplosionRadius)
		{
			continue;
		}
		const float Alpha = 1.f - Dist / FMath::Max(ExplosionRadius, 1.f);
		const FVector Launch = Offset.GetSafeNormal2D() * (ExplosionLaunchSpeed * (0.4f + 0.6f * Alpha))
			+ FVector(0.f, 0.f, ExplosionLaunchSpeed * (0.3f + 0.4f * Alpha));
		Enemy->KillWithLaunch(Launch, InstigatorController, this);
	}
	// Barris, caixas e outros alvos com dano.
	TArray<AActor*> Ignore;
	Ignore.Add(this);
	UGameplayStatics::ApplyRadialDamageWithFalloff(this, ExplosionDamage, ExplosionDamage * 0.1f, Origin,
		ExplosionRadius * 0.4f, ExplosionRadius, 1.f, nullptr, Ignore, this, InstigatorController);

	if (!IsPlayerControlled())
	{
		return;
	}
	const UJRObjectiveSubsystem* Objective = GetWorld()->GetSubsystem<UJRObjectiveSubsystem>();
	const bool bDrivingStage = Objective && Objective->GetStage() == EJRLevelStage::Driving;
	AJRPlayerController* PC = Cast<AJRPlayerController>(GetController());
	if (PC && (!bDrivingStage || bEjectOnExplodeWhileDriving))
	{
		AJRHUD::Toast(this, TEXT("O carro explodiu! Continue a pé."), FLinearColor(1.f, 0.4f, 0.1f));
		PC->RequestExitVehicle(GetExitTransform());
	}
	else if (AJRGameMode* GameMode = GetWorld()->GetAuthGameMode<AJRGameMode>())
	{
		AJRHUD::Toast(this, TEXT("O carro explodiu!"), FLinearColor(1.f, 0.3f, 0.1f));
		GameMode->HandlePlayerFailure(this);
	}
}

void AJRVehiclePawn::TickBurn()
{
	if (bExploded || !bFireOn)
	{
		GetWorldTimerManager().ClearTimer(BurnTimer);
		return;
	}
	DamageComponent->ApplyZoneDamage(EJRVehicleZone::Engine, BurnEngineDamagePerSecond);
}

void AJRVehiclePawn::EndExplosionFlash()
{
	FireLight->SetIntensity(8000.f);
	FireLight->SetAttenuationRadius(600.f);
}

void AJRVehiclePawn::UpdateSteeringVisuals(float DeltaSeconds)
{
	const float Target = bDriveEnabled ? LastSteerInput : 0.f;
	VisualSteer = FMath::FInterpTo(VisualSteer, Target, DeltaSeconds, SteerVisualSpeed);
	// Roll gira em volta do eixo local X do volante (aplicado antes da inclinação da coluna).
	SteeringWheelMesh->SetRelativeRotation(FRotator(SteeringWheelBaseRotation.Pitch, SteeringWheelBaseRotation.Yaw,
		SteeringWheelBaseRotation.Roll + VisualSteer * SteeringWheelMaxDegrees));
	// Motorista inclina e vira o tronco para dentro da curva (gira no quadril).
	DriverPivot->SetRelativeRotation(FRotator(0.f, VisualSteer * DriverYawDegrees, VisualSteer * DriverLeanDegrees));
}

void AJRVehiclePawn::HandleVehicleHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	// Batida forte em algo (não zumbi) derruba quem está agarrado.
	if (GetGrabberCount() > 0 && !(OtherActor && OtherActor->IsA<APawn>()) && NormalImpulse.Size() > ShakeOffImpactImpulse)
	{
		ReleaseAllGrabbers(true);
	}
	if (!bWallScrapeEnabled || !bDriveEnabled || !GetMesh()->IsSimulatingPhysics())
	{
		return;
	}
	// Zumbis e objetos soltos (barris, caixas) seguem a física normal.
	if (OtherActor && OtherActor->IsA<APawn>())
	{
		return;
	}
	const UPrimitiveComponent* OtherComp = Hit.GetComponent();
	if (OtherComp && OtherComp->IsSimulatingPhysics())
	{
		return;
	}
	FVector WallNormal = Hit.ImpactNormal;
	if (FMath::Abs(WallNormal.Z) > 0.5)
	{
		return; // chão, rampa ou teto: não é parede
	}
	WallNormal.Z = 0.0;
	if (!WallNormal.Normalize())
	{
		return;
	}
	const FVector Velocity = GetMesh()->GetPhysicsLinearVelocity();
	const FVector Flat(Velocity.X, Velocity.Y, 0.0);
	const double FlatSpeed = Flat.Size();
	if (FlatSpeed * 0.036 < WallScrapeMinSpeedKmh)
	{
		return;
	}
	if (FVector::DotProduct(Flat, WallNormal) > 0.0)
	{
		WallNormal = -WallNormal; // agora aponta da parede para o carro
	}
	const double Into = -FVector::DotProduct(Flat, WallNormal);
	const float AngleDeg = FMath::RadiansToDegrees(FMath::Asin(static_cast<float>(FMath::Clamp(Into / FlatSpeed, 0.0, 1.0))));
	if (AngleDeg > WallScrapeMaxAngle)
	{
		return; // quase de frente: a batida para o carro (física normal)
	}
	const double Now = GetWorld()->GetTimeSeconds();
	const bool bNewImpact = Now - LastScrapeTime > 0.25;
	float Keep = 1.f;
	if (bNewImpact)
	{
		const float Alpha = FMath::Clamp((AngleDeg - 10.f) / FMath::Max(WallScrapeMaxAngle - 10.f, 1.f), 0.f, 1.f);
		Keep = FMath::Lerp(WallScrapeKeepShallow, WallScrapeKeepSteep, Alpha);
	}
	else
	{
		Keep = 1.f - WallScrapeDragPerSecond * static_cast<float>(FMath::Min(Now - LastScrapeTime, 0.1));
	}
	LastScrapeTime = Now;

	// Tira só a parte da velocidade que entra na parede; o resto segue junto ao muro.
	const FVector Tangent = Flat + WallNormal * Into;
	FVector NewVelocity = Tangent * Keep + WallNormal * 30.0;
	NewVelocity.Z = Velocity.Z;
	GetMesh()->SetPhysicsLinearVelocity(NewVelocity);

	// Alinha o carro com a parede (só andando para frente).
	const FVector Forward = GetActorForwardVector();
	if (FVector::DotProduct(Forward, Tangent) > 0.0)
	{
		const float YawError = FMath::FindDeltaAngleDegrees(static_cast<float>(Forward.Rotation().Yaw), static_cast<float>(Tangent.Rotation().Yaw));
		FVector Angular = GetMesh()->GetPhysicsAngularVelocityInDegrees();
		Angular.Z = FMath::Clamp(YawError * WallAlignStrength, -90.f, 90.f);
		GetMesh()->SetPhysicsAngularVelocityInDegrees(Angular);
	}
	if (bNewImpact)
	{
		UE_LOG(LogJR, Verbose, TEXT("%s: raspão na parede a %.0f graus, %.0f km/h"), *GetName(), AngleDeg, FlatSpeed * 0.036);
		OnWallScrape(Hit.ImpactPoint, static_cast<float>(FlatSpeed * 0.036), AngleDeg);
	}
}

bool AJRVehiclePawn::IsNearGround() const
{
	const FVector Up = GetActorUpVector();
	const FVector Start = GetActorLocation() + Up * 50.f;
	const FVector End = Start - Up * (GroundCheckDistance + 50.f);
	FCollisionQueryParams Params(SCENE_QUERY_STAT(JRVehicleGround), false, this);
	FCollisionObjectQueryParams ObjectParams;
	ObjectParams.AddObjectTypesToQuery(ECC_WorldStatic);
	ObjectParams.AddObjectTypesToQuery(ECC_WorldDynamic);
	FHitResult Hit;
	return GetWorld()->LineTraceSingleByObjectType(Hit, Start, End, ObjectParams, Params);
}

void AJRVehiclePawn::ApplyGripAssist(float DeltaSeconds)
{
	if (!bDriveEnabled || LateralGripAssist <= 0.f || !IsPlayerControlled() || !GetMesh()->IsSimulatingPhysics())
	{
		return;
	}
	if (!IsNearGround())
	{
		return; // no ar o carro voa livre
	}
	const FVector Right = GetActorRightVector();
	const double Lateral = FVector::DotProduct(GetMesh()->GetPhysicsLinearVelocity(), Right);
	const float Scale = bHandbrakeHeld ? HandbrakeGripScale : 1.f;
	// Limitado para nunca inverter a derrapagem num único frame.
	const float Rate = FMath::Min(LateralGripAssist * Scale, 1.f / FMath::Max(DeltaSeconds, 0.001f));
	GetMesh()->AddForce(-Right * (Lateral * Rate), NAME_None, true);
}

void AJRVehiclePawn::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);
	if (NewController && NewController->IsPlayerController())
	{
		RefreshDriver();
		if (GetWorldTimerManager().IsTimerActive(CarBombTimer))
		{
			// Voltou para o carro: desarma (continua pegando fogo).
			GetWorldTimerManager().ClearTimer(CarBombTimer);
			AJRHUD::Toast(this, TEXT("Bomba desarmada (o carro continua pegando fogo)."), FLinearColor(1.f, 0.8f, 0.2f));
		}
	}
}

void AJRVehiclePawn::SetDriverVisible(bool bVisible)
{
	DriverMesh->SetHiddenInGame(!bVisible);
	DriverMesh->SetComponentTickEnabled(bVisible);
}

void AJRVehiclePawn::RefreshDriver()
{
	UWorld* World = GetWorld();
	AJRGameMode* GameMode = World ? World->GetAuthGameMode<AJRGameMode>() : nullptr;
	USkeletalMesh* HeroMesh = nullptr;
	UAnimSequenceBase* DriveAnim = FallbackDrivingAnim;
	const AJRCharacter* HeroDefaults = nullptr;
	if (GameMode)
	{
		TSubclassOf<AJRCharacter> HeroClass = GameMode->ResolveCharacterClass();
		if (HeroClass)
		{
			HeroDefaults = GetDefault<AJRCharacter>(HeroClass);
		}
	}
	if (HeroDefaults)
	{
		if (HeroDefaults->GetDrivingAnim())
		{
			DriveAnim = HeroDefaults->GetDrivingAnim();
		}
		if (HeroDefaults->GetMesh())
		{
			HeroMesh = HeroDefaults->GetMesh()->GetSkeletalMeshAsset();
		}
	}
	const FJRSkinDefinition* Skin = GameMode ? GameMode->ResolveSelectedSkin() : nullptr;
	if (Skin)
	{
		if (USkeletalMesh* SkinMesh = Skin->Mesh.LoadSynchronous())
		{
			HeroMesh = SkinMesh;
		}
	}
	if (!HeroMesh || !DriveAnim)
	{
		UE_LOG(LogJR, Warning, TEXT("%s: motorista escondido (malha=%s, animação=%s). Rode tools/unreal/fix_vehicle_feel.py."),
			*GetName(), *GetNameSafe(HeroMesh), *GetNameSafe(DriveAnim));
		SetDriverVisible(false);
		return;
	}
	if (DriveAnim->GetSkeleton() != HeroMesh->GetSkeleton())
	{
		UE_LOG(LogJR, Warning, TEXT("%s: %s não é do esqueleto de %s; o motorista pode ficar em T."),
			*GetName(), *GetNameSafe(DriveAnim), *GetNameSafe(HeroMesh));
	}
	DriverMesh->SetSkeletalMeshAsset(HeroMesh);
	DriverMesh->EmptyOverrideMaterials();
	if (HeroDefaults && HeroDefaults->GetMesh())
	{
		const TArray<TObjectPtr<UMaterialInterface>>& HeroMaterials = HeroDefaults->GetMesh()->OverrideMaterials;
		for (int32 Slot = 0; Slot < HeroMaterials.Num(); ++Slot)
		{
			if (HeroMaterials[Slot])
			{
				DriverMesh->SetMaterial(Slot, HeroMaterials[Slot]);
			}
		}
	}
	if (Skin)
	{
		for (int32 Slot = 0; Slot < Skin->MaterialOverrides.Num(); ++Slot)
		{
			if (UMaterialInterface* Material = Skin->MaterialOverrides[Slot].LoadSynchronous())
			{
				DriverMesh->SetMaterial(Slot, Material);
			}
		}
	}
	// Canelas/pés atravessariam o assoalho: esconde (o tronco e as coxas ficam dentro da cabine).
	for (const FName& Bone : DriverHiddenBones)
	{
		if (DriverMesh->GetBoneIndex(Bone) != INDEX_NONE)
		{
			DriverMesh->HideBoneByName(Bone, EPhysBodyOp::PBO_None);
		}
	}
	DriverMesh->SetAnimationMode(EAnimationMode::AnimationSingleNode);
	DriverMesh->PlayAnimation(DriveAnim, true);
	SetDriverVisible(true);
}

void AJRVehiclePawn::HandleNitro(const FInputActionValue& Value)
{
	bNitroHeld = Value.Get<bool>();
}

void AJRVehiclePawn::TickNitro()
{
	bNitroActive = bNitroHeld && bDriveEnabled && NitroCharge > 0.f && GetSpeedKmh() < NitroMaxSpeedKmh;
	if (!bNitroActive)
	{
		return;
	}
	const float Dt = 0.05f;
	NitroCharge = FMath::Max(0.f, NitroCharge - NitroDrainPerSecond * Dt);
	// A força do nitro é aplicada no Tick (a cada frame).
}

FTransform AJRVehiclePawn::GetExitTransform() const
{
	return ExitPoint->GetComponentTransform();
}

FTransform AJRVehiclePawn::GetSeatTransform() const
{
	return SeatPoint->GetComponentTransform();
}

float AJRVehiclePawn::GetSpeedKmh() const
{
	return GetVehicleMovementComponent() ? GetVehicleMovementComponent()->GetForwardSpeed() * 0.036f : 0.f;
}

void AJRVehiclePawn::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* Input = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (!Input)
	{
		return;
	}
	if (ThrottleAction)
	{
		Input->BindAction(ThrottleAction, ETriggerEvent::Triggered, this, &AJRVehiclePawn::HandleThrottle);
		Input->BindAction(ThrottleAction, ETriggerEvent::Completed, this, &AJRVehiclePawn::HandleThrottle);
	}
	if (BrakeAction)
	{
		Input->BindAction(BrakeAction, ETriggerEvent::Triggered, this, &AJRVehiclePawn::HandleBrake);
		Input->BindAction(BrakeAction, ETriggerEvent::Completed, this, &AJRVehiclePawn::HandleBrake);
	}
	if (SteerAction)
	{
		Input->BindAction(SteerAction, ETriggerEvent::Triggered, this, &AJRVehiclePawn::HandleSteer);
		Input->BindAction(SteerAction, ETriggerEvent::Completed, this, &AJRVehiclePawn::HandleSteerReleased);
	}
	if (HandbrakeAction)
	{
		Input->BindAction(HandbrakeAction, ETriggerEvent::Started, this, &AJRVehiclePawn::HandleHandbrake);
		Input->BindAction(HandbrakeAction, ETriggerEvent::Completed, this, &AJRVehiclePawn::HandleHandbrake);
	}
	if (LookAction)
	{
		Input->BindAction(LookAction, ETriggerEvent::Triggered, this, &AJRVehiclePawn::HandleLook);
	}
	if (NitroAction)
	{
		Input->BindAction(NitroAction, ETriggerEvent::Started, this, &AJRVehiclePawn::HandleNitro);
		Input->BindAction(NitroAction, ETriggerEvent::Completed, this, &AJRVehiclePawn::HandleNitro);
	}
	if (MouseLookAction)
	{
		Input->BindAction(MouseLookAction, ETriggerEvent::Triggered, this, &AJRVehiclePawn::HandleLook);
	}
}

void AJRVehiclePawn::HandleThrottle(const FInputActionValue& Value)
{
	if (bDriveEnabled)
	{
		GetVehicleMovementComponent()->SetThrottleInput(Value.Get<float>());
	}
}

void AJRVehiclePawn::HandleBrake(const FInputActionValue& Value)
{
	if (bDriveEnabled)
	{
		GetVehicleMovementComponent()->SetBrakeInput(Value.Get<float>());
	}
}

void AJRVehiclePawn::HandleSteer(const FInputActionValue& Value)
{
	LastSteerInput = Value.Get<float>();
	if (bDriveEnabled)
	{
		GetVehicleMovementComponent()->SetSteeringInput(ComputeSteering(LastSteerInput));
	}
}

void AJRVehiclePawn::HandleSteerReleased(const FInputActionValue& Value)
{
	LastSteerInput = 0.f;
	if (bDriveEnabled)
	{
		// Sem input o pneu furado (e o zumbi agarrado) continua puxando para o lado.
		GetVehicleMovementComponent()->SetSteeringInput(ComputeSteering(0.f));
	}
}

void AJRVehiclePawn::HandleHandbrake(const FInputActionValue& Value)
{
	bHandbrakeHeld = Value.Get<bool>();
	if (bDriveEnabled)
	{
		GetVehicleMovementComponent()->SetHandbrakeInput(Value.Get<bool>());
	}
}

void AJRVehiclePawn::HandleLook(const FInputActionValue& Value)
{
	const FVector2D Look = Value.Get<FVector2D>();
	AddControllerYawInput(Look.X);
	AddControllerPitchInput(Look.Y);
}

void AJRVehiclePawn::ZeroInputs(bool bApplyHandbrake)
{
	if (UChaosVehicleMovementComponent* Movement = GetVehicleMovementComponent())
	{
		Movement->SetThrottleInput(0.f);
		Movement->SetSteeringInput(0.f);
		Movement->SetBrakeInput(bApplyHandbrake ? 1.f : 0.f);
		Movement->SetHandbrakeInput(bApplyHandbrake);
	}
	LastSteerInput = 0.f;
}

void AJRVehiclePawn::UnPossessed()
{
	// Requisito de teste: o veículo não continua acelerando quando o controle muda.
	ZeroInputs(true);
	// O herói de verdade assume no banco (animação de sair): o motorista visual some.
	SetDriverVisible(false);
	// Agarrados descem vivos e voltam a perseguir o jogador a pé.
	ReleaseAllGrabbers(false);
	// "Bomba": saiu do carro pegando fogo, explode daqui a pouco e leva os zumbis junto.
	if (bCarBombOnExitWhileBurning && bFireOn && !bExploded && !GetWorldTimerManager().IsTimerActive(CarBombTimer))
	{
		GetWorldTimerManager().SetTimer(CarBombTimer, this, &AJRVehiclePawn::Explode, FMath::Max(CarBombFuseTime, 0.1f), false);
		AJRHUD::Toast(this, FString::Printf(TEXT("Corra! O carro explode em %.0f s."), CarBombFuseTime), FLinearColor(1.f, 0.3f, 0.1f));
		UE_LOG(LogJR, Log, TEXT("%s: bomba armada (%.1f s)"), *GetName(), CarBombFuseTime);
	}
	Super::UnPossessed();
}

void AJRVehiclePawn::ParkAndDisable()
{
	bDriveEnabled = false;
	ZeroInputs(true);
	GetWorldTimerManager().SetTimer(SleepTimer, this, &AJRVehiclePawn::SleepPhysics, SleepDelayAfterPark, false);
}

void AJRVehiclePawn::StopThenExit(const FTransform& FallbackTransform)
{
	if (GetWorldTimerManager().IsTimerActive(StopExitTimer))
	{
		return;
	}
	bDriveEnabled = false;
	ZeroInputs(true);
	PendingExitFallback = FallbackTransform;
	StopExitElapsed = 0.f;
	GetWorldTimerManager().SetTimer(StopExitTimer, this, &AJRVehiclePawn::TickStopForExit, 0.1f, true);
}

void AJRVehiclePawn::TickStopForExit()
{
	StopExitElapsed += 0.1f;
	ZeroInputs(true);
	if (FMath::Abs(GetSpeedKmh()) > ExitMaxSpeedKmh && StopExitElapsed < ExitStopTimeout)
	{
		return;
	}
	GetWorldTimerManager().ClearTimer(StopExitTimer);
	// Parada total: o carro não pode seguir andando sozinho depois que o jogador desce.
	GetMesh()->SetPhysicsLinearVelocity(FVector::ZeroVector);
	GetMesh()->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
	if (AJRPlayerController* PC = Cast<AJRPlayerController>(GetController()))
	{
		PC->RequestExitVehicle(PendingExitFallback);
	}
}

void AJRVehiclePawn::SleepPhysics()
{
	GetMesh()->PutAllRigidBodiesToSleep();
}

void AJRVehiclePawn::HandleVehicleDisabled()
{
	// Integridade no fim: o carro explode (falha no estágio Driving; nos outros o jogador sai a pé).
	Explode();
}
