// Copyright utrazin. All Rights Reserved.

#include "Combat/JRWeaponComponent.h"
#include "AI/JRAimPrediction.h"
#include "Combat/JRWeaponDefinition.h"
#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"
#include "GameFramework/Controller.h"
#include "GameFramework/Pawn.h"
#include "JogoResgate.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "TimerManager.h"

UJRWeaponComponent::UJRWeaponComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UJRWeaponComponent::BeginPlay()
{
	Super::BeginPlay();
	SpreadStream.GenerateNewSeed();
	EquipDefinition(Definition);
}

void UJRWeaponComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	CancelAll();
	Super::EndPlay(EndPlayReason);
}

void UJRWeaponComponent::EquipDefinition(UJRWeaponDefinition* NewDefinition)
{
	CancelAll();
	Definition = NewDefinition;
	if (Definition)
	{
		Ammo.Initialize(Definition->MagazineSize, Definition->StartingReserve);
		OnAmmoChanged.Broadcast(Ammo.Magazine, Ammo.Reserve);
	}
}

void UJRWeaponComponent::SwitchDefinitionKeepAmmo(UJRWeaponDefinition* NewDefinition)
{
	if (!NewDefinition || NewDefinition == Definition)
	{
		return;
	}
	CancelAll();
	const int32 Total = Ammo.Magazine + Ammo.Reserve;
	Definition = NewDefinition;
	Ammo.MagazineSize = FMath::Max(1, Definition->MagazineSize);
	Ammo.Magazine = FMath::Min(Ammo.MagazineSize, Total);
	Ammo.Reserve = FMath::Max(0, Total - Ammo.Magazine);
	OnAmmoChanged.Broadcast(Ammo.Magazine, Ammo.Reserve);
}

void UJRWeaponComponent::SetBoost(float InDamageMultiplier, float InFireRateMultiplier)
{
	DamageMultiplier = FMath::Max(0.1f, InDamageMultiplier);
	FireRateMultiplier = FMath::Max(0.1f, InFireRateMultiplier);
	if (bWantsToFire)
	{
		StartFire(); // reinicia o timer com a nova cadência
	}
}

void UJRWeaponComponent::StartFire()
{
	if (!Definition || bReloading)
	{
		return;
	}
	bWantsToFire = true;
	UWorld* World = GetWorld();
	const float Interval = 1.f / (Definition->FireRate * FireRateMultiplier);
	const double Elapsed = World->GetTimeSeconds() - LastFireTime;
	const float FirstDelay = FMath::Max(0.f, Interval - static_cast<float>(Elapsed));
	World->GetTimerManager().SetTimer(FireTimer, this, &UJRWeaponComponent::FireOnce, Interval, true, FirstDelay);
}

void UJRWeaponComponent::StopFire()
{
	bWantsToFire = false;
	if (UWorld* World = GetWorld())
	{
		World->GetTimerManager().ClearTimer(FireTimer);
	}
}

bool UJRWeaponComponent::StartReload()
{
	if (!Definition || bReloading || !Ammo.CanReload())
	{
		return false;
	}
	StopFire();
	bReloading = true;
	OnReloadStateChanged.Broadcast(true);
	GetWorld()->GetTimerManager().SetTimer(ReloadTimer, this, &UJRWeaponComponent::FinishReload, Definition->ReloadTime, false);
	return true;
}

void UJRWeaponComponent::FinishReload()
{
	bReloading = false;
	Ammo.Reload();
	OnReloadStateChanged.Broadcast(false);
	OnAmmoChanged.Broadcast(Ammo.Magazine, Ammo.Reserve);
}

void UJRWeaponComponent::AddReserveAmmo(int32 Amount)
{
	Ammo.AddReserve(Amount);
	OnAmmoChanged.Broadcast(Ammo.Magazine, Ammo.Reserve);
}

void UJRWeaponComponent::CancelAll()
{
	StopFire();
	if (bReloading)
	{
		bReloading = false;
		if (UWorld* World = GetWorld())
		{
			World->GetTimerManager().ClearTimer(ReloadTimer);
		}
		OnReloadStateChanged.Broadcast(false);
	}
}

bool UJRWeaponComponent::GetAimViewPoint(FVector& OutLocation, FRotator& OutRotation) const
{
	const APawn* Pawn = Cast<APawn>(GetOwner());
	if (!Pawn)
	{
		return false;
	}
	if (const AController* Controller = Pawn->GetController())
	{
		Controller->GetPlayerViewPoint(OutLocation, OutRotation);
		return true;
	}
	Pawn->GetActorEyesViewPoint(OutLocation, OutRotation);
	return true;
}

void UJRWeaponComponent::FireOnce()
{
	if (!Definition || !bWantsToFire)
	{
		StopFire();
		return;
	}
	if (!Ammo.ConsumeShot())
	{
		StopFire();
		StartReload();
		return;
	}
	LastFireTime = GetWorld()->GetTimeSeconds();

	FVector ViewLocation;
	FRotator ViewRotation;
	if (!GetAimViewPoint(ViewLocation, ViewRotation))
	{
		return;
	}
	const float Spread = bAiming ? Definition->SpreadHalfAngleDegrees * 0.5f : Definition->SpreadHalfAngleDegrees;
	const FVector Direction = FJRAimPrediction::ApplySpread(ViewRotation.Vector(), Spread, SpreadStream);

	FCollisionQueryParams Params(SCENE_QUERY_STAT(JRWeaponTrace), true, GetOwner());
	FHitResult Hit;
	bool bHit = false;
	FVector End = ViewLocation + Direction * Definition->Range;
	const int32 Pellets = FMath::Max(1, Definition->PelletCount);
	for (int32 Pellet = 0; Pellet < Pellets; ++Pellet)
	{
		const FVector PelletDir = Pellets > 1
			? FJRAimPrediction::ApplySpread(ViewRotation.Vector(), FMath::Max(Spread, Definition->PelletSpreadDegrees), SpreadStream)
			: Direction;
		const FVector PelletEnd = ViewLocation + PelletDir * Definition->Range;
		FHitResult PelletHit;
		const bool bPelletHit = GetWorld()->LineTraceSingleByChannel(PelletHit, ViewLocation, PelletEnd, TraceChannel, Params);
		if (Pellet == 0)
		{
			Hit = PelletHit;
			bHit = bPelletHit;
			End = PelletEnd;
		}
		if (bPelletHit && PelletHit.GetActor())
		{
			UGameplayStatics::ApplyPointDamage(PelletHit.GetActor(), Definition->Damage * DamageMultiplier, PelletDir, PelletHit,
				GetOwner()->GetInstigatorController(), GetOwner(), nullptr);
			UPrimitiveComponent* HitComp = PelletHit.GetComponent();
			if (HitComp && HitComp->IsSimulatingPhysics())
			{
				// Velocidade direta (independe da massa): cone e caixa reagem de forma visível.
				HitComp->AddImpulseAtLocation(PelletDir * HitImpulse * HitComp->GetMass(), PelletHit.ImpactPoint, PelletHit.BoneName);
			}
		}
		if (bDrawDebugTracer && Pellet > 0)
		{
			DrawDebugLine(GetWorld(), GetOwner()->GetActorLocation() + FVector(0.f, 0.f, 50.f),
				bPelletHit ? FVector(PelletHit.ImpactPoint) : PelletEnd, FColor::Purple, false, 0.1f, 0, 1.5f);
		}
	}
	if (bDrawDebugTracer)
	{
		// Greybox: rastro visível do tiro até existir arma/VFX de verdade.
		const FVector Muzzle = GetOwner()->GetActorLocation() + FVector(0.f, 0.f, 50.f);
		const FVector Impact = bHit ? FVector(Hit.ImpactPoint) : End;
		DrawDebugLine(GetWorld(), Muzzle, Impact, FColor::Cyan, false, 0.12f, 0, 2.f);
		if (bHit)
		{
			DrawDebugSphere(GetWorld(), Impact, 12.f, 8, FColor::Red, false, 0.3f);
		}
	}
	OnWeaponFired.Broadcast(ViewLocation, bHit ? Hit.ImpactPoint : End);
	OnAmmoChanged.Broadcast(Ammo.Magazine, Ammo.Reserve);
}
