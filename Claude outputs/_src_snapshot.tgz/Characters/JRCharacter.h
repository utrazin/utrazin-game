// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "JRCharacter.generated.h"

class UAnimMontage;
class UAnimSequenceBase;
class UCameraComponent;
class UInputAction;
class UJRHealthComponent;
class UJRInteractionComponent;
class UJRWeaponComponent;
class UJRWeaponDefinition;
class UStaticMesh;
class UStaticMeshComponent;
class USpringArmComponent;
struct FInputActionValue;
struct FJRSkinDefinition;

/** Armas que o herói pode carregar (começa sem nenhuma; acha pelo caminho). */
UENUM(BlueprintType)
enum class EJRWeaponSlot : uint8
{
	None,
	Melee,    // graveto alien (corpo a corpo)
	Pistol,
	Shotgun
};

/** Personagem jogável a pé (GDD 7). Componentes fazem o trabalho; a classe só compõe e roteia input. */
UCLASS()
class JOGORESGATE_API AJRCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AJRCharacter();

	/** Toca a montage de saída do carro bloqueando o movimento até terminar. */
	UFUNCTION(BlueprintCallable, Category = "Character")
	void PlayExitVehicleSequence();

	/** Começa sentado no banco do veículo e a animação leva o personagem para fora. */
	void PlayExitFromVehicle(AActor* FromVehicle, const FTransform& SeatTransform);

	/** Abraço do resgate. Retorna a duração (0 se não houver montage). */
	UFUNCTION(BlueprintCallable, Category = "Character")
	float PlayRescueHug();

	void ApplySkin(const FJRSkinDefinition& Skin);

	UFUNCTION(BlueprintPure, Category = "Character")
	UJRHealthComponent* GetHealthComponent() const { return HealthComponent; }

	UFUNCTION(BlueprintPure, Category = "Character")
	UJRWeaponComponent* GetWeaponComponent() const { return WeaponComponent; }

	/** Puxa (true: melhor arma que tiver) ou guarda (false) a arma, com animação. */
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void SetWeaponEquipped(bool bEquip);

	/** Arma de fogo na mão (pistola ou escopeta). */
	UFUNCTION(BlueprintPure, Category = "Weapon")
	bool IsWeaponEquipped() const { return bWeaponEquipped; }

	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void SelectWeaponSlot(EJRWeaponSlot NewSlot);

	UFUNCTION(BlueprintPure, Category = "Weapon")
	EJRWeaponSlot GetCurrentWeaponSlot() const { return CurrentSlot; }

	UFUNCTION(BlueprintPure, Category = "Weapon")
	bool OwnsWeapon(EJRWeaponSlot Slot) const;

	/** Ganha a arma (e, se pedir, já puxa). */
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void GrantWeapon(EJRWeaponSlot Slot, bool bEquipNow);

	/** Abaixa, pega a arma do chão (animação) e já fica com ela na mão. */
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void PickUpWeaponFromGround(EJRWeaponSlot Slot);

	/** Animação de corpo inteiro travando o movimento (pegar, abrir baú). Retorna a duração. */
	UFUNCTION(BlueprintCallable, Category = "Character")
	float PlayFullBodyAction(UAnimSequenceBase* Anim, float PlayRate = 1.f, float MaxDuration = 0.f);

	UFUNCTION(BlueprintPure, Category = "Character")
	UAnimSequenceBase* GetOpenChestAnim() const { return OpenChestAnim; }

	/** Loop de dirigir (sentado, mãos no volante) usado pelo motorista visual do carro. */
	UFUNCTION(BlueprintPure, Category = "Character")
	UAnimSequenceBase* GetDrivingAnim() const { return DrivingAnim; }

	/** Console (teste): dá todas as armas. */
	UFUNCTION(Exec)
	void JRArmas();

	UFUNCTION(BlueprintPure, Category = "Weapon")
	bool IsAimHeld() const { return bAimHeld; }

	/** Poder "Fúria": dano e cadência maiores por alguns segundos. */
	UFUNCTION(BlueprintCallable, Category = "Weapon")
	void ActivateFury(float Seconds);

	/** Segundos restantes de Fúria (0 = inativa). */
	UFUNCTION(BlueprintPure, Category = "Weapon")
	float GetFuryRemaining() const;

	/** Restaura vida e estado para respawn em checkpoint. */
	void ResetForRespawn();

protected:
	virtual void BeginPlay() override;
	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

	void HandleMove(const FInputActionValue& Value);
	void HandleLook(const FInputActionValue& Value);
	void HandleSprint(const FInputActionValue& Value);
	void HandleAim(const FInputActionValue& Value);
	void HandleFireStarted(const FInputActionValue& Value);
	void HandleFireStopped(const FInputActionValue& Value);
	void HandleReload(const FInputActionValue& Value);
	void HandleInteract(const FInputActionValue& Value);
	void HandleToggleWeapon(const FInputActionValue& Value);
	void MeleeAttack();
	void DoMeleeHit();
	void UpdateWeaponVisuals();
	EJRWeaponSlot NextOwnedSlot() const;

	UFUNCTION()
	void HandleDeath(UJRHealthComponent* Health, AActor* Killer);

	UFUNCTION()
	void HandleMontageEnded(UAnimMontage* Montage, bool bInterrupted);

	UFUNCTION()
	void HandleExitBlendingOut(UAnimMontage* Montage, bool bInterrupted);

	UFUNCTION()
	void HandleWeaponFired(const FVector& Start, const FVector& End);

	UFUNCTION()
	void HandleReloadStateChanged(bool bIsReloading);

	UFUNCTION()
	void HandleHealthChanged(UJRHealthComponent* Health, float NewHealth, float Delta);

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	TObjectPtr<USpringArmComponent> SpringArm;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	TObjectPtr<UCameraComponent> Camera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	TObjectPtr<UJRHealthComponent> HealthComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	TObjectPtr<UJRWeaponComponent> WeaponComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Character")
	TObjectPtr<UJRInteractionComponent> InteractionComponent;

	/** Pistola/escopeta visível na mão direita (só aparece com arma de fogo na mão). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<UStaticMeshComponent> WeaponMesh;

	/** Graveto alien na mão direita (corpo a corpo). */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<UStaticMeshComponent> MeleeMesh;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	TObjectPtr<UJRWeaponDefinition> PistolDefinition;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	TObjectPtr<UJRWeaponDefinition> ShotgunDefinition;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	TObjectPtr<UStaticMesh> PistolStaticMesh;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	TObjectPtr<UStaticMesh> ShotgunStaticMesh;

	/** Escala da malha da escopeta em relação ao encaixe da pistola. */
	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float ShotgunMeshScale = 1.35f;

	/** Golpes do graveto (alternados em combo, slot UpperBody). */
	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee")
	TArray<TObjectPtr<UAnimSequenceBase>> MeleeAnims;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee")
	float MeleeDamage = 40.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee", meta = (Units = "cm"))
	float MeleeRange = 170.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee", meta = (Units = "cm"))
	float MeleeRadius = 110.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee", meta = (Units = "s"))
	float MeleeHitDelay = 0.3f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee", meta = (Units = "s"))
	float MeleeCooldown = 0.55f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee")
	float MeleePlayRate = 1.4f;

	/** Empurrão do golpe (cm/s) em zumbis e objetos. */
	UPROPERTY(EditDefaultsOnly, Category = "Weapon|Melee")
	float MeleeKnockback = 650.f;

	/** Pegar do chão (corpo inteiro). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> PickupAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float PickupGrantTime = 0.9f;

	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float PickupDuration = 1.6f;

	/** Abrir baú (corpo inteiro). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> OpenChestAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> MoveAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> LookAction;

	/** Olhar com o mouse (separado do analógico, como no template da Epic). */
	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> MouseLookAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> JumpAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> SprintAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> AimAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> FireAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> ReloadAction;

	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> InteractAction;

	/** Equipar/guardar a pistola. */
	UPROPERTY(EditDefaultsOnly, Category = "Input")
	TObjectPtr<UInputAction> ToggleWeaponAction;

	UPROPERTY(EditDefaultsOnly, Category = "Movement", meta = (Units = "cm/s"))
	float WalkSpeed = 350.f;

	UPROPERTY(EditDefaultsOnly, Category = "Movement", meta = (Units = "cm/s"))
	float SprintSpeed = 600.f;

	UPROPERTY(EditDefaultsOnly, Category = "Camera", meta = (Units = "cm"))
	float DefaultArmLength = 400.f;

	UPROPERTY(EditDefaultsOnly, Category = "Camera", meta = (Units = "cm"))
	float AimArmLength = 170.f;

	/** Câmera sobre o ombro direito (andando / mirando). Y = lado, Z = altura. */
	UPROPERTY(EditDefaultsOnly, Category = "Camera")
	FVector ShoulderOffset = FVector(0.f, 45.f, 45.f);

	UPROPERTY(EditDefaultsOnly, Category = "Camera")
	FVector AimShoulderOffset = FVector(0.f, 70.f, 55.f);

	UPROPERTY(EditDefaultsOnly, Category = "Camera")
	float CameraBlendSpeed = 10.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float FuryDamageMultiplier = 2.f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	float FuryFireRateMultiplier = 1.75f;

	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimMontage> ExitVehicleMontage;

	/** Loop sentado dirigindo (do mesmo esqueleto do herói). O carro lê isto do Blueprint do herói. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> DrivingAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimMontage> RescueHugMontage;

	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimMontage> DeathMontage;

	/** Pose de mira com a pistola (loop no UpperBody só ao mirar ou atirar). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> AimAnim;

	/** Recuo de um tiro (curto; começa e termina na pose de mira). Cada herói tem o seu. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> FireAnim;

	/** Puxar a pistola. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> EquipAnim;

	/** Guardar a pistola (o arquivo começa mirando; pulamos para UnequipStartTime). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> UnequipAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float UnequipStartTime = 3.2f;

	/** Momento do "puxar" em que a arma aparece na mão. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float EquipShowWeaponTime = 0.55f;

	/** Momento do "guardar" em que a arma some (já atrás das costas). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float UnequipHideWeaponTime = 0.65f;

	/** Quanto tempo a arma continua erguida depois do último tiro. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation", meta = (Units = "s"))
	float AimLingerTime = 0.8f;

	UPROPERTY(EditDefaultsOnly, Category = "Weapon")
	bool bStartWithWeaponEquipped = false;

	/** Recarga (slot UpperBody). A velocidade é ajustada para durar o ReloadTime da arma. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> ReloadAnim;

	/** Reação ao levar dano (slot UpperBody; não interrompe tiro/recarga). */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TObjectPtr<UAnimSequenceBase> HitReactAnim;

	/** Slot do AnimBP usado pelas animações de parte de cima do corpo. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	FName UpperBodySlot = TEXT("UpperBody");

	/** Slot de corpo inteiro (morte, sair do carro, resgate): enquanto ativo, a pose da arma sai. */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	FName FullBodySlot = TEXT("DefaultSlot");

	/** Atraso entre a morte e o reinício no checkpoint. */
	UPROPERTY(EditDefaultsOnly, Category = "Character", meta = (Units = "s"))
	float FailureDelay = 2.5f;

private:
	void NotifyFailure();

	FTimerHandle FailureTimer;

	void UpdateUpperBody();
	void PlayAimPose(float BlendIn);
	void HandleRecoilBlendingOut(UAnimMontage* Montage, bool bInterrupted);
	bool WantsAimPose() const;

	UPROPERTY(Transient)
	TObjectPtr<UAnimMontage> AimMontage;

	FTimerHandle UpperBodyTimer;
	FTimerHandle FuryTimer;
	FTimerHandle MeleeTimer;
	FTimerHandle ActionTimer;
	FTimerHandle PickupTimer;
	EJRWeaponSlot CurrentSlot = EJRWeaponSlot::None;
	bool bOwnMelee = false;
	bool bOwnPistol = false;
	bool bOwnShotgun = false;
	bool bMeleeBusy = false;
	int32 MeleeComboIndex = 0;
	double LastMeleeTime = -100.0;
	FTimerHandle WeaponVisibilityTimer;
	FTimerHandle WeaponTransitionTimer;
	double LastShotTime = -1000.0;
	bool bWeaponEquipped = false;
	bool bWeaponTransition = false;
	bool bAimHeld = false;
	bool bFireHeld = false;

	TWeakObjectPtr<AActor> ExitingVehicle;
	TEnumAsByte<ECollisionResponse> ExitVehiclePawnResponse = ECR_Block;
	bool bIsSprinting = false;
};
