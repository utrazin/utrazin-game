// Copyright utrazin. All Rights Reserved.

#include "Characters/JRCharacter.h"
#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimSequenceBase.h"
#include "Camera/CameraComponent.h"
#include "Characters/JRCharacterDefinition.h"
#include "Combat/JRHealthComponent.h"
#include "Combat/JRWeaponComponent.h"
#include "Combat/JRWeaponDefinition.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Core/JRGameMode.h"
#include "EnhancedInputComponent.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "InputActionValue.h"
#include "Interactions/JRInteractionComponent.h"
#include "Materials/MaterialInterface.h"
#include "Engine/OverlapResult.h"
#include "Engine/StaticMesh.h"
#include "Kismet/GameplayStatics.h"
#include "TimerManager.h"

AJRCharacter::AJRCharacter()
{
	PrimaryActorTick.bCanEverTick = false;

	bUseControllerRotationYaw = false;
	UCharacterMovementComponent* Move = GetCharacterMovement();
	Move->bOrientRotationToMovement = true;
	Move->RotationRate = FRotator(0.f, 540.f, 0.f);
	Move->MaxWalkSpeed = WalkSpeed;
	Move->JumpZVelocity = 450.f;
	// Empurrar objetos físicos de forma plausível (GDD 7).
	Move->bEnablePhysicsInteraction = true;
	Move->PushForceFactor = 300000.f;

	SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
	SpringArm->SetupAttachment(RootComponent);
	SpringArm->TargetArmLength = DefaultArmLength;
	SpringArm->SocketOffset = FVector(0.f, 45.f, 45.f);
	SpringArm->bUsePawnControlRotation = true;
	SpringArm->bEnableCameraLag = false; // lag + física causava tremido

	Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
	Camera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);

	HealthComponent = CreateDefaultSubobject<UJRHealthComponent>(TEXT("HealthComponent"));
	WeaponComponent = CreateDefaultSubobject<UJRWeaponComponent>(TEXT("WeaponComponent"));
	InteractionComponent = CreateDefaultSubobject<UJRInteractionComponent>(TEXT("InteractionComponent"));

	WeaponMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WeaponMesh"));
	WeaponMesh->SetupAttachment(GetMesh(), TEXT("hand_r"));
	WeaponMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	WeaponMesh->SetGenerateOverlapEvents(false);
	WeaponMesh->SetVisibility(false);

	MeleeMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("MeleeMesh"));
	MeleeMesh->SetupAttachment(GetMesh(), TEXT("hand_r"));
	MeleeMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	MeleeMesh->SetGenerateOverlapEvents(false);
	MeleeMesh->SetVisibility(false);
}

void AJRCharacter::BeginPlay()
{
	Super::BeginPlay();
	GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
	HealthComponent->OnDeath.AddDynamic(this, &AJRCharacter::HandleDeath);
	HealthComponent->OnHealthChanged.AddDynamic(this, &AJRCharacter::HandleHealthChanged);
	WeaponComponent->OnWeaponFired.AddDynamic(this, &AJRCharacter::HandleWeaponFired);
	WeaponComponent->OnReloadStateChanged.AddDynamic(this, &AJRCharacter::HandleReloadStateChanged);
	// Ergue/abaixa a pistola conforme mira e tiro (sem Tick).
	GetWorldTimerManager().SetTimer(UpperBodyTimer, this, &AJRCharacter::UpdateUpperBody, 0.05f, true, 0.2f);
	if (bStartWithWeaponEquipped)
	{
		bOwnPistol = true;
		CurrentSlot = EJRWeaponSlot::Pistol;
		bWeaponEquipped = true;
		WeaponComponent->SwitchDefinitionKeepAmmo(PistolDefinition.Get());
	}
	UpdateWeaponVisuals();
}

bool AJRCharacter::OwnsWeapon(EJRWeaponSlot Slot) const
{
	switch (Slot)
	{
	case EJRWeaponSlot::None: return true;
	case EJRWeaponSlot::Melee: return bOwnMelee;
	case EJRWeaponSlot::Pistol: return bOwnPistol;
	case EJRWeaponSlot::Shotgun: return bOwnShotgun;
	default: return false;
	}
}

void AJRCharacter::SetWeaponEquipped(bool bEquip)
{
	if (!bEquip)
	{
		SelectWeaponSlot(EJRWeaponSlot::None);
		return;
	}
	const EJRWeaponSlot Best = bOwnShotgun ? EJRWeaponSlot::Shotgun : bOwnPistol ? EJRWeaponSlot::Pistol
		: bOwnMelee ? EJRWeaponSlot::Melee : EJRWeaponSlot::None;
	SelectWeaponSlot(Best);
}

EJRWeaponSlot AJRCharacter::NextOwnedSlot() const
{
	const EJRWeaponSlot Order[] = { EJRWeaponSlot::None, EJRWeaponSlot::Melee, EJRWeaponSlot::Pistol, EJRWeaponSlot::Shotgun };
	int32 Index = 0;
	for (int32 i = 0; i < 4; ++i)
	{
		if (Order[i] == CurrentSlot)
		{
			Index = i;
		}
	}
	for (int32 Step = 1; Step <= 4; ++Step)
	{
		const EJRWeaponSlot Candidate = Order[(Index + Step) % 4];
		if (OwnsWeapon(Candidate))
		{
			return Candidate;
		}
	}
	return EJRWeaponSlot::None;
}

void AJRCharacter::UpdateWeaponVisuals()
{
	const bool bRanged = CurrentSlot == EJRWeaponSlot::Pistol || CurrentSlot == EJRWeaponSlot::Shotgun;
	if (bRanged)
	{
		UStaticMesh* Want = CurrentSlot == EJRWeaponSlot::Shotgun && ShotgunStaticMesh ? ShotgunStaticMesh.Get()
			: (PistolStaticMesh ? PistolStaticMesh.Get() : static_cast<UStaticMesh*>(WeaponMesh->GetStaticMesh()));
		if (Want && WeaponMesh->GetStaticMesh() != Want)
		{
			WeaponMesh->SetStaticMesh(Want);
		}
		WeaponMesh->SetRelativeScale3D(FVector(CurrentSlot == EJRWeaponSlot::Shotgun ? ShotgunMeshScale : 1.f));
	}
	WeaponMesh->SetVisibility(bRanged);
	MeleeMesh->SetVisibility(CurrentSlot == EJRWeaponSlot::Melee);
}

void AJRCharacter::SelectWeaponSlot(EJRWeaponSlot NewSlot)
{
	if (bWeaponTransition || NewSlot == CurrentSlot || !OwnsWeapon(NewSlot) || HealthComponent->GetHealth() <= 0.f)
	{
		return;
	}
	WeaponComponent->CancelAll();
	bFireHeld = false;
	const bool bWasArmed = CurrentSlot != EJRWeaponSlot::None;
	CurrentSlot = NewSlot;
	bWeaponEquipped = NewSlot == EJRWeaponSlot::Pistol || NewSlot == EJRWeaponSlot::Shotgun;
	if (bWeaponEquipped)
	{
		WeaponComponent->SwitchDefinitionKeepAmmo(NewSlot == EJRWeaponSlot::Shotgun ? ShotgunDefinition.Get() : PistolDefinition.Get());
	}
	const bool bEquip = NewSlot != EJRWeaponSlot::None;
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	// Trocar de uma arma para outra também usa a animação de puxar (a nova aparece no meio dela).
	UAnimSequenceBase* Clip = bEquip ? EquipAnim.Get() : (bWasArmed ? UnequipAnim.Get() : nullptr);
	if (!Anim || !Clip)
	{
		UpdateWeaponVisuals();
		return;
	}
	bWeaponTransition = true;
	Anim->StopSlotAnimation(0.15f, UpperBodySlot);
	const float Start = bEquip ? 0.f : FMath::Clamp(UnequipStartTime, 0.f, Clip->GetPlayLength() - 0.1f);
	Anim->PlaySlotAnimationAsDynamicMontage(Clip, UpperBodySlot, 0.2f, 0.35f, 1.f, 1, -1.f, Start);

	FTimerManager& Timers = GetWorldTimerManager();
	Timers.SetTimer(WeaponVisibilityTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		UpdateWeaponVisuals();
	}), FMath::Max(0.01f, bEquip ? EquipShowWeaponTime : UnequipHideWeaponTime), false);
	const float Remaining = Clip->GetPlayLength() - Start;
	Timers.SetTimer(WeaponTransitionTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		bWeaponTransition = false;
	}), FMath::Max(0.1f, Remaining - 0.35f), false);
}

void AJRCharacter::GrantWeapon(EJRWeaponSlot Slot, bool bEquipNow)
{
	switch (Slot)
	{
	case EJRWeaponSlot::Melee: bOwnMelee = true; break;
	case EJRWeaponSlot::Pistol: bOwnPistol = true; break;
	case EJRWeaponSlot::Shotgun:
		bOwnShotgun = true;
		WeaponComponent->AddReserveAmmo(15); // vem com algumas células
		break;
	default: return;
	}
	if (bEquipNow)
	{
		bWeaponTransition = false;
		SelectWeaponSlot(Slot);
	}
}

void AJRCharacter::JRArmas()
{
	GrantWeapon(EJRWeaponSlot::Melee, false);
	GrantWeapon(EJRWeaponSlot::Pistol, false);
	GrantWeapon(EJRWeaponSlot::Shotgun, true);
	WeaponComponent->AddReserveAmmo(120);
}

float AJRCharacter::PlayFullBodyAction(UAnimSequenceBase* InAnim, float PlayRate, float MaxDuration)
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!InAnim || !Anim)
	{
		return 0.f;
	}
	WeaponComponent->CancelAll();
	bFireHeld = false;
	float Duration = InAnim->GetPlayLength() / FMath::Max(0.1f, PlayRate);
	if (MaxDuration > 0.f)
	{
		Duration = FMath::Min(Duration, MaxDuration);
	}
	Anim->StopSlotAnimation(0.1f, UpperBodySlot);
	Anim->PlaySlotAnimationAsDynamicMontage(InAnim, FullBodySlot, 0.2f, 0.3f, PlayRate, 1, Duration * PlayRate);
	GetCharacterMovement()->StopMovementImmediately();
	if (AController* C = GetController())
	{
		C->SetIgnoreMoveInput(true);
	}
	GetWorldTimerManager().SetTimer(ActionTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		if (UAnimInstance* A = GetMesh()->GetAnimInstance())
		{
			A->StopSlotAnimation(0.3f, FullBodySlot);
		}
		if (AController* C2 = GetController())
		{
			C2->ResetIgnoreMoveInput();
		}
	}), FMath::Max(0.1f, Duration), false);
	return Duration;
}

void AJRCharacter::PickUpWeaponFromGround(EJRWeaponSlot Slot)
{
	const float Duration = PlayFullBodyAction(PickupAnim, 1.3f, PickupDuration);
	if (Duration <= 0.f)
	{
		GrantWeapon(Slot, true);
		return;
	}
	GetWorldTimerManager().SetTimer(PickupTimer, FTimerDelegate::CreateWeakLambda(this, [this, Slot]()
	{
		// A arma já "está na mão" ao levantar: sem animação de puxar.
		switch (Slot)
		{
		case EJRWeaponSlot::Melee: bOwnMelee = true; break;
		case EJRWeaponSlot::Pistol: bOwnPistol = true; break;
		case EJRWeaponSlot::Shotgun: bOwnShotgun = true; WeaponComponent->AddReserveAmmo(15); break;
		default: break;
		}
		CurrentSlot = Slot;
		bWeaponEquipped = Slot == EJRWeaponSlot::Pistol || Slot == EJRWeaponSlot::Shotgun;
		if (bWeaponEquipped)
		{
			WeaponComponent->SwitchDefinitionKeepAmmo(Slot == EJRWeaponSlot::Shotgun ? ShotgunDefinition.Get() : PistolDefinition.Get());
		}
		UpdateWeaponVisuals();
	}), FMath::Min(PickupGrantTime, Duration * 0.8f), false);
}

void AJRCharacter::MeleeAttack()
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (bMeleeBusy || bWeaponTransition || !Anim)
	{
		return;
	}
	const double Now = GetWorld()->GetTimeSeconds();
	MeleeComboIndex = (Now - LastMeleeTime < 1.2 && MeleeAnims.Num() > 0) ? (MeleeComboIndex + 1) % MeleeAnims.Num() : 0;
	LastMeleeTime = Now;
	bMeleeBusy = true;
	// Golpeia para onde a câmera olha.
	if (Controller)
	{
		SetActorRotation(FRotator(0.f, Controller->GetControlRotation().Yaw, 0.f));
	}
	if (MeleeAnims.IsValidIndex(MeleeComboIndex) && MeleeAnims[MeleeComboIndex])
	{
		Anim->PlaySlotAnimationAsDynamicMontage(MeleeAnims[MeleeComboIndex], UpperBodySlot, 0.08f, 0.2f, MeleePlayRate);
	}
	GetWorldTimerManager().SetTimer(MeleeTimer, this, &AJRCharacter::DoMeleeHit, MeleeHitDelay, false);
}

void AJRCharacter::DoMeleeHit()
{
	const FVector Fwd = GetActorForwardVector();
	const FVector Center = GetActorLocation() + Fwd * (MeleeRange * 0.6f);
	TArray<FOverlapResult> Overlaps;
	FCollisionObjectQueryParams Objects;
	Objects.AddObjectTypesToQuery(ECC_Pawn);
	Objects.AddObjectTypesToQuery(ECC_PhysicsBody);
	Objects.AddObjectTypesToQuery(ECC_WorldDynamic);
	FCollisionQueryParams Params(SCENE_QUERY_STAT(JRMelee), false, this);
	GetWorld()->OverlapMultiByObjectType(Overlaps, Center, FQuat::Identity, Objects, FCollisionShape::MakeSphere(MeleeRadius), Params);
	TSet<AActor*> Done;
	for (const FOverlapResult& O : Overlaps)
	{
		AActor* Other = O.GetActor();
		if (!Other || Done.Contains(Other))
		{
			continue;
		}
		Done.Add(Other);
		FHitResult Hit;
		Hit.ImpactPoint = Other->GetActorLocation();
		Hit.Location = Hit.ImpactPoint;
		const float Mult = GetFuryRemaining() > 0.f ? FuryDamageMultiplier : 1.f;
		UGameplayStatics::ApplyPointDamage(Other, MeleeDamage * Mult, Fwd, Hit, GetController(), this, nullptr);
		if (ACharacter* OtherChar = Cast<ACharacter>(Other))
		{
			OtherChar->LaunchCharacter(Fwd * MeleeKnockback + FVector(0.f, 0.f, 150.f), true, false);
		}
		if (UPrimitiveComponent* Comp = O.GetComponent())
		{
			if (Comp->IsSimulatingPhysics())
			{
				Comp->AddImpulse(Fwd * MeleeKnockback * Comp->GetMass());
			}
		}
	}
	GetWorldTimerManager().SetTimer(MeleeTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		bMeleeBusy = false;
	}), FMath::Max(0.05f, MeleeCooldown - MeleeHitDelay), false);
}

void AJRCharacter::ActivateFury(float Seconds)
{
	WeaponComponent->SetBoost(FuryDamageMultiplier, FuryFireRateMultiplier);
	GetWorldTimerManager().SetTimer(FuryTimer, FTimerDelegate::CreateWeakLambda(this, [this]()
	{
		WeaponComponent->SetBoost(1.f, 1.f);
	}), FMath::Max(1.f, Seconds), false);
}

float AJRCharacter::GetFuryRemaining() const
{
	return GetWorldTimerManager().IsTimerActive(FuryTimer) ? GetWorldTimerManager().GetTimerRemaining(FuryTimer) : 0.f;
}

void AJRCharacter::HandleToggleWeapon(const FInputActionValue& Value)
{
	SelectWeaponSlot(NextOwnedSlot());
}

bool AJRCharacter::WantsAimPose() const
{
	if (!bWeaponEquipped || bWeaponTransition || !AimAnim)
	{
		return false;
	}
	return bAimHeld || bFireHeld || GetWorld()->GetTimeSeconds() - LastShotTime < AimLingerTime;
}

void AJRCharacter::PlayAimPose(float BlendIn)
{
	if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
	{
		AimMontage = Anim->PlaySlotAnimationAsDynamicMontage(AimAnim, UpperBodySlot, BlendIn, 0.3f, 1.f, 100000);
	}
}

void AJRCharacter::UpdateUpperBody()
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!Anim)
	{
		return;
	}
	const bool bAlive = HealthComponent->GetHealth() > 0.f;
	if (!bAlive || Anim->IsSlotActive(FullBodySlot))
	{
		if (bAlive && Anim->IsSlotActive(UpperBodySlot))
		{
			Anim->StopSlotAnimation(0.2f, UpperBodySlot);
		}
		return;
	}
	const bool bWantAim = WantsAimPose();
	// Câmera sobre o ombro: o personagem fica de lado e a mira (centro da tela) livre.
	{
		const float Dt = 0.05f;
		const bool bCloseAim = bAimHeld && bWeaponEquipped;
		SpringArm->SocketOffset = FMath::VInterpTo(SpringArm->SocketOffset, bCloseAim ? AimShoulderOffset : ShoulderOffset, Dt, CameraBlendSpeed);
		SpringArm->TargetArmLength = FMath::FInterpTo(SpringArm->TargetArmLength, bCloseAim ? AimArmLength : DefaultArmLength, Dt, CameraBlendSpeed);
	}
	// Mirando ou atirando, o personagem olha para onde a câmera aponta (o tiro sai para lá).
	const bool bFaceCamera = bAimHeld || bWantAim;
	bUseControllerRotationYaw = bFaceCamera;
	GetCharacterMovement()->bOrientRotationToMovement = !bFaceCamera;

	if (bWeaponTransition || WeaponComponent->IsReloading())
	{
		return;
	}
	const bool bAimPlaying = AimMontage && Anim->Montage_IsPlaying(AimMontage);
	if (bWantAim && !Anim->IsSlotActive(UpperBodySlot))
	{
		PlayAimPose(0.15f);
	}
	else if (!bWantAim && bAimPlaying)
	{
		Anim->Montage_Stop(0.3f, AimMontage);
		AimMontage = nullptr;
	}
}

void AJRCharacter::HandleWeaponFired(const FVector& Start, const FVector& End)
{
	LastShotTime = GetWorld()->GetTimeSeconds();
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!Anim || !AimAnim || WeaponComponent->IsReloading())
	{
		return;
	}
	if (!(AimMontage && Anim->Montage_IsPlaying(AimMontage)) || !FireAnim)
	{
		// Primeiro tiro com a arma abaixada: só ergue a arma (rápido).
		if (!Anim->IsSlotActive(UpperBodySlot))
		{
			PlayAimPose(0.08f);
		}
		return;
	}
	// O recuo começa e termina na pose de mira: ao acabar, a mira volta sem transição.
	UAnimMontage* Recoil = Anim->PlaySlotAnimationAsDynamicMontage(FireAnim, UpperBodySlot, 0.08f, 0.f);
	if (Recoil)
	{
		FOnMontageBlendingOutStarted Delegate;
		Delegate.BindUObject(this, &AJRCharacter::HandleRecoilBlendingOut);
		Anim->Montage_SetBlendingOutDelegate(Delegate, Recoil);
	}
}

void AJRCharacter::HandleRecoilBlendingOut(UAnimMontage* Montage, bool bInterrupted)
{
	if (!bInterrupted && WantsAimPose() && !WeaponComponent->IsReloading())
	{
		PlayAimPose(0.f);
	}
}

void AJRCharacter::HandleReloadStateChanged(bool bIsReloading)
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!bIsReloading || !ReloadAnim || !Anim)
	{
		return; // a animação termina sozinha (morte/respawn param tudo)
	}
	Anim->StopSlotAnimation(0.1f, UpperBodySlot);
	float Rate = 1.f;
	const UJRWeaponDefinition* Def = WeaponComponent->GetDefinition();
	if (Def && Def->ReloadTime > 0.f && ReloadAnim->GetPlayLength() > 0.f)
	{
		Rate = ReloadAnim->GetPlayLength() / Def->ReloadTime;
	}
	Anim->PlaySlotAnimationAsDynamicMontage(ReloadAnim, UpperBodySlot, 0.15f, 0.2f, Rate);
}

void AJRCharacter::HandleHealthChanged(UJRHealthComponent* Health, float NewHealth, float Delta)
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (Delta >= 0.f || NewHealth <= 0.f || !HitReactAnim || !Anim || WeaponComponent->IsReloading() || bWeaponTransition)
	{
		return;
	}
	Anim->PlaySlotAnimationAsDynamicMontage(HitReactAnim, UpperBodySlot, 0.1f, 0.2f);
}

void AJRCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	UEnhancedInputComponent* Input = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (!Input)
	{
		return;
	}
	if (MoveAction) { Input->BindAction(MoveAction, ETriggerEvent::Triggered, this, &AJRCharacter::HandleMove); }
	if (LookAction) { Input->BindAction(LookAction, ETriggerEvent::Triggered, this, &AJRCharacter::HandleLook); }
	if (MouseLookAction) { Input->BindAction(MouseLookAction, ETriggerEvent::Triggered, this, &AJRCharacter::HandleLook); }
	if (JumpAction)
	{
		Input->BindAction(JumpAction, ETriggerEvent::Started, this, &ACharacter::Jump);
		Input->BindAction(JumpAction, ETriggerEvent::Completed, this, &ACharacter::StopJumping);
	}
	if (SprintAction)
	{
		Input->BindAction(SprintAction, ETriggerEvent::Started, this, &AJRCharacter::HandleSprint);
		Input->BindAction(SprintAction, ETriggerEvent::Completed, this, &AJRCharacter::HandleSprint);
	}
	if (AimAction)
	{
		Input->BindAction(AimAction, ETriggerEvent::Started, this, &AJRCharacter::HandleAim);
		Input->BindAction(AimAction, ETriggerEvent::Completed, this, &AJRCharacter::HandleAim);
	}
	if (FireAction)
	{
		Input->BindAction(FireAction, ETriggerEvent::Started, this, &AJRCharacter::HandleFireStarted);
		Input->BindAction(FireAction, ETriggerEvent::Completed, this, &AJRCharacter::HandleFireStopped);
	}
	if (ReloadAction) { Input->BindAction(ReloadAction, ETriggerEvent::Started, this, &AJRCharacter::HandleReload); }
	if (InteractAction) { Input->BindAction(InteractAction, ETriggerEvent::Started, this, &AJRCharacter::HandleInteract); }
	if (ToggleWeaponAction) { Input->BindAction(ToggleWeaponAction, ETriggerEvent::Started, this, &AJRCharacter::HandleToggleWeapon); }
}

void AJRCharacter::HandleMove(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	if (!Controller)
	{
		return;
	}
	const FRotator Yaw(0.f, Controller->GetControlRotation().Yaw, 0.f);
	AddMovementInput(FRotationMatrix(Yaw).GetUnitAxis(EAxis::X), Axis.Y);
	AddMovementInput(FRotationMatrix(Yaw).GetUnitAxis(EAxis::Y), Axis.X);
}

void AJRCharacter::HandleLook(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	AddControllerYawInput(Axis.X);
	AddControllerPitchInput(Axis.Y);
}

void AJRCharacter::HandleSprint(const FInputActionValue& Value)
{
	bIsSprinting = Value.Get<bool>();
	GetCharacterMovement()->MaxWalkSpeed = bIsSprinting ? SprintSpeed : WalkSpeed;
}

void AJRCharacter::HandleAim(const FInputActionValue& Value)
{
	const bool bAim = Value.Get<bool>();
	bAimHeld = bAim;
	WeaponComponent->SetAiming(bAim);
	// Distância e ombro da câmera são suavizados em UpdateUpperBody.
}

void AJRCharacter::HandleFireStarted(const FInputActionValue& Value)
{
	if (CurrentSlot == EJRWeaponSlot::Melee && !bWeaponTransition)
	{
		MeleeAttack();
		return;
	}
	// Só atira com a arma na mão (e fora da animação de puxar/guardar).
	if (!bWeaponEquipped || bWeaponTransition)
	{
		return;
	}
	bFireHeld = true;
	WeaponComponent->StartFire();
}

void AJRCharacter::HandleFireStopped(const FInputActionValue& Value)
{
	bFireHeld = false;
	WeaponComponent->StopFire();
}

void AJRCharacter::HandleReload(const FInputActionValue& Value)
{
	if (bWeaponEquipped && !bWeaponTransition)
	{
		WeaponComponent->StartReload();
	}
}

void AJRCharacter::HandleInteract(const FInputActionValue& Value)
{
	InteractionComponent->TryInteract();
}

void AJRCharacter::PlayExitVehicleSequence()
{
	PlayExitFromVehicle(nullptr, GetActorTransform());
}

void AJRCharacter::PlayExitFromVehicle(AActor* FromVehicle, const FTransform& SeatTransform)
{
	UAnimInstance* Anim = GetMesh()->GetAnimInstance();
	if (!ExitVehicleMontage || !Anim)
	{
		return;
	}
	if (FromVehicle)
	{
		// Coloca o personagem no banco (no chão, abaixo do banco), ignorando a colisão do carro
		// até a animação terminar de levá-lo para fora.
		const FVector Seat = SeatTransform.GetLocation();
		FCollisionQueryParams Params(SCENE_QUERY_STAT(JRSeatGround), false, FromVehicle);
		Params.AddIgnoredActor(this);
		FHitResult Hit;
		float GroundZ = Seat.Z - 60.f;
		if (GetWorld()->LineTraceSingleByChannel(Hit, Seat + FVector(0.f, 0.f, 50.f), Seat - FVector(0.f, 0.f, 500.f), ECC_Visibility, Params))
		{
			GroundZ = Hit.ImpactPoint.Z;
		}
		ExitingVehicle = FromVehicle;
		GetCapsuleComponent()->IgnoreActorWhenMoving(FromVehicle, true);
		// Sem isso o braço da câmera bate na carroceria e a câmera entra no carro.
		SpringArm->bDoCollisionTest = false;
		// O carro também precisa ignorar o personagem, senão a física "expulsa" o carro longe.
		if (UPrimitiveComponent* VehicleBody = Cast<UPrimitiveComponent>(FromVehicle->GetRootComponent()))
		{
			ExitVehiclePawnResponse = VehicleBody->GetCollisionResponseToChannel(ECC_Pawn);
			VehicleBody->SetCollisionResponseToChannel(ECC_Pawn, ECR_Ignore);
			VehicleBody->SetPhysicsLinearVelocity(FVector::ZeroVector);
			VehicleBody->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
		}
		const FRotator Yaw(0.f, SeatTransform.Rotator().Yaw, 0.f);
		SetActorLocationAndRotation(FVector(Seat.X, Seat.Y, GroundZ + GetCapsuleComponent()->GetScaledCapsuleHalfHeight()),
			Yaw, false, nullptr, ETeleportType::TeleportPhysics);
		if (AController* C = GetController())
		{
			C->SetControlRotation(Yaw);
		}
	}
	if (AController* C = GetController())
	{
		C->SetIgnoreMoveInput(true);
	}
	Anim->Montage_Play(ExitVehicleMontage);
	FOnMontageBlendingOutStarted BlendOutDelegate;
	BlendOutDelegate.BindUObject(this, &AJRCharacter::HandleExitBlendingOut);
	Anim->Montage_SetBlendingOutDelegate(BlendOutDelegate, ExitVehicleMontage);
	FOnMontageEnded EndDelegate;
	EndDelegate.BindUObject(this, &AJRCharacter::HandleMontageEnded);
	Anim->Montage_SetEndDelegate(EndDelegate, ExitVehicleMontage);
}

void AJRCharacter::HandleExitBlendingOut(UAnimMontage* Montage, bool bInterrupted)
{
	// A animação do Mixamo move o quadril para fora do carro; leva a cápsula até lá e corta a
	// montage na hora, para não haver "pulo" de volta ao banco.
	const FVector Pelvis = GetMesh()->GetBoneLocation(TEXT("pelvis"));
	const FVector Loc = GetActorLocation();
	SetActorLocation(FVector(Pelvis.X, Pelvis.Y, Loc.Z), false, nullptr, ETeleportType::TeleportPhysics);
	if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
	{
		Anim->Montage_Stop(0.f, Montage);
	}
	SpringArm->bDoCollisionTest = true;
	if (AActor* Vehicle = ExitingVehicle.Get())
	{
		GetCapsuleComponent()->IgnoreActorWhenMoving(Vehicle, false);
		if (UPrimitiveComponent* VehicleBody = Cast<UPrimitiveComponent>(Vehicle->GetRootComponent()))
		{
			VehicleBody->SetCollisionResponseToChannel(ECC_Pawn, ExitVehiclePawnResponse);
		}
	}
	ExitingVehicle.Reset();
}

void AJRCharacter::HandleMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (AController* C = GetController())
	{
		C->ResetIgnoreMoveInput();
	}
}

float AJRCharacter::PlayRescueHug()
{
	WeaponComponent->CancelAll();
	return RescueHugMontage ? PlayAnimMontage(RescueHugMontage) : 0.f;
}

void AJRCharacter::ApplySkin(const FJRSkinDefinition& Skin)
{
	if (USkeletalMesh* SkinMesh = Skin.Mesh.LoadSynchronous())
	{
		GetMesh()->SetSkeletalMeshAsset(SkinMesh);
	}
	for (int32 Slot = 0; Slot < Skin.MaterialOverrides.Num(); ++Slot)
	{
		if (UMaterialInterface* Material = Skin.MaterialOverrides[Slot].LoadSynchronous())
		{
			GetMesh()->SetMaterial(Slot, Material);
		}
	}
}

void AJRCharacter::HandleDeath(UJRHealthComponent* Health, AActor* Killer)
{
	WeaponComponent->CancelAll();
	if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
	{
		Anim->StopAllMontages(0.1f);
	}
	if (AController* C = GetController())
	{
		C->SetIgnoreMoveInput(true);
		C->SetIgnoreLookInput(true);
	}
	GetCharacterMovement()->DisableMovement();
	if (DeathMontage)
	{
		PlayAnimMontage(DeathMontage);
	}
	GetWorldTimerManager().SetTimer(FailureTimer, this, &AJRCharacter::NotifyFailure, FailureDelay, false);
}

void AJRCharacter::NotifyFailure()
{
	if (AJRGameMode* GameMode = GetWorld()->GetAuthGameMode<AJRGameMode>())
	{
		GameMode->HandlePlayerFailure(this);
	}
}

void AJRCharacter::ResetForRespawn()
{
	HealthComponent->ResetHealth();
	if (UAnimInstance* Anim = GetMesh()->GetAnimInstance())
	{
		Anim->StopAllMontages(0.f);
	}
	GetCharacterMovement()->SetMovementMode(MOVE_Walking);
	if (AController* C = GetController())
	{
		C->ResetIgnoreInputFlags();
	}
}
