// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interactions/JRInteractable.h"
#include "JRPickup.generated.h"

class UPointLightComponent;
class URotatingMovementComponent;
class USphereComponent;
class UStaticMesh;
class UStaticMeshComponent;

/** Tipos de item coletável. */
UENUM(BlueprintType)
enum class EJRPickupType : uint8
{
	Ammo,     // munição de reserva (a pé)
	Health,   // cura o personagem
	Nitro,    // carga de nitro (no carro)
	Fury,     // poder temporário: tiro mais forte e rápido
	Repair,   // conserta o carro
	WeaponMelee,   // graveto alien (pegar com E)
	WeaponPistol,  // pistola (pegar com E)
	WeaponShotgun  // escopeta alien (pegar com E)
};

/**
 * Item no mapa ou dropado por zumbi. Visual simples (formas básicas da engine coloridas),
 * gira e flutua; coleta por sobreposição. Sem Tick (rotação por componente).
 */
UCLASS()
class JOGORESGATE_API AJRPickup : public AActor, public IJRInteractable
{
	GENERATED_BODY()

public:
	AJRPickup();

	/** Define tipo e quantidade (use antes de FinishSpawning ou logo após o spawn). */
	UFUNCTION(BlueprintCallable, Category = "Pickup")
	void Setup(EJRPickupType InType, float InAmount);

	/** Spawna um item no chão (usado no drop dos zumbis). */
	static AJRPickup* SpawnPickup(UWorld* World, EJRPickupType InType, float InAmount, const FVector& Location, float LifeSeconds = 0.f);

	UFUNCTION(BlueprintPure, Category = "Pickup")
	EJRPickupType GetPickupType() const { return Type; }

	void SetDisplayMesh(UStaticMesh* InMesh, float InScale)
	{
		DisplayMesh = InMesh;
		DisplayScale = InScale;
		ApplyVisual();
	}

	/** Armas não são coletadas encostando: o jogador aperta E e pega do chão (animação). */
	bool IsWeapon() const { return Type >= EJRPickupType::WeaponMelee; }

	virtual bool CanInteract_Implementation(AActor* InstigatorActor) const override;
	virtual void Interact_Implementation(AActor* InstigatorActor) override;
	virtual FText GetInteractionText_Implementation() const override;

protected:
	virtual void BeginPlay() override;
	virtual void OnConstruction(const FTransform& Transform) override;

	UFUNCTION()
	void HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	bool TryApply(AActor* Collector);
	void ApplyVisual();

	UPROPERTY(VisibleAnywhere, Category = "Pickup")
	TObjectPtr<USphereComponent> Trigger;

	UPROPERTY(VisibleAnywhere, Category = "Pickup")
	TObjectPtr<UStaticMeshComponent> Mesh;

	UPROPERTY(VisibleAnywhere, Category = "Pickup")
	TObjectPtr<UPointLightComponent> Glow;

	UPROPERTY(VisibleAnywhere, Category = "Pickup")
	TObjectPtr<URotatingMovementComponent> Rotator;

	UPROPERTY(EditAnywhere, Category = "Pickup")
	EJRPickupType Type = EJRPickupType::Ammo;

	/** Ammo: balas; Health: vida; Nitro: carga 0..1; Fury: segundos; Repair: 0..1 do carro. */
	UPROPERTY(EditAnywhere, Category = "Pickup")
	float Amount = 12.f;

	/** Malha mostrada para itens de arma (graveto, pistola...). Vazio = forma básica. */
	UPROPERTY(EditAnywhere, Category = "Pickup")
	TObjectPtr<UStaticMesh> DisplayMesh;

	UPROPERTY(EditAnywhere, Category = "Pickup")
	float DisplayScale = 1.f;

	bool bTaken = false;
};
