// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "JRStoryTrigger.generated.h"

class UBoxComponent;

/**
 * Momento da história: quando o jogador entra, mostra uma fala/aviso e troca a dica de objetivo
 * do HUD (ex.: "Procure algo para se defender", "Revire a casa"). Uma vez por fase.
 */
UCLASS()
class JOGORESGATE_API AJRStoryTrigger : public AActor
{
	GENERATED_BODY()

public:
	AJRStoryTrigger();

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UPROPERTY(VisibleAnywhere, Category = "Story")
	TObjectPtr<UBoxComponent> Box;

	/** Fala/aviso mostrado ao entrar. */
	UPROPERTY(EditAnywhere, Category = "Story")
	FString Message;

	/** Nova dica de objetivo (vazio = mantém). */
	UPROPERTY(EditAnywhere, Category = "Story")
	FString ObjectiveHint;

	/** Só dispara a pé (true) ou também no carro. */
	UPROPERTY(EditAnywhere, Category = "Story")
	bool bOnFootOnly = false;

private:
	bool bDone = false;
};
