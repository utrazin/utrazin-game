// Copyright utrazin. All Rights Reserved.

#include "Gameplay/JRStoryTrigger.h"
#include "Characters/JRCharacter.h"
#include "Components/BoxComponent.h"
#include "Engine/World.h"
#include "GameFramework/PlayerController.h"
#include "UI/JRHUD.h"

AJRStoryTrigger::AJRStoryTrigger()
{
	PrimaryActorTick.bCanEverTick = false;
	Box = CreateDefaultSubobject<UBoxComponent>(TEXT("Box"));
	Box->SetBoxExtent(FVector(800.f, 800.f, 400.f));
	Box->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	RootComponent = Box;
}

void AJRStoryTrigger::BeginPlay()
{
	Super::BeginPlay();
	Box->OnComponentBeginOverlap.AddDynamic(this, &AJRStoryTrigger::HandleOverlap);
}

void AJRStoryTrigger::HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	const APawn* Pawn = Cast<APawn>(OtherActor);
	if (bDone || !Pawn || !Pawn->IsPlayerControlled() || (bOnFootOnly && !Pawn->IsA<AJRCharacter>()))
	{
		return;
	}
	bDone = true;
	const APlayerController* PC = Cast<APlayerController>(Pawn->GetController());
	if (AJRHUD* Hud = PC ? Cast<AJRHUD>(PC->GetHUD()) : nullptr)
	{
		if (!Message.IsEmpty())
		{
			Hud->ShowToast(Message, FLinearColor(1.f, 0.95f, 0.7f));
		}
		if (!ObjectiveHint.IsEmpty())
		{
			Hud->SetObjectiveHint(ObjectiveHint);
		}
	}
}
