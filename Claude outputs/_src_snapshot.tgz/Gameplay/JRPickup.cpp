// Copyright utrazin. All Rights Reserved.

#include "Gameplay/JRPickup.h"
#include "Characters/JRCharacter.h"
#include "Combat/JRHealthComponent.h"
#include "Combat/JRWeaponComponent.h"
#include "Components/PointLightComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "GameFramework/RotatingMovementComponent.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Materials/MaterialInterface.h"
#include "UI/JRHUD.h"
#include "Vehicles/JRVehicleDamageComponent.h"
#include "Vehicles/JRVehiclePawn.h"

namespace
{
	const TCHAR* MeshFor(EJRPickupType T)
	{
		switch (T)
		{
		case EJRPickupType::Health: return TEXT("/Engine/BasicShapes/Sphere.Sphere");
		case EJRPickupType::Nitro: return TEXT("/Engine/BasicShapes/Cylinder.Cylinder");
		case EJRPickupType::Fury: return TEXT("/Engine/BasicShapes/Cone.Cone");
		case EJRPickupType::Repair: return TEXT("/Engine/BasicShapes/Cube.Cube");
		case EJRPickupType::WeaponMelee:
		case EJRPickupType::WeaponPistol:
		case EJRPickupType::WeaponShotgun: return TEXT("/Engine/BasicShapes/Cone.Cone");
		default: return TEXT("/Engine/BasicShapes/Cube.Cube");
		}
	}

	FLinearColor ColorFor(EJRPickupType T)
	{
		switch (T)
		{
		case EJRPickupType::Health: return FLinearColor(1.f, 0.12f, 0.15f);
		case EJRPickupType::Nitro: return FLinearColor(0.1f, 0.55f, 1.f);
		case EJRPickupType::Fury: return FLinearColor(0.75f, 0.2f, 1.f);
		case EJRPickupType::Repair: return FLinearColor(0.2f, 1.f, 0.35f);
		case EJRPickupType::WeaponMelee:
		case EJRPickupType::WeaponPistol:
		case EJRPickupType::WeaponShotgun: return FLinearColor(0.2f, 1.f, 0.9f);
		default: return FLinearColor(1.f, 0.8f, 0.1f);
		}
	}
}

AJRPickup::AJRPickup()
{
	PrimaryActorTick.bCanEverTick = false;
	Trigger = CreateDefaultSubobject<USphereComponent>(TEXT("Trigger"));
	Trigger->InitSphereRadius(140.f);
	Trigger->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
	RootComponent = Trigger;

	Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	Mesh->SetupAttachment(Trigger);
	Mesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Mesh->SetRelativeLocation(FVector(0.f, 0.f, 40.f));
	Mesh->SetRelativeScale3D(FVector(0.45f));

	Glow = CreateDefaultSubobject<UPointLightComponent>(TEXT("Glow"));
	Glow->SetupAttachment(Mesh);
	Glow->SetIntensity(2500.f);
	Glow->SetAttenuationRadius(350.f);
	Glow->SetCastShadows(false);

	Rotator = CreateDefaultSubobject<URotatingMovementComponent>(TEXT("Rotator"));
	Rotator->RotationRate = FRotator(0.f, 120.f, 0.f);
	Rotator->SetUpdatedComponent(Mesh);
}

void AJRPickup::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	ApplyVisual();
}

void AJRPickup::BeginPlay()
{
	Super::BeginPlay();
	ApplyVisual();
	Trigger->OnComponentBeginOverlap.AddDynamic(this, &AJRPickup::HandleOverlap);
}

void AJRPickup::Setup(EJRPickupType InType, float InAmount)
{
	Type = InType;
	Amount = InAmount;
	ApplyVisual();
}

void AJRPickup::ApplyVisual()
{
	const FLinearColor Color = ColorFor(Type);
	Glow->SetLightColor(Color);
	// Arma: a própria malha, deitada no chão, sem girar; pode ser alvo do traço de interação.
	if (IsWeapon())
	{
		Mesh->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		Mesh->SetCollisionResponseToAllChannels(ECR_Ignore);
		Mesh->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);
		Rotator->RotationRate = FRotator(0.f, 25.f, 0.f);
		if (DisplayMesh)
		{
			Mesh->SetStaticMesh(DisplayMesh);
			Mesh->SetRelativeScale3D(FVector(DisplayScale));
			Mesh->SetRelativeLocation(FVector(0.f, 0.f, 15.f));
			return;
		}
	}
	if (UStaticMesh* Shape = LoadObject<UStaticMesh>(nullptr, MeshFor(Type)))
	{
		Mesh->SetStaticMesh(Shape);
	}
	if (UMaterialInterface* Base = LoadObject<UMaterialInterface>(nullptr, TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial")))
	{
		if (UMaterialInstanceDynamic* MID = Mesh->CreateDynamicMaterialInstance(0, Base))
		{
			MID->SetVectorParameterValue(TEXT("Color"), Color);
		}
	}
	Glow->SetLightColor(Color);
}

AJRPickup* AJRPickup::SpawnPickup(UWorld* World, EJRPickupType InType, float InAmount, const FVector& Location, float LifeSeconds)
{
	if (!World)
	{
		return nullptr;
	}
	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	AJRPickup* Pickup = World->SpawnActor<AJRPickup>(AJRPickup::StaticClass(), Location, FRotator::ZeroRotator, Params);
	if (Pickup)
	{
		Pickup->Setup(InType, InAmount);
		if (LifeSeconds > 0.f)
		{
			Pickup->SetLifeSpan(LifeSeconds);
		}
	}
	return Pickup;
}

void AJRPickup::HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	const APawn* Pawn = Cast<APawn>(OtherActor);
	if (!IsWeapon() && !bTaken && Pawn && Pawn->IsPlayerControlled() && TryApply(OtherActor))
	{
		bTaken = true;
		Destroy();
	}
}

bool AJRPickup::CanInteract_Implementation(AActor* InstigatorActor) const
{
	return IsWeapon() && !bTaken && Cast<AJRCharacter>(InstigatorActor) != nullptr;
}

FText AJRPickup::GetInteractionText_Implementation() const
{
	switch (Type)
	{
	case EJRPickupType::WeaponMelee: return NSLOCTEXT("JogoResgate", "PickStick", "Pegar o graveto alien");
	case EJRPickupType::WeaponPistol: return NSLOCTEXT("JogoResgate", "PickPistol", "Pegar a pistola");
	case EJRPickupType::WeaponShotgun: return NSLOCTEXT("JogoResgate", "PickShotgun", "Pegar a escopeta alien");
	default: return FText::GetEmpty();
	}
}

void AJRPickup::Interact_Implementation(AActor* InstigatorActor)
{
	AJRCharacter* Hero = Cast<AJRCharacter>(InstigatorActor);
	if (!Hero || bTaken)
	{
		return;
	}
	bTaken = true;
	const EJRWeaponSlot Slot = Type == EJRPickupType::WeaponMelee ? EJRWeaponSlot::Melee
		: Type == EJRPickupType::WeaponPistol ? EJRWeaponSlot::Pistol : EJRWeaponSlot::Shotgun;
	Hero->PickUpWeaponFromGround(Slot);
	AJRHUD::Toast(this, FString::Printf(TEXT("Você pegou: %s"), *GetInteractionText_Implementation().ToString().Replace(TEXT("Pegar "), TEXT(""))),
		FLinearColor(0.2f, 1.f, 0.8f));
	SetLifeSpan(0.9f); // some quando a mão chega no chão
	Glow->SetVisibility(false);
}

bool AJRPickup::TryApply(AActor* Collector)
{
	if (AJRCharacter* Hero = Cast<AJRCharacter>(Collector))
	{
		switch (Type)
		{
		case EJRPickupType::Ammo:
			Hero->GetWeaponComponent()->AddReserveAmmo(FMath::RoundToInt(Amount));
			AJRHUD::Toast(this, FString::Printf(TEXT("+%d células"), FMath::RoundToInt(Amount)), FLinearColor(1.f, 0.85f, 0.2f));
			return true;
		case EJRPickupType::Health:
			if (Hero->GetHealthComponent()->GetHealthNormalized() >= 1.f)
			{
				return false; // vida cheia: deixa o item para depois
			}
			Hero->GetHealthComponent()->Heal(Amount);
			AJRHUD::Toast(this, FString::Printf(TEXT("+%d de vida"), FMath::RoundToInt(Amount)), FLinearColor(1.f, 0.35f, 0.35f));
			return true;
		case EJRPickupType::Fury:
			Hero->ActivateFury(Amount);
			AJRHUD::Toast(this, TEXT("FÚRIA! Tiros mais fortes"), FLinearColor(0.8f, 0.3f, 1.f));
			return true;
		default:
			return false;
		}
	}
	if (AJRVehiclePawn* Vehicle = Cast<AJRVehiclePawn>(Collector))
	{
		switch (Type)
		{
		case EJRPickupType::Nitro:
			Vehicle->AddNitro(Amount);
			AJRHUD::Toast(this, TEXT("+ Nitro"), FLinearColor(0.3f, 0.7f, 1.f));
			return true;
		case EJRPickupType::Repair:
			if (UJRVehicleDamageComponent* Damage = Vehicle->GetDamageComponent())
			{
				Damage->RepairAll();
			}
			AJRHUD::Toast(this, TEXT("Carro consertado!"), FLinearColor(0.3f, 1.f, 0.5f));
			return true;
		default:
			return false;
		}
	}
	return false;
}
