// Copyright utrazin. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "AI/JREnemyStateLogic.h"
#include "Gameplay/JRPickup.h"
#include "GameFramework/Character.h"
#include "JREnemyCharacter.generated.h"

class UJREnemyArchetype;
class AJRVehiclePawn;
class AAIController;
class UJRHealthComponent;
class UStaticMesh;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FJROnEnemyDied, AJREnemyCharacter*, Enemy);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FJROnEnemyStateChanged, EJREnemyState, OldState, EJREnemyState, NewState);

/**
 * Inimigo genérico parametrizado por UJREnemyArchetype (ADR-002).
 * Decisão de estado: FJREnemyStateLogic. Execução: este ator, por timer (não Tick), com
 * frequência definida pelo UJREnemyBudgetSubsystem. Um StateTree no AIController pode assumir
 * a decisão (bUseBuiltInBrain = false) chamando as funções BlueprintCallable abaixo.
 */
UCLASS()
class JOGORESGATE_API AJREnemyCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	AJREnemyCharacter();

	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void SetFullUpdate(bool bFull);

	UFUNCTION(BlueprintPure, Category = "Enemy")
	bool IsFullUpdate() const { return bFullUpdate; }

	UFUNCTION(BlueprintPure, Category = "Enemy")
	EJREnemyState GetEnemyState() const { return CurrentState; }

	UFUNCTION(BlueprintPure, Category = "Enemy")
	bool IsDead() const { return CurrentState == EJREnemyState::Dead; }

	UFUNCTION(BlueprintPure, Category = "Enemy")
	UJREnemyArchetype* GetArchetype() const { return Archetype; }

	/** Uma iteração de percepção + decisão + ação. Chamado pelo timer ou por task de StateTree. */
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void UpdateBrain();

	/** Executa o ataque do arquétipo contra o alvo atual, respeitando o intervalo. */
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	bool TryAttack();

	/** Atropelado: arremessa (ragdoll) ou derruba, e danifica o carro. */
	void HitByVehicle(AActor* Vehicle);

	/** Faz o zumbi caçar o jogador mesmo longe/sem visão (zumbis que "chegam" pelo mapa). */
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void SetForceAggro(bool bForce) { bForceAggro = bForce; }

	/** Barricada: fica parado no lugar enquanto o jogador estiver no carro longe (vira obstáculo na estrada). */
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void SetHoldPosition(bool bHold) { bHoldPosition = bHold; }

	/** Morre arremessado (ragdoll) com esta velocidade (cm/s). Usado pela explosão do carro e ao cair do carro. */
	void KillWithLaunch(const FVector& LaunchVelocity, AController* InstigatorController, AActor* Causer);

	/** Agarrado no carro (capô ou lateral)? */
	UFUNCTION(BlueprintPure, Category = "Enemy")
	bool IsGrabbingVehicle() const { return GrabbedVehicle.IsValid(); }

	/** Tenta pular/agarrar no carro (ponto livre mais próximo). */
	bool TryGrabVehicle(AJRVehiclePawn* Car);

	/** Solta do carro. bKill = arremessado e morto (sacudida/batida); senão cai ao lado e volta a perseguir. */
	void ReleaseFromVehicle(bool bKill, const FVector& LaunchVelocity);

	/** Teto de ragdolls ativos: congela o corpo e encurta o tempo até sumir. */
	void FreezeRagdoll();

	UPROPERTY(BlueprintAssignable, Category = "Enemy")
	FJROnEnemyDied OnEnemyDied;

	UPROPERTY(BlueprintAssignable, Category = "Enemy")
	FJROnEnemyStateChanged OnEnemyStateChanged;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	UFUNCTION()
	void HandleDeath(UJRHealthComponent* Health, AActor* Killer);

	UFUNCTION()
	void HandleHealthChanged(UJRHealthComponent* Health, float NewHealth, float Delta);

	void ResolveMeleeHit();

	UFUNCTION()
	void HandleCapsuleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	void DropLoot();

	/** Chance (0..1) de deixar um item ao morrer. */
	UPROPERTY(EditAnywhere, Category = "Enemy|Loot")
	float DropChance = 0.45f;

	/** Zumbi especial (elite): sempre deixa este item (ex.: escopeta alien). */
	UPROPERTY(EditAnywhere, Category = "Enemy|Loot")
	bool bHasGuaranteedDrop = false;

	UPROPERTY(EditAnywhere, Category = "Enemy|Loot")
	EJRPickupType GuaranteedDrop = EJRPickupType::WeaponShotgun;

	UPROPERTY(EditAnywhere, Category = "Enemy|Loot")
	TObjectPtr<UStaticMesh> GuaranteedDropMesh;

	/** Tempo entre começar o golpe e o dano (o jogador pode desviar). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Combat", meta = (Units = "s"))
	float MeleeWindup = 0.45f;

	/** Cada zumbi chega por um ângulo diferente (cerca o jogador) até esta distância. */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Combat", meta = (Units = "cm"))
	float FlankDistance = 450.f;

	/** Persegue o carro do jogador até esta distância da lataria (carro faz barulho: não precisa de visão). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "cm"))
	float VehicleChaseRadius = 4000.f;

	/** Corre para onde o carro VAI estar daqui a até este tempo (intercepta em vez de correr atrás). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "s"))
	float VehicleInterceptMaxTime = 1.5f;

	/** Grupo correndo para o carro se espalha até esta distância para cada lado da estrada (cerca a pista). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "cm"))
	float VehicleRoadSpread = 250.f;

	/** Fração do AttackDamage aplicada à lataria por soco (o carro aguenta mais que o herói). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (ClampMin = "0"))
	float VehicleAttackDamageScale = 0.3f;

	/** Distância da lataria em que o zumbi consegue agarrar o carro. */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "cm"))
	float GrabReach = 120.f;

	/** Chance por decisão (a cada 0,1 a 0,5 s) de agarrar quando está colado no carro devagar. */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (ClampMin = "0", ClampMax = "1"))
	float GrabChance = 0.15f;

	/** Chance de agarrar quando o carro devagar esbarra nele (em vez de só empurrar). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (ClampMin = "0", ClampMax = "1"))
	float GrabWhenBumpedChance = 0.35f;

	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "s"))
	float GrabCooldown = 3.f;

	/** Intervalo dos golpes enquanto agarrado (toca a montage de ataque em loop). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "s"))
	float GrabAttackInterval = 1.f;

	/** Dano na zona do carro por segundo, por zumbi agarrado (no capô, metade vai também para o motor). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (ClampMin = "0"))
	float GrabDamagePerSecond = 4.f;

	/** Fração da velocidade que o carro perde a cada zumbi arremessado (o carro limita o total). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (ClampMin = "0", ClampMax = "1"))
	float RunOverDragFraction = 0.06f;

	/** Abaixo desta velocidade o carro encostando não empurra nem machuca (zumbi andando até o carro parado). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "km/h"))
	float BumpMinSpeedKmh = 8.f;

	/** Barricada: solta o zumbi quando o carro chega a esta distância (ou se o jogador estiver a pé). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "cm"))
	float HoldReleaseDistance = 500.f;

	/** Cambaleia ao levar tiro (para de andar por este tempo). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Combat", meta = (Units = "s"))
	float StaggerTime = 0.3f;

	/** Velocidade do carro (km/h) NA DIREÇÃO do zumbi a partir da qual ele é arremessado (ragdoll). */
	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle", meta = (Units = "km/h"))
	float RunOverSpeedKmh = 18.f;

	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Vehicle")
	float RunOverCarDamage = 3.f;

	void SetEnemyState(EJREnemyState NewState);
	/** Persegue o carro: intercepta a posição prevista; perto ou devagar, vai até a lataria. */
	void MoveTowardVehicle(AAIController* AI, AJRVehiclePawn* Car, float BodyDistance, const FVector& ContactPoint);
	/** Golpe periódico enquanto agarrado no carro. */
	void TickGrab();
	void RestartBrainTimer();
	void FireRangedShot();
	FVector GetMuzzleLocation() const;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Enemy")
	TObjectPtr<UJRHealthComponent> HealthComponent;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Enemy")
	TObjectPtr<UJREnemyArchetype> Archetype;

	UPROPERTY(EditAnywhere, Category = "Enemy")
	bool bUseBuiltInBrain = true;

	UPROPERTY(EditAnywhere, Category = "Enemy")
	bool bHasPatrol = false;

	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Performance", meta = (Units = "s"))
	float FullUpdateInterval = 0.1f;

	UPROPERTY(EditDefaultsOnly, Category = "Enemy|Performance", meta = (Units = "s"))
	float ReducedUpdateInterval = 0.5f;

	UPROPERTY(EditDefaultsOnly, Category = "Enemy")
	FName MuzzleSocket = TEXT("hand_r");

private:
	TWeakObjectPtr<AActor> Target;
	FTimerHandle BrainTimer;
	FTimerHandle BurstTimer;
	FRandomStream Random;
	EJREnemyState CurrentState = EJREnemyState::Idle;
	double StateEnterTime = 0.0;
	double LastAttackTime = -1000.0;
	int32 BurstShotsRemaining = 0;
	bool bFullUpdate = false;
	bool bLoggedMoveFailure = false;
	bool bStateInitialized = false;
	bool bForceAggro = false;
	bool bKilledByVehicle = false;
	float FlankAngle = 0.f;
	double StaggerUntil = 0.0;
	FTimerHandle MeleeHitTimer;
	double LastVehicleHitTime = -10.0;
	FVector PendingLaunch = FVector::ZeroVector;
	int32 BrainDebugLogsLeft = 3;
	bool bHoldPosition = false;
	TWeakObjectPtr<AJRVehiclePawn> GrabbedVehicle;
	int32 GrabSlot = INDEX_NONE;
	double NextGrabTime = 0.0;
	FTimerHandle GrabTimer;
};
