// Copyright utrazin. All Rights Reserved.

#include "AI/JREnemyCharacter.h"
#include "AI/JRAIDirector.h"
#include "AI/JRAimPrediction.h"
#include "AI/JREnemyArchetype.h"
#include "AI/JREnemyBudgetSubsystem.h"
#include "AIController.h"
#include "Navigation/PathFollowingComponent.h"
#include "Combat/JRHealthComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "JogoResgate.h"
#include "TimerManager.h"
#include "Vehicles/JRVehicleDamageComponent.h"
#include "Vehicles/JRVehiclePawn.h"

AJREnemyCharacter::AJREnemyCharacter()
{
	PrimaryActorTick.bCanEverTick = false;
	AutoPossessAI = EAutoPossessAI::PlacedInWorldOrSpawned;
	AIControllerClass = AAIController::StaticClass();
	HealthComponent = CreateDefaultSubobject<UJRHealthComponent>(TEXT("HealthComponent"));
	GetCharacterMovement()->bOrientRotationToMovement = true;
	bUseControllerRotationYaw = false;
}

void AJREnemyCharacter::BeginPlay()
{
	Super::BeginPlay();
	Random.GenerateNewSeed();
	if (Archetype)
	{
		HealthComponent->SetMaxHealth(Archetype->MaxHealth, true);
		GetCharacterMovement()->MaxWalkSpeed = Archetype->MoveSpeed;
	}
	HealthComponent->OnDeath.AddDynamic(this, &AJREnemyCharacter::HandleDeath);
	// O carro atravessa o zumbi (sobreposição) em vez de bater num "poste": nada de atolar.
	GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Vehicle, ECR_Overlap);
	GetCapsuleComponent()->SetGenerateOverlapEvents(true);
	GetMesh()->SetCollisionResponseToChannel(ECC_Vehicle, ECR_Ignore);
	GetCapsuleComponent()->OnComponentBeginOverlap.AddDynamic(this, &AJREnemyCharacter::HandleCapsuleOverlap);
	GetCharacterMovement()->MaxWalkSpeed *= Random.FRandRange(0.85f, 1.2f); // grupos menos "robóticos"
	FlankAngle = Random.FRandRange(-75.f, 75.f);
	HealthComponent->OnHealthChanged.AddDynamic(this, &AJREnemyCharacter::HandleHealthChanged);
	SetEnemyState(bHasPatrol ? EJREnemyState::Patrol : EJREnemyState::Idle);

	if (UJREnemyBudgetSubsystem* Budget = GetWorld()->GetSubsystem<UJREnemyBudgetSubsystem>())
	{
		Budget->RegisterEnemy(this); // define full/reduced e inicia o timer
	}
	else
	{
		SetFullUpdate(true);
	}
}

void AJREnemyCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (UJREnemyBudgetSubsystem* Budget = GetWorld()->GetSubsystem<UJREnemyBudgetSubsystem>())
	{
		Budget->UnregisterEnemy(this);
	}
	if (AJRVehiclePawn* Car = GrabbedVehicle.Get())
	{
		Car->ReleaseGrabSlot(this);
	}
	GrabbedVehicle.Reset();
	GetWorldTimerManager().ClearTimer(BrainTimer);
	GetWorldTimerManager().ClearTimer(BurstTimer);
	GetWorldTimerManager().ClearTimer(GrabTimer);
	Super::EndPlay(EndPlayReason);
}

void AJREnemyCharacter::SetFullUpdate(bool bFull)
{
	if (bFull == bFullUpdate && BrainTimer.IsValid())
	{
		return;
	}
	bFullUpdate = bFull;
	RestartBrainTimer();
}

void AJREnemyCharacter::RestartBrainTimer()
{
	if (IsDead() || !bUseBuiltInBrain)
	{
		return;
	}
	const float Interval = bFullUpdate ? FullUpdateInterval : ReducedUpdateInterval;
	UE_LOG(LogJR, Log, TEXT("IA %s: cérebro ligado (%s, a cada %.2fs)"), *GetName(), bFullUpdate ? TEXT("completo") : TEXT("reduzido"), Interval);
	// Desfasa inimigos para não decidirem todos no mesmo frame.
	GetWorldTimerManager().SetTimer(BrainTimer, this, &AJREnemyCharacter::UpdateBrain, Interval, true, Random.FRandRange(0.f, Interval));
}

void AJREnemyCharacter::SetEnemyState(EJREnemyState NewState)
{
	if (NewState == CurrentState && bStateInitialized)
	{
		return;
	}
	bStateInitialized = true;
	const EJREnemyState Old = CurrentState;
	CurrentState = NewState;
	StateEnterTime = GetWorld()->GetTimeSeconds();
	if (NewState == EJREnemyState::Alert && Archetype && Archetype->AlertSound)
	{
		UGameplayStatics::PlaySoundAtLocation(this, Archetype->AlertSound, GetActorLocation());
	}
	UE_LOG(LogJR, Log, TEXT("IA %s: %s -> %s (controller=%s)"), *GetName(), *UEnum::GetValueAsString(Old),
		*UEnum::GetValueAsString(NewState), *GetNameSafe(GetController()));
	OnEnemyStateChanged.Broadcast(Old, NewState);
}

void AJREnemyCharacter::UpdateBrain()
{
	if (IsDead() || !Archetype)
	{
		UE_LOG(LogJR, Warning, TEXT("IA %s: sem Archetype ou morto, cérebro parado"), *GetName());
		GetWorldTimerManager().ClearTimer(BrainTimer);
		return;
	}
	if (GrabbedVehicle.IsValid())
	{
		return; // agarrado no carro: TickGrab cuida
	}
	// O alvo é o pawn atual do jogador: veículo ou personagem (perseguição de ambos).
	APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(this, 0);
	Target = PlayerPawn;
	AAIController* AI = Cast<AAIController>(GetController());
	AJRVehiclePawn* Car = Cast<AJRVehiclePawn>(PlayerPawn);
	if (Car && Car->IsWrecked())
	{
		Car = nullptr;
	}
	FVector CarContact = FVector::ZeroVector;

	FJREnemyDecisionInput In;
	In.Current = CurrentState;
	In.TimeInState = static_cast<float>(GetWorld()->GetTimeSeconds() - StateEnterTime);
	if (Car)
	{
		// Carro: distância até a lataria (o centro do carro fica a mais de 2 m de quem está encostado).
		In.DistanceToTarget = Car->GetDistanceToBody(GetActorLocation(), &CarContact);
		// Carro faz barulho: dentro do raio de perseguição o zumbi sempre "sabe" onde ele está.
		In.bHasLineOfSight = In.DistanceToTarget <= VehicleChaseRadius;
	}
	else if (PlayerPawn)
	{
		In.DistanceToTarget = static_cast<float>(FVector::Dist(GetActorLocation(), PlayerPawn->GetActorLocation()));
		// Traço de visão só quando o alvo está perto o bastante para importar (custo).
		const bool bWorthTracing = In.DistanceToTarget <= Archetype->LoseAggroRadius;
		In.bHasLineOfSight = bWorthTracing && AI && AI->LineOfSightTo(PlayerPawn);
	}
	if (PlayerPawn && bForceAggro)
	{
		In.bHasLineOfSight = true;
		In.DistanceToTarget = FMath::Min(In.DistanceToTarget, Archetype->AggroRadius * 0.9f);
	}

	// Barricada: parado no meio da estrada até o carro chegar perto (ou o jogador descer).
	if (bHoldPosition)
	{
		if (Car && In.DistanceToTarget > HoldReleaseDistance)
		{
			if (AI)
			{
				AI->StopMovement();
				if (In.DistanceToTarget < VehicleChaseRadius)
				{
					AI->SetFocus(Car);
				}
			}
			return;
		}
		bHoldPosition = false;
	}

	FJREnemyDecisionParams P;
	P.AggroRadius = Archetype->AggroRadius;
	P.LoseAggroRadius = Archetype->LoseAggroRadius;
	P.AttackRange = Archetype->AttackRange;
	P.AlertDuration = Archetype->AlertDuration;
	P.bHasPatrol = bHasPatrol;

	if (Car)
	{
		// Carro: aggro e desistência maiores (o zumbi corre atrás do carro de longe).
		P.AggroRadius = FMath::Max(P.AggroRadius, VehicleChaseRadius);
		P.LoseAggroRadius = FMath::Max(P.LoseAggroRadius, VehicleChaseRadius * 1.25f);
	}
	EJREnemyState Next = FJREnemyStateLogic::Decide(In, P);
	if (GetWorld()->GetTimeSeconds() < StaggerUntil && Next != EJREnemyState::Dead)
	{
		if (AI)
		{
			AI->StopMovement();
		}
		return; // cambaleando
	}
	if (BrainDebugLogsLeft > 0 && PlayerPawn && In.DistanceToTarget < P.LoseAggroRadius)
	{
		--BrainDebugLogsLeft;
		UE_LOG(LogJR, Log, TEXT("IA %s: alvo=%s dist=%.0f visão=%d estado=%s -> %s"), *GetName(), *PlayerPawn->GetName(),
			In.DistanceToTarget, In.bHasLineOfSight ? 1 : 0, *UEnum::GetValueAsString(CurrentState), *UEnum::GetValueAsString(Next));
	}
	SetEnemyState(Next);

	// Colado no carro devagar: às vezes pula no capô/lateral e se agarra.
	if (Car && (Next == EJREnemyState::Chase || Next == EJREnemyState::Attack) && In.DistanceToTarget <= GrabReach
		&& Archetype->AttackType == EJREnemyAttackType::Melee && GetWorld()->GetTimeSeconds() >= NextGrabTime
		&& Random.FRand() < GrabChance && TryGrabVehicle(Car))
	{
		return;
	}

	if (!AI)
	{
		return;
	}
	switch (Next)
	{
	case EJREnemyState::Chase:
		if (Car)
		{
			MoveTowardVehicle(AI, Car, In.DistanceToTarget, CarContact);
		}
		else if (PlayerPawn && In.DistanceToTarget > FlankDistance)
		{
			// Longe: vai para um ponto ao lado do jogador (cada zumbi com seu ângulo) e cerca.
			const FVector ToMe = (GetActorLocation() - PlayerPawn->GetActorLocation()).GetSafeNormal2D();
			const FVector Side = ToMe.RotateAngleAxis(FlankAngle, FVector::UpVector);
			const FVector Goal = PlayerPawn->GetActorLocation() + Side * (FlankDistance * 0.6f);
			const EPathFollowingRequestResult::Type Result = AI->MoveToLocation(Goal, 80.f, true, true, true, true);
			if (Result == EPathFollowingRequestResult::Failed)
			{
				AI->MoveToActor(PlayerPawn, Archetype->AttackRange * 0.8f, true, true, true);
			}
		}
		else if (PlayerPawn)
		{
			const EPathFollowingRequestResult::Type Result = AI->MoveToActor(PlayerPawn, Archetype->AttackRange * 0.8f, true, true, true);
			if (Result == EPathFollowingRequestResult::Failed && !bLoggedMoveFailure)
			{
				bLoggedMoveFailure = true;
				UE_LOG(LogJR, Warning, TEXT("IA %s: MoveToActor falhou (sem navmesh ou alvo fora da navmesh?)"), *GetName());
			}
		}
		break;
	case EJREnemyState::Attack:
		AI->StopMovement();
		if (PlayerPawn)
		{
			AI->SetFocus(PlayerPawn);
		}
		TryAttack();
		break;
	case EJREnemyState::Alert:
		AI->StopMovement();
		if (PlayerPawn)
		{
			AI->SetFocus(PlayerPawn);
		}
		break;
	default:
		AI->ClearFocus(EAIFocusPriority::Gameplay);
		break;
	}
}

void AJREnemyCharacter::MoveTowardVehicle(AAIController* AI, AJRVehiclePawn* Car, float BodyDistance, const FVector& ContactPoint)
{
	const FVector CarVelocity = Car->GetVelocity();
	FVector Goal;
	if (CarVelocity.Size2D() < 300.f || BodyDistance < 400.f)
	{
		// Devagar ou perto: vai até o ponto mais próximo da lataria e para encostado nela.
		const float Radius = GetCapsuleComponent()->GetScaledCapsuleRadius();
		Goal = ContactPoint + (GetActorLocation() - ContactPoint).GetSafeNormal2D() * (Radius + 30.f);
	}
	else
	{
		// Andando: corre para onde o carro vai estar (intercepta).
		const float MySpeed = FMath::Max(GetCharacterMovement()->MaxWalkSpeed, 100.f);
		const float LeadTime = FMath::Min(BodyDistance / MySpeed, VehicleInterceptMaxTime);
		Goal = Car->GetActorLocation() + CarVelocity * LeadTime;
		// Cada zumbi mira um pouco para um lado da pista: o grupo "fecha" a estrada em vez de fazer fila.
		const FVector Side = FVector::CrossProduct(FVector::UpVector, CarVelocity.GetSafeNormal2D());
		Goal += Side * ((FlankAngle / 75.f) * VehicleRoadSpread);
	}
	const EPathFollowingRequestResult::Type Result = AI->MoveToLocation(Goal, 30.f, false, true, true, true);
	if (Result == EPathFollowingRequestResult::Failed)
	{
		AI->MoveToActor(Car, 50.f, false, true, true);
	}
}

bool AJREnemyCharacter::TryGrabVehicle(AJRVehiclePawn* Car)
{
	if (!Car || IsDead() || GrabbedVehicle.IsValid() || Car->IsWrecked())
	{
		return false;
	}
	const int32 Slot = Car->TryReserveGrabSlot(this);
	USceneComponent* Point = Slot != INDEX_NONE ? Car->GetGrabPoint(Slot) : nullptr;
	if (!Point)
	{
		if (Slot != INDEX_NONE)
		{
			Car->ReleaseGrabSlot(this);
		}
		return false;
	}
	GrabbedVehicle = Car;
	GrabSlot = Slot;
	GetWorldTimerManager().ClearTimer(MeleeHitTimer);
	if (AAIController* AI = Cast<AAIController>(GetController()))
	{
		AI->StopMovement();
		AI->ClearFocus(EAIFocusPriority::Gameplay);
	}
	// Sem física e sem colisão: vai "de carona" preso ao ponto do carro.
	GetCharacterMovement()->StopMovementImmediately();
	GetCharacterMovement()->DisableMovement();
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	AttachToComponent(Point, FAttachmentTransformRules(EAttachmentRule::SnapToTarget, EAttachmentRule::SnapToTarget,
		EAttachmentRule::KeepWorld, false));
	SetEnemyState(EJREnemyState::Attack);
	GetWorldTimerManager().SetTimer(GrabTimer, this, &AJREnemyCharacter::TickGrab, GrabAttackInterval, true, 0.2f);
	UE_LOG(LogJR, Log, TEXT("IA %s: agarrou o carro (ponto %d)"), *GetName(), Slot);
	Car->NotifyZombieCarEvent(EJRZombieCarEvent::ZombieGrabbed, this, GetActorLocation(), static_cast<float>(Slot));
	return true;
}

void AJREnemyCharacter::TickGrab()
{
	AJRVehiclePawn* Car = GrabbedVehicle.Get();
	if (!Car || IsDead() || Car->IsWrecked())
	{
		ReleaseFromVehicle(false, FVector::ZeroVector);
		return;
	}
	if (Archetype && Archetype->AttackMontage)
	{
		PlayAnimMontage(Archetype->AttackMontage);
	}
	if (UJRVehicleDamageComponent* Damage = Car->GetDamageComponent())
	{
		const float Amount = GrabDamagePerSecond * GrabAttackInterval;
		const EJRVehicleZone Zone = Car->GetGrabZone(GrabSlot);
		Damage->ApplyZoneDamage(Zone, Amount);
		if (Zone == EJRVehicleZone::Front && !Car->IsWrecked())
		{
			Damage->ApplyZoneDamage(EJRVehicleZone::Engine, Amount * 0.5f); // arranca peças do motor
		}
		Car->NotifyZombieCarEvent(EJRZombieCarEvent::ZombieHitCar, this, GetActorLocation(), Amount);
	}
}

void AJREnemyCharacter::ReleaseFromVehicle(bool bKill, const FVector& LaunchVelocity)
{
	AJRVehiclePawn* Car = GrabbedVehicle.Get();
	const bool bWasGrabbing = GrabbedVehicle.IsValid() || GrabSlot != INDEX_NONE;
	GetWorldTimerManager().ClearTimer(GrabTimer);
	GrabbedVehicle.Reset();
	GrabSlot = INDEX_NONE;
	if (Car)
	{
		Car->ReleaseGrabSlot(this);
	}
	if (!bWasGrabbing)
	{
		return;
	}
	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	SetActorRotation(FRotator(0.f, GetActorRotation().Yaw, 0.f));
	NextGrabTime = GetWorld()->GetTimeSeconds() + GrabCooldown;
	if (IsDead())
	{
		return;
	}
	if (bKill)
	{
		if (Car)
		{
			Car->NotifyZombieCarEvent(EJRZombieCarEvent::ZombieThrownOff, this, GetActorLocation(), static_cast<float>(Car->GetVelocity().Size()) * 0.036f);
		}
		KillWithLaunch(LaunchVelocity, Car ? Car->GetController() : nullptr, Car);
		return;
	}
	// Desceu vivo (jogador saiu do carro): cai ao lado e volta a perseguir.
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	GetCharacterMovement()->SetMovementMode(MOVE_Falling);
	SetEnemyState(EJREnemyState::Chase);
}

void AJREnemyCharacter::KillWithLaunch(const FVector& LaunchVelocity, AController* InstigatorController, AActor* Causer)
{
	if (IsDead())
	{
		return;
	}
	PendingLaunch = LaunchVelocity;
	bKilledByVehicle = true;
	UGameplayStatics::ApplyDamage(this, 9999.f, InstigatorController, Causer, nullptr);
}

void AJREnemyCharacter::FreezeRagdoll()
{
	if (!IsDead())
	{
		return;
	}
	// Dorme em vez de desligar a física (desligar faria o corpo "levantar" na pose da animação).
	GetMesh()->PutAllRigidBodiesToSleep();
	SetLifeSpan(3.f);
}

bool AJREnemyCharacter::TryAttack()
{
	AActor* TargetActor = Target.Get();
	if (!Archetype || !TargetActor || IsDead())
	{
		return false;
	}
	const double Now = GetWorld()->GetTimeSeconds();
	if (Now - LastAttackTime < Archetype->AttackInterval)
	{
		return false;
	}
	LastAttackTime = Now;
	if (Archetype->AttackMontage)
	{
		PlayAnimMontage(Archetype->AttackMontage);
	}

	if (Archetype->AttackType == EJREnemyAttackType::Melee)
	{
		// Golpe com preparação: o dano só sai se o alvo ainda estiver ao alcance (dá para desviar).
		GetWorldTimerManager().SetTimer(MeleeHitTimer, this, &AJREnemyCharacter::ResolveMeleeHit, MeleeWindup, false);
		return true;
	}

	BurstShotsRemaining = FMath::Max(1, Archetype->BurstCount);
	FireRangedShot();
	return true;
}

FVector AJREnemyCharacter::GetMuzzleLocation() const
{
	return GetMesh() && GetMesh()->DoesSocketExist(MuzzleSocket) ? GetMesh()->GetSocketLocation(MuzzleSocket)
		: GetActorLocation() + FVector(0.f, 0.f, BaseEyeHeight);
}

void AJREnemyCharacter::FireRangedShot()
{
	AActor* TargetActor = Target.Get();
	if (!Archetype || !TargetActor || IsDead() || BurstShotsRemaining <= 0)
	{
		return;
	}
	--BurstShotsRemaining;

	const FVector Muzzle = GetMuzzleLocation();
	FVector AimPoint;
	double TimeToHit = 0.0;
	FJRAimPrediction::PredictInterceptPoint(Muzzle, TargetActor->GetActorLocation(), TargetActor->GetVelocity(),
		Archetype->ProjectileSpeed, AimPoint, TimeToHit);
	const FVector Dir = FJRAimPrediction::ApplySpread(AimPoint - Muzzle, Archetype->SpreadHalfAngleDegrees, Random);

	if (Archetype->AttackType == EJREnemyAttackType::Projectile && Archetype->ProjectileClass)
	{
		FActorSpawnParameters Params;
		Params.Owner = this;
		Params.Instigator = this;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		if (AActor* Projectile = GetWorld()->SpawnActor<AActor>(Archetype->ProjectileClass, Muzzle, Dir.Rotation(), Params))
		{
			if (UProjectileMovementComponent* Move = Projectile->FindComponentByClass<UProjectileMovementComponent>())
			{
				Move->Velocity = Dir * Archetype->ProjectileSpeed;
			}
		}
	}
	else
	{
		FHitResult Hit;
		FCollisionQueryParams Query(SCENE_QUERY_STAT(JREnemyShot), true, this);
		const FVector End = Muzzle + Dir * (Archetype->AttackRange * 1.5f);
		if (GetWorld()->LineTraceSingleByChannel(Hit, Muzzle, End, ECC_Visibility, Query) && Hit.GetActor())
		{
			UGameplayStatics::ApplyPointDamage(Hit.GetActor(), Archetype->AttackDamage, Dir, Hit, GetController(), this, nullptr);
		}
	}

	if (BurstShotsRemaining > 0)
	{
		GetWorldTimerManager().SetTimer(BurstTimer, this, &AJREnemyCharacter::FireRangedShot, Archetype->BurstShotInterval, false);
	}
}

void AJREnemyCharacter::HandleDeath(UJRHealthComponent* Health, AActor* Killer)
{
	SetEnemyState(EJREnemyState::Dead);
	if (GrabbedVehicle.IsValid() || GrabSlot != INDEX_NONE)
	{
		ReleaseFromVehicle(false, FVector::ZeroVector); // morto: só solta do carro
	}
	GetWorldTimerManager().ClearTimer(BrainTimer);
	GetWorldTimerManager().ClearTimer(BurstTimer);
	GetWorldTimerManager().ClearTimer(MeleeHitTimer);
	if (AAIController* AI = Cast<AAIController>(GetController()))
	{
		AI->StopMovement();
		AI->ClearFocus(EAIFocusPriority::Gameplay);
	}
	GetCharacterMovement()->DisableMovement();
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
	GetMesh()->SetSimulatePhysics(true);
	SetLifeSpan(Archetype ? Archetype->CorpseLifetime : 10.f);
	if (!PendingLaunch.IsZero())
	{
		GetMesh()->SetAllPhysicsLinearVelocity(PendingLaunch, false); // atropelado/explosão: o corpo todo voa longe
		PendingLaunch = FVector::ZeroVector;
	}
	if (UJREnemyBudgetSubsystem* Budget = GetWorld()->GetSubsystem<UJREnemyBudgetSubsystem>())
	{
		Budget->RegisterRagdoll(this); // teto de ragdolls ativos (os mais antigos congelam)
	}
	if (AJRAIDirector* Director = AJRAIDirector::Find(this))
	{
		Director->NotifyEnemyKilled(this);
	}
	DropLoot();
	UE_LOG(LogJR, Log, TEXT("IA %s morreu"), *GetName());
	OnEnemyDied.Broadcast(this);
}

void AJREnemyCharacter::HandleCapsuleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor && OtherActor->IsA<AJRVehiclePawn>())
	{
		HitByVehicle(OtherActor);
	}
}

void AJREnemyCharacter::HitByVehicle(AActor* Vehicle)
{
	AJRVehiclePawn* Car = Cast<AJRVehiclePawn>(Vehicle);
	const double Now = GetWorld()->GetTimeSeconds();
	if (!Car || IsDead() || GrabbedVehicle.IsValid() || Now - LastVehicleHitTime < 0.5)
	{
		return;
	}
	const FVector Vel = Car->GetVelocity();
	const float Kmh = static_cast<float>(Vel.Size()) * 0.036f;
	if (Kmh < BumpMinSpeedKmh)
	{
		return; // carro parado/quase parado: zumbi encostando não é atropelamento
	}
	LastVehicleHitTime = Now;
	const FVector Away = (GetActorLocation() - Car->GetActorLocation()).GetSafeNormal2D();
	// Só conta a velocidade do carro NA DIREÇÃO do zumbi (raspão de lado só empurra).
	const float ImpactKmh = FMath::Max(0.f, static_cast<float>(FVector::DotProduct(Vel, Away))) * 0.036f;
	if (ImpactKmh >= RunOverSpeedKmh)
	{
		// Arremesso (ragdoll): herda a velocidade do carro, para cima e para o lado.
		const FVector Launch = Vel * 0.9f + Away * 300.f + FVector(0.f, 0.f, 350.f + ImpactKmh * 9.f);
		if (UJRVehicleDamageComponent* Damage = Car->GetDamageComponent())
		{
			Damage->ApplyZoneDamage(EJRVehicleZone::Front, RunOverCarDamage + ImpactKmh * 0.03f);
		}
		Car->ApplyZombieDrag(RunOverDragFraction); // cada zumbi freia um pouco (o carro limita o total)
		Car->NotifyZombieCarEvent(EJRZombieCarEvent::RunOver, this, GetActorLocation(), ImpactKmh);
		KillWithLaunch(Launch, Car->GetController(), Car);
		return;
	}
	// Devagar: às vezes pula no carro e se agarra.
	if (Kmh < Car->GrabMaxSpeedKmh && Archetype && Archetype->AttackType == EJREnemyAttackType::Melee
		&& Now >= NextGrabTime && Random.FRand() < GrabWhenBumpedChance && TryGrabVehicle(Car))
	{
		return;
	}
	// Senão é empurrado e cambaleia, mas continua vindo.
	LaunchCharacter(Away * (300.f + Kmh * 20.f) + FVector(0.f, 0.f, 200.f), true, true);
	UGameplayStatics::ApplyDamage(this, 5.f, Car->GetController(), Car, nullptr);
	StaggerUntil = Now + StaggerTime * 2.f;
	Car->NotifyZombieCarEvent(EJRZombieCarEvent::ZombiePushed, this, GetActorLocation(), Kmh);
}

void AJREnemyCharacter::ResolveMeleeHit()
{
	AActor* TargetActor = Target.Get();
	if (!Archetype || !TargetActor || IsDead())
	{
		return;
	}
	if (AJRVehiclePawn* Car = Cast<AJRVehiclePawn>(TargetActor))
	{
		// Carro: soco na lataria mais próxima (dano na zona, sem furar pneu).
		FVector Contact;
		if (Car->GetDistanceToBody(GetActorLocation(), &Contact) > Archetype->AttackRange * 1.35f + 60.f)
		{
			return; // o carro saiu
		}
		const float Amount = Archetype->AttackDamage * VehicleAttackDamageScale;
		if (UJRVehicleDamageComponent* Damage = Car->GetDamageComponent())
		{
			Damage->ApplyDamageAtLocation(Contact, Amount, false);
		}
		Car->NotifyZombieCarEvent(EJRZombieCarEvent::ZombieHitCar, this, Contact, Amount);
		return;
	}
	const float Dist = static_cast<float>(FVector::Dist2D(TargetActor->GetActorLocation(), GetActorLocation()));
	if (Dist > Archetype->AttackRange * 1.35f + 60.f)
	{
		return; // desviou
	}
	// Dano pontual: no veículo vira dano por zona (UJRVehicleDamageComponent).
	FHitResult Hit;
	Hit.ImpactPoint = TargetActor->GetActorLocation();
	Hit.Location = Hit.ImpactPoint;
	const FVector Dir = (TargetActor->GetActorLocation() - GetActorLocation()).GetSafeNormal();
	UGameplayStatics::ApplyPointDamage(TargetActor, Archetype->AttackDamage, Dir, Hit, GetController(), this, nullptr);
}

void AJREnemyCharacter::HandleHealthChanged(UJRHealthComponent* Health, float NewHealth, float Delta)
{
	if (Delta >= 0.f || NewHealth <= 0.f || IsDead())
	{
		return;
	}
	StaggerUntil = GetWorld()->GetTimeSeconds() + StaggerTime;
	GetWorldTimerManager().ClearTimer(MeleeHitTimer); // apanhou: perde o golpe
	if (Archetype && Archetype->HitReactMontage)
	{
		PlayAnimMontage(Archetype->HitReactMontage);
	}
	// Levou tiro de longe: agora sabe onde o jogador está.
	bForceAggro = true;
	bHoldPosition = false;
}

void AJREnemyCharacter::DropLoot()
{
	if (bHasGuaranteedDrop)
	{
		if (AJRPickup* Drop = AJRPickup::SpawnPickup(GetWorld(), GuaranteedDrop, 1.f, GetActorLocation() - FVector(0.f, 0.f, 70.f)))
		{
			Drop->SetDisplayMesh(GuaranteedDropMesh, 1.3f);
		}
		return;
	}
	if (Random.FRand() > DropChance)
	{
		return;
	}
	if (bKilledByVehicle)
	{
		// Atropelou: às vezes solta um pouco de nitro (o carro pega passando por cima).
		if (Random.FRand() < 0.5f)
		{
			AJRPickup::SpawnPickup(GetWorld(), EJRPickupType::Nitro, 0.12f, GetActorLocation() - FVector(0.f, 0.f, 40.f), 20.f);
		}
		return;
	}
	// Mais munição; vida e Fúria são mais raros.
	const float Roll = Random.FRand();
	EJRPickupType Type = EJRPickupType::Ammo;
	float Amount = 12.f;
	if (Roll > 0.92f)
	{
		Type = EJRPickupType::Fury;
		Amount = 10.f;
	}
	else if (Roll > 0.7f)
	{
		Type = EJRPickupType::Health;
		Amount = 25.f;
	}
	AJRPickup::SpawnPickup(GetWorld(), Type, Amount, GetActorLocation() - FVector(0.f, 0.f, 40.f), 30.f);
}
