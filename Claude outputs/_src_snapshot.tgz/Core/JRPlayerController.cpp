// Copyright utrazin. All Rights Reserved.

#include "Core/JRPlayerController.h"
#include "AI/JRAIDirector.h"
#include "Characters/JRCharacter.h"
#include "Core/JRGameMode.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "InputActionValue.h"
#include "UI/JRHUD.h"
#include "Engine/GameInstance.h"
#include "Engine/LocalPlayer.h"
#include "Engine/World.h"
#include "InputMappingContext.h"
#include "JogoResgate.h"
#include "Kismet/GameplayStatics.h"
#include "Progression/JRProgressionSubsystem.h"
#include "Vehicles/JRVehicleDamageComponent.h"
#include "Vehicles/JRVehiclePawn.h"

void AJRPlayerController::JRHeroi(const FString& CharacterId)
{
	UJRProgressionSubsystem* Progression = GetGameInstance() ? GetGameInstance()->GetSubsystem<UJRProgressionSubsystem>() : nullptr;
	if (!Progression)
	{
		UE_LOG(LogJR, Warning, TEXT("JRHeroi: sem ProgressionSubsystem."));
		return;
	}
	Progression->SelectCharacter(FName(*CharacterId), NAME_None);
	UE_LOG(LogJR, Log, TEXT("JRHeroi: personagem selecionado %s. Reiniciando a fase."), *CharacterId);
	UGameplayStatics::OpenLevel(this, FName(*UGameplayStatics::GetCurrentLevelName(this)));
}

void AJRPlayerController::JRDirector(const FString& Command)
{
	JRDiretor(Command);
}

void AJRPlayerController::JRDiretor(const FString& Command)
{
	AJRAIDirector* Director = AJRAIDirector::Find(this);
	TArray<FString> Words;
	Command.TrimStartAndEnd().ToLower().ParseIntoArrayWS(Words);
	const FString Cmd = Words.Num() > 0 ? Words[0] : FString();
	if (Cmd.IsEmpty() || Cmd == TEXT("debug"))
	{
		const bool bNew = !AJRAIDirector::IsDebugEnabled();
		AJRAIDirector::SetDebugEnabled(bNew);
		UE_LOG(LogJR, Log, TEXT("JRDiretor: debug %s%s"), bNew ? TEXT("ligado") : TEXT("desligado"),
			Director ? TEXT("") : TEXT(" (nenhum AJRAIDirector neste mapa!)"));
		return;
	}
	if (!Director)
	{
		UE_LOG(LogJR, Warning, TEXT("JRDiretor: nenhum AJRAIDirector neste mapa (rode tools/unreal/setup_ai_director.py)."));
		return;
	}
	if (Cmd == TEXT("horda") || Cmd == TEXT("horde"))
	{
		const int32 Size = Words.Num() > 1 ? FCString::Atoi(*Words[1]) : 0;
		Director->TriggerHorde(TEXT("Console"), 60.f, Size);
	}
	else if (Cmd == TEXT("calma") || Cmd == TEXT("calmaria"))
	{
		Director->ForcePhase(EJRDirectorPhase::Relax);
	}
	else if (Cmd == TEXT("subida"))
	{
		Director->ForcePhase(EJRDirectorPhase::BuildUp);
	}
	else if (Cmd == TEXT("status"))
	{
		UE_LOG(LogJR, Log, TEXT("%s"), *Director->GetStatusLine());
	}
	else if (Cmd == TEXT("off") || Cmd == TEXT("on"))
	{
		Director->SetDirectorEnabled(Cmd == TEXT("on"));
		UE_LOG(LogJR, Log, TEXT("JRDiretor: diretor %s"), Director->IsDirectorEnabled() ? TEXT("ligado") : TEXT("desligado"));
	}
	else
	{
		UE_LOG(LogJR, Warning, TEXT("JRDiretor: comandos: (vazio) | horda [tamanho] | calma | subida | status | off | on"));
	}
}

void AJRPlayerController::JRCarDamage(float Amount)
{
	AJRVehiclePawn* Vehicle = Cast<AJRVehiclePawn>(GetPawn());
	if (!Vehicle || !Vehicle->GetDamageComponent())
	{
		UE_LOG(LogJR, Warning, TEXT("JRCarDamage: você não está num carro."));
		return;
	}
	const float Value = Amount > 0.f ? Amount : 25.f;
	UJRVehicleDamageComponent* Damage = Vehicle->GetDamageComponent();
	Damage->ApplyZoneDamage(EJRVehicleZone::Front, Value);
	Damage->ApplyZoneDamage(EJRVehicleZone::Engine, Value);
	UE_LOG(LogJR, Log, TEXT("JRCarDamage: integridade agora %.0f%%"), Damage->GetIntegrity() * 100.f);
}

void AJRPlayerController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);
	ApplyMappingContextFor(InPawn);
	if (AJRCharacter* OnFootChar = Cast<AJRCharacter>(InPawn))
	{
		OnFootCharacter = OnFootChar;
	}
	OnControlledPawnChanged.Broadcast(InPawn);
}

void AJRPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	if (UEnhancedInputComponent* Input = Cast<UEnhancedInputComponent>(InputComponent))
	{
		if (ToggleMapAction)
		{
			Input->BindAction(ToggleMapAction, ETriggerEvent::Started, this, &AJRPlayerController::HandleToggleMap);
		}
	}
}

void AJRPlayerController::HandleToggleMap(const FInputActionValue& Value)
{
	if (AJRHUD* JRHud = Cast<AJRHUD>(GetHUD()))
	{
		JRHud->ToggleBigMap();
	}
}

void AJRPlayerController::ApplyMappingContextFor(const APawn* InPawn)
{
	UEnhancedInputLocalPlayerSubsystem* Subsystem = GetLocalPlayer()
		? GetLocalPlayer()->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>() : nullptr;
	if (!Subsystem)
	{
		return;
	}
	Subsystem->ClearAllMappings();
	for (UInputMappingContext* Context : GlobalMappingContexts)
	{
		if (Context)
		{
			Subsystem->AddMappingContext(Context, 10);
		}
	}
	const bool bInVehicle = InPawn && InPawn->IsA<AJRVehiclePawn>();
	for (UInputMappingContext* Context : bInVehicle ? VehicleMappingContexts : OnFootMappingContexts)
	{
		if (Context)
		{
			Subsystem->AddMappingContext(Context, 0);
		}
	}
}

bool AJRPlayerController::RequestExitVehicle(const FTransform& FallbackTransform)
{
	AJRVehiclePawn* Vehicle = Cast<AJRVehiclePawn>(GetPawn());
	if (!Vehicle || bExitInProgress)
	{
		return false;
	}
	bExitInProgress = true;

	AJRGameMode* GameMode = GetWorld()->GetAuthGameMode<AJRGameMode>();
	const FTransform SpawnTransform = Vehicle->GetExitTransform();

	// Reutiliza o personagem se já existir: a transição nunca duplica personagens.
	AJRCharacter* OnFootChar = OnFootCharacter;
	if (OnFootChar)
	{
		OnFootChar->SetActorTransform(SpawnTransform, false, nullptr, ETeleportType::TeleportPhysics);
	}
	else
	{
		const TSubclassOf<AJRCharacter> CharacterClass = GameMode ? GameMode->ResolveCharacterClass() : nullptr;
		if (!CharacterClass)
		{
			UE_LOG(LogJR, Error, TEXT("RequestExitVehicle: classe de personagem não definida."));
			bExitInProgress = false;
			return false;
		}
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
		OnFootChar = GetWorld()->SpawnActor<AJRCharacter>(CharacterClass, SpawnTransform, Params);
		if (!OnFootChar)
		{
			OnFootChar = GetWorld()->SpawnActor<AJRCharacter>(CharacterClass, FallbackTransform, Params);
		}
		if (!OnFootChar)
		{
			UE_LOG(LogJR, Error, TEXT("RequestExitVehicle: falha ao spawnar personagem."));
			bExitInProgress = false;
			return false;
		}
	}

	Vehicle->ParkAndDisable();
	ParkedVehicle = Vehicle;
	Possess(OnFootChar); // UnPossessed do veículo zera os inputs
	if (GameMode)
	{
		GameMode->ApplySelectedSkin(OnFootChar);
	}
	OnFootChar->PlayExitFromVehicle(Vehicle, Vehicle->GetSeatTransform());
	bExitInProgress = false;
	return true;
}
